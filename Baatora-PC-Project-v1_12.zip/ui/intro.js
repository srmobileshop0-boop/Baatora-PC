/* Baatora PC — first-run welcome (shown once, Opera-style animated intro) */
'use strict';
(function () {
  const DONE_KEY = 'bt_intro_v1';
  let done = false;
  try { done = localStorage.getItem(DONE_KEY) === '1'; } catch (e) {}

  function markDone() {
    try { localStorage.setItem(DONE_KEY, '1'); } catch (e) {}
    try { window.bt.setFlag('introDone', true); } catch (e) {}
  }

  const FEAT = [
    ['shield', 'Ad Blocker', 'Pages without junk ads and trackers'],
    ['speed', 'Memory Saver', 'Sleeping tabs keep your PC fast'],
    ['globe', 'Secure DNS', 'Sites start loading sooner'],
    ['print', 'Print & PDF', 'Full print preview, like Chrome'],
    ['lang', 'Translate', 'Any page into Hindi and more'],
    ['incog', 'Incognito', 'Browse without saving history']
  ];

  function el(h) { const d = document.createElement('div'); d.innerHTML = h.trim(); return d.firstChild; }

  function showIntro(force) {
    if (INCOG) return;
    if (done && !force) return;
    if (document.getElementById('intro')) return;
    const reduce = !!S.reduceMotion;
    const box = el('<div id="intro" class="' + (reduce ? 'nomo' : '') + '">' +
      '<div class="in-drag"></div>' +
      '<div class="in-bg"><i class="o1"></i><i class="o2"></i><i class="o3"></i><i class="o4"></i></div>' +
      '<div class="in-stars"></div>' +
      '<button class="in-skip" id="inSkip">Skip</button>' +
      /* Stage 1: animated logo splash */
      '<div class="in-splash" id="inSplash">' +
        '<div class="in-logo"><span class="ring r1"></span><span class="ring r2"></span><span class="ring r3"></span><img src="logo.png" alt=""></div>' +
        '<div class="in-word">' + 'Baatora'.split('').map((c, i) => '<b style="--d:' + (i * 0.06 + 1.15) + 's">' + c + '</b>').join('') + '</div>' +
        '<div class="in-tag">Fast. Secure. Your own browser.</div>' +
      '</div>' +
      /* Stage 2: welcome steps */
      '<div class="in-steps" id="inSteps"><div class="in-card" id="inCard"></div><div class="in-dots" id="inDots"></div></div>' +
    '</div>');
    document.body.appendChild(box);

    // Twinkling stars
    const st = box.querySelector('.in-stars');
    for (let i = 0; i < 46; i++) {
      const s = document.createElement('i');
      s.style.left = Math.random() * 100 + '%'; s.style.top = Math.random() * 100 + '%';
      s.style.animationDelay = (Math.random() * 3).toFixed(2) + 's';
      s.style.transform = 'scale(' + (0.4 + Math.random()).toFixed(2) + ')';
      st.appendChild(s);
    }

    let step = 0;
    const STEPS = [stepWelcome, stepLook, stepSetup, stepDefault, stepReady];

    function go(n) {
      step = Math.max(0, Math.min(STEPS.length - 1, n));
      const c = document.getElementById('inCard');
      c.classList.remove('show');
      setTimeout(() => {
        c.innerHTML = STEPS[step]();
        bindStep(c);
        c.classList.add('show');
        document.getElementById('inDots').innerHTML = STEPS.map((_, i) => '<i class="' + (i === step ? 'on' : (i < step ? 'past' : '')) + '"></i>').join('');
      }, reduce ? 0 : 220);
    }

    function nav(next, back, nextLabel) {
      return '<div class="in-nav">' + (back ? '<button class="in-btn ghost" data-in="back">Back</button>' : '<span></span>') +
        '<button class="in-btn pri" data-in="' + (next || 'next') + '">' + (nextLabel || 'Continue') + ' <svg viewBox="0 0 24 24"><path d="M12 4l-1.41 1.41L16.17 11H4v2h12.17l-5.58 5.59L12 20l8-8z"/></svg></button></div>';
    }

    function stepWelcome() {
      return '<div class="in-hero"><img src="logo.png" alt=""><div><h1>Welcome to <span>Baatora</span></h1><p>A fast, clean browser — made in India 🇮🇳, made for you.</p></div></div>' +
        '<div class="in-feat">' + FEAT.map((f, i) => '<div style="--d:' + (i * 0.07) + 's"><b class="fic"><svg><use href="#i-' + f[0] + '"/></svg></b><span><strong>' + f[1] + '</strong><small>' + f[2] + '</small></span></div>').join('') + '</div>' +
        nav('next', false, 'Let’s go');
    }

    function stepLook() {
      const mode = S.mode || 'light', theme = S.theme || 'light';
      const modes = [['light', 'sun', 'Light'], ['dark', 'moon', 'Dark'], ['device', 'desk', 'System']];
      const themes = Object.keys(THEMES).filter((k) => k !== 'incog');
      return '<h2>Make it yours</h2><p class="in-sub">Pick a look. You can change it any time in Settings › Appearance.</p>' +
        '<div class="in-modes">' + modes.map((m) => '<button data-mode="' + m[0] + '" class="' + (mode === m[0] ? 'on' : '') + '"><span class="pv ' + m[0] + '"><i></i><i></i><i></i></span><b><svg><use href="#i-' + m[1] + '"/></svg>' + m[2] + '</b></button>').join('') + '</div>' +
        '<div class="in-themes">' + themes.map((k) => '<button data-theme="' + k + '" title="' + esc(THEMES[k].n) + '" class="' + (theme === k ? 'on' : '') + '" style="--a:' + THEMES[k].acc + ';--b:' + THEMES[k].bar + ';--c:' + THEMES[k].tool + '"><i></i></button>').join('') + '</div>' +
        nav('next', true);
    }

    function stepSetup() {
      const sw = (k, on, ic, t, s) => '<label class="in-row"><b class="fic"><svg><use href="#i-' + ic + '"/></svg></b><span><strong>' + t + '</strong><small>' + s + '</small></span><button class="in-sw' + (on ? ' on' : '') + '" data-sw="' + k + '"><i></i></button></label>';
      return '<h2>Browse faster</h2><p class="in-sub">Smart defaults are already on. Turn off anything you don’t want.</p>' +
        sw('adblock', S.adblock !== false, 'shield', 'Block ads and trackers', 'Pages load faster and cleaner') +
        sw('memSaver', S.memSaver !== false, 'speed', 'Memory Saver', 'Inactive tabs sleep to keep Baatora smooth') +
        sw('bmbar', !!S.bmbar, 'bm', 'Show bookmarks bar', 'Your favourite sites, one click away') +
        '<label class="in-row"><b class="fic"><svg><use href="#i-zoom"/></svg></b><span><strong>Search engine</strong><small>Used in the address bar</small></span><select id="inEng">' + Object.keys(ENG).map((k) => '<option value="' + k + '"' + (S.engine === k ? ' selected' : '') + '>' + ENGN[k] + '</option>').join('') + '</select></label>' +
        nav('next', true);
    }

    function stepDefault() {
      return '<div class="in-def"><div class="in-defl"><img src="logo.png" alt=""></div>' +
        '<h2>Make Baatora your default</h2><p class="in-sub">Open every link in Baatora, and bring your bookmarks from Chrome, Edge or Firefox.</p>' +
        '<div class="in-acts"><button class="in-btn pri" data-in="default"><svg><use href="#i-win"/></svg>Set as default browser</button>' +
        '<button class="in-btn ghost" data-in="import"><svg><use href="#i-star"/></svg>Import bookmarks</button></div>' +
        '<small class="in-hint" id="inHint">In Chrome: Bookmarks › Bookmark manager › ⋮ › Export bookmarks — then import that file here.</small></div>' +
        nav('next', true, 'Next');
    }

    function stepReady() {
      return '<div class="in-ready"><div class="in-burst">' + Array.from({ length: 14 }, (_, i) => '<i style="--r:' + (i * 360 / 14) + 'deg;--d:' + (i * 0.03) + 's"></i>').join('') + '<img src="logo.png" alt=""></div>' +
        '<h2>You’re all set!</h2><p class="in-sub">Enjoy a faster, cleaner web with Baatora.</p>' +
        '<button class="in-btn pri big" data-in="finish">Start browsing <svg viewBox="0 0 24 24"><path d="M12 4l-1.41 1.41L16.17 11H4v2h12.17l-5.58 5.59L12 20l8-8z"/></svg></button>' +
        '<div class="in-made">Created by <b>Anil Yadav</b> · Made in India</div></div>';
    }

    function bindStep(c) {
      c.querySelectorAll('[data-in]').forEach((b) => b.onclick = async () => {
        const a = b.dataset.in;
        if (a === 'next') go(step + 1);
        else if (a === 'back') go(step - 1);
        else if (a === 'finish') finish();
        else if (a === 'default') { window.bt.defaultBrowser(); b.innerHTML = '✓ Opening Windows Settings…'; }
        else if (a === 'import') {
          const n = await INT_API.importBookmarks().catch(() => null);
          if (n != null) { b.innerHTML = '✓ ' + n + ' bookmarks imported'; b.classList.add('ok'); }
        }
      });
      c.querySelectorAll('[data-mode]').forEach((b) => b.onclick = () => { INT_API.setS('mode', b.dataset.mode); c.querySelectorAll('[data-mode]').forEach((x) => x.classList.toggle('on', x === b)); });
      c.querySelectorAll('[data-theme]').forEach((b) => b.onclick = () => { INT_API.setS('theme', b.dataset.theme); c.querySelectorAll('[data-theme]').forEach((x) => x.classList.toggle('on', x === b)); });
      c.querySelectorAll('[data-sw]').forEach((b) => b.onclick = (e) => { e.preventDefault(); const v = !b.classList.contains('on'); b.classList.toggle('on', v); INT_API.setS(b.dataset.sw, v); });
      const eng = c.querySelector('#inEng'); if (eng) eng.onchange = () => { INT_API.setS('engine', eng.value); applyTheme(); };
    }

    function finish() {
      markDone(); done = true;
      box.classList.add('out');
      setTimeout(() => { box.remove(); if (cur) { if (isHome(cur.url)) $('addr').focus(); else cur.wv.focus(); } }, reduce ? 0 : 650);
    }

    document.getElementById('inSkip').onclick = finish;
    box.addEventListener('keydown', (e) => { if (e.key === 'Escape') finish(); });
    // Splash → steps
    setTimeout(() => { box.classList.add('steps'); go(0); }, reduce ? 300 : 3100);
  }

  window.showIntro = showIntro;
  // First run: wait for saved flags so a reinstall/old profile that already saw it doesn't repeat
  if (!done && !INCOG) {
    window.bt.flags().then((f) => {
      if (f && f.introDone) { done = true; try { localStorage.setItem(DONE_KEY, '1'); } catch (e) {} return; }
      showIntro(false);
    }).catch(() => showIntro(false));
  }
})();
