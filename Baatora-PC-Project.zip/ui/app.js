/* Baatora PC — browser UI (tabs, address bar, panels) */
'use strict';
const Q = new URLSearchParams(location.search);
const INCOG = Q.get('incog') === '1';
const HOME = Q.get('home');
const PART = INCOG ? 'baatora-incognito' : 'persist:baatora';
const $ = (id) => document.getElementById(id);
const MOBILE_UA = 'Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Mobile Safari/537.36';
const ENG = { google: 'https://www.google.com/search?q=', bing: 'https://www.bing.com/search?q=', duckduckgo: 'https://duckduckgo.com/?q=', yahoo: 'https://search.yahoo.com/search?p=' };
const ENGN = { google: 'Google', bing: 'Bing', duckduckgo: 'DuckDuckGo', yahoo: 'Yahoo' };

document.addEventListener('error', (e) => { const im = e.target; if (!im || im.tagName !== 'IMG') return; const m = /url=https:\/\/([^&]+)/.exec(im.src); if (m && !im.dataset.f) { im.dataset.f = '1'; im.src = 'https://www.google.com/s2/favicons?domain=' + m[1] + '&sz=32'; } else if (im.dataset.f !== '2') { im.dataset.f = '2'; im.src = 'logo.png'; } }, true);
if (INCOG) { document.body.classList.add('incog'); document.title = 'Baatora Incognito'; }

/* ---------------- Storage ---------------- */
function load(k, d) { try { const v = JSON.parse(localStorage.getItem(k)); return v == null ? d : v; } catch (e) { return d; } }
function save(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) {} }
const S = Object.assign({ engine: 'google', adblock: true, theme: 'light', bmbar: true, restore: true, night: false }, load('bt_set', {}));
function saveSet() { save('bt_set', S); }
let HIST = load('bt_hist', []);
let BM = load('bt_bm', []);
let DL = INCOG ? [] : load('bt_dl', []);
function saveHist() { if (!INCOG) save('bt_hist', HIST.slice(0, 3000)); }
function saveBm() { save('bt_bm', BM); }
function saveDl() { if (!INCOG) save('bt_dl', DL.slice(0, 200)); }
window.addEventListener('storage', (e) => {
  if (e.key === 'bt_bm') { BM = load('bt_bm', []); renderBm(); updStar(); }
  if (e.key === 'bt_hist') HIST = load('bt_hist', []);
  if (e.key === 'bt_set') { Object.assign(S, load('bt_set', {})); renderBm(); updShield(); applyTheme(); }
});


/* ---------------- Browser ka rang (Themes) ---------------- */
const FLAG_SVG = '<svg viewBox="0 0 30 20"><rect width="30" height="20" fill="#fff"/><rect width="30" height="6.67" fill="#FF9933"/><rect y="13.33" width="30" height="6.67" fill="#138808"/><circle cx="15" cy="10" r="2.7" fill="none" stroke="#000080" stroke-width=".7"/><circle cx="15" cy="10" r=".7" fill="#000080"/></svg>';
const LIGHT_BASE = { omni: '#F1F3F4', field: '#FFFFFF', pan: '#FFFFFF', line: 'rgba(0,0,0,.12)', hov: 'rgba(0,0,0,.07)', hov2: 'rgba(0,0,0,.12)', chip: 'rgba(0,0,0,.05)', shadow: 'rgba(15,23,42,.18)', dim: 'rgba(15,23,42,.35)', sec: '#0F9D58', brandg: 'linear-gradient(90deg,#FF6D00,#FF9100 45%,#1E5BFF)' };
const DARK_BASE = { line: 'rgba(255,255,255,.14)', hov: 'rgba(255,255,255,.09)', hov2: 'rgba(255,255,255,.16)', chip: 'rgba(255,255,255,.08)', shadow: 'rgba(0,0,0,.5)', dim: 'rgba(0,0,0,.55)', sec: '#69F0AE', txt: '#FFFFFF', brandg: 'linear-gradient(90deg,#FF8A00,#FFC107 45%,#00E5FF)' };
function LT(o) { return Object.assign({ dark: false }, LIGHT_BASE, o); }
function DK(o) { return Object.assign({ dark: true }, DARK_BASE, o); }
const THEMES = {
  light: LT({ n: 'Safed (Light)', bar: '#DFE3E8', tool: '#FFFFFF', tabon: '#FFFFFF', pan2: '#F6F8FB', txt: '#1F2937', mu: '#5F6B7A', ic: '#3C4552', tabtxt: '#3C4552', acc: '#1E5BFF', hb: ['#F8FAFF', '#EEF3FF', '#E4ECFF'] }),
  grey: LT({ n: 'Grey', bar: '#C8CDD4', tool: '#ECEFF3', tabon: '#ECEFF3', omni: '#FFFFFF', pan2: '#F1F3F6', txt: '#202124', mu: '#5F6368', ic: '#3C4043', tabtxt: '#3C4043', acc: '#1A73E8', hb: ['#F4F5F7', '#ECEEF1', '#E2E5E9'] }),
  sky: LT({ n: 'Aasmani (Sky)', bar: '#B9E0FF', tool: '#EAF6FF', tabon: '#EAF6FF', omni: '#FFFFFF', pan2: '#F2F9FF', txt: '#0B2545', mu: '#4A6585', ic: '#1D4E89', tabtxt: '#1D4E89', acc: '#0288D1', hb: ['#F3FAFF', '#E3F3FF', '#D3ECFF'] }),
  saffron: LT({ n: 'Kesariya', bar: '#FFD3A6', tool: '#FFF4E8', tabon: '#FFF4E8', omni: '#FFFFFF', pan2: '#FFF9F2', txt: '#3A2200', mu: '#7A5A3A', ic: '#8A4B00', tabtxt: '#8A4B00', acc: '#E65100', hb: ['#FFFAF3', '#FFF0E0', '#FFE6CC'] }),
  mint: LT({ n: 'Hara (Mint)', bar: '#BDE8D3', tool: '#EEFBF5', tabon: '#EEFBF5', omni: '#FFFFFF', pan2: '#F3FCF8', txt: '#0B3D2E', mu: '#4B6F62', ic: '#0F5C45', tabtxt: '#0F5C45', acc: '#00897B', hb: ['#F4FCF8', '#E6F7EF', '#D7F2E5'] }),
  pink: LT({ n: 'Gulabi', bar: '#F7C6DA', tool: '#FFF0F6', tabon: '#FFF0F6', omni: '#FFFFFF', pan2: '#FFF6FA', txt: '#4A1030', mu: '#80506A', ic: '#8E1D55', tabtxt: '#8E1D55', acc: '#C2185B', hb: ['#FFF7FB', '#FFEAF3', '#FFDDEB'] }),
  navy: DK({ n: 'Baatora Neela', bar: '#06103A', tool: '#0B1A5E', tabon: '#0B1A5E', omni: '#040A26', field: '#040A26', pan: '#0E1C66', pan2: '#0A1650', mu: '#B3C0EE', ic: '#E6EBFF', tabtxt: '#CFD8FF', acc: '#00E5FF', hb: ['#0B1A5E', '#06103A', '#040A26'] }),
  black: DK({ n: 'Kaala (Dark)', bar: '#0F0F10', tool: '#202124', tabon: '#202124', omni: '#303134', field: '#303134', pan: '#292A2D', pan2: '#1F2023', txt: '#E8EAED', mu: '#9AA0A6', ic: '#E8EAED', tabtxt: '#BDC1C6', acc: '#8AB4F8', hb: ['#202124', '#18191B', '#111113'] }),
  purple: DK({ n: 'Jamuni', bar: '#24104F', tool: '#341A72', tabon: '#341A72', omni: '#1A0B3A', field: '#1A0B3A', pan: '#3A1F7E', pan2: '#2A1460', mu: '#CDBDF2', ic: '#F0E9FF', tabtxt: '#D9CCFF', acc: '#B388FF', hb: ['#341A72', '#24104F', '#170A35'] }),
  incog: DK({ n: 'Incognito', bar: '#1A0B3A', tool: '#2A1260', tabon: '#2A1260', omni: '#12062A', field: '#12062A', pan: '#2E1666', pan2: '#22104F', mu: '#C9B8F0', ic: '#EDE4FF', tabtxt: '#D9CCFF', acc: '#B388FF', hb: ['#2A1260', '#1A0B3A', '#12062A'] })
};
function curTheme() { return INCOG ? THEMES.incog : (THEMES[S.theme] || THEMES.light); }
function homeTheme() {
  const t = curTheme();
  return { b1: t.hb[0], b2: t.hb[1], b3: t.hb[2], txt: t.txt, mu: t.mu, acc: t.acc, brandg: t.brandg,
    card: t.dark ? 'rgba(255,255,255,.07)' : 'rgba(255,255,255,.8)', cardb: t.line, tile: t.dark ? 'rgba(255,255,255,.10)' : '#FFFFFF',
    field: t.dark ? t.field : '#FFFFFF', hov: t.hov, shadow: t.dark ? 'rgba(0,0,0,.45)' : 'rgba(15,23,42,.12)', o: t.dark ? '.45' : '.22' };
}
function applyTheme() {
  const t = curTheme(), r = document.documentElement.style;
  ['bar', 'tool', 'tabon', 'omni', 'field', 'pan', 'pan2', 'txt', 'mu', 'ic', 'tabtxt', 'line', 'hov', 'hov2', 'chip', 'shadow', 'dim', 'sec', 'acc', 'brandg'].forEach((k) => { if (t[k]) r.setProperty('--' + k, t[k]); });
  window.bt.titleColor(t.bar, t.dark ? '#FFFFFF' : '#1F2937');
  if (typeof tabs !== 'undefined') tabs.forEach((x) => { if (isHome(x.url) && x.ready) x.wv.executeJavaScript('window.applyUi&&applyUi(' + JSON.stringify(homeCfg()) + ')').catch(() => {}); });
}
function homeCfg() { return { engine: S.engine, incog: INCOG, home: homeTheme() }; }

/* ---------------- Helpers ---------------- */
function isHome(u) { return !!u && /^file:/i.test(u) && /\/pages\/home(-pc)?\.html$/i.test(u.split('#')[0].split('?')[0]); }
function homeUrl() { return HOME + (INCOG ? '#incog' : ''); }
function host(u) { try { return new URL(u).hostname; } catch (e) { return ''; } }
function fav(u) { const h = host(u); return h ? 'https://t1.gstatic.com/faviconV2?client=SOCIAL&type=FAVICON&fallback_opts=TYPE,SIZE,URL&url=https://' + encodeURIComponent(h) + '&size=64' : 'logo.png'; }
function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c])); }
function search(q) { return (ENG[S.engine] || ENG.google) + encodeURIComponent(q); }
function toUrl(q) {
  q = q.trim();
  if (!q) return null;
  if (/^(baatora:\/\/)?home$/i.test(q)) return homeUrl();
  if (/^[a-z][a-z0-9+.-]*:\/\//i.test(q) || /^(about|data|mailto|view-source):/i.test(q)) return q;
  if (/^(localhost|\d{1,3}(\.\d{1,3}){3})(:\d+)?(\/.*)?$/i.test(q)) return 'http://' + q;
  if (!/\s/.test(q) && /^[^\s/]+\.[a-z]{2,}(:\d+)?(\/.*)?$/i.test(q)) return 'https://' + q;
  return search(q);
}
function fmtSize(b) { if (!b || b < 0) return ''; const u = ['B', 'KB', 'MB', 'GB']; let i = 0; while (b >= 1024 && i < 3) { b /= 1024; i++; } return b.toFixed(i ? 1 : 0) + ' ' + u[i]; }
function fmtTime(ts) { const d = new Date(ts); return d.toLocaleTimeString('hi-IN', { hour: '2-digit', minute: '2-digit' }); }
function dayLabel(ts) {
  const d = new Date(ts), n = new Date(); const a = new Date(d.getFullYear(), d.getMonth(), d.getDate()), b = new Date(n.getFullYear(), n.getMonth(), n.getDate());
  const diff = Math.round((b - a) / 864e5);
  if (diff === 0) return 'AAJ'; if (diff === 1) return 'KAL';
  return d.toLocaleDateString('hi-IN', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' }).toUpperCase();
}
let toastT = 0;
function toast(m) { const t = $('toast'); t.textContent = m; t.classList.add('show'); clearTimeout(toastT); toastT = setTimeout(() => t.classList.remove('show'), 2600); }

/* ---------------- Tabs ---------------- */
let tabs = [], cur = null, seq = 0;
const closed = [];
const ASSETS = {};
async function asset(n) { if (!(n in ASSETS)) ASSETS[n] = await window.bt.asset(n); return ASSETS[n]; }

function newTab(url, opt) {
  opt = opt || {};
  const t = { id: ++seq, url: url || homeUrl(), title: 'Naya tab', icon: null, loading: false, ready: false, wcId: null, zoom: 1, mobile: false, audio: false, muted: false, nightKey: null };
  const wv = document.createElement('webview');
  wv.setAttribute('partition', PART);
  wv.setAttribute('allowpopups', '');
  wv.setAttribute('webpreferences', 'contextIsolation=yes,sandbox=yes');
  wv.src = t.url;
  t.wv = wv;
  const el = document.createElement('div');
  el.className = 'tab';
  el.innerHTML = '<img src="logo.png" alt=""><span>Naya tab</span><i class="snd"></i><button class="x" title="Band karein (Ctrl+W)">✕</button>';
  el.title = 'Naya tab';
  t.el = el;
  el.addEventListener('mousedown', (e) => { if (e.button === 0 && !e.target.classList.contains('x')) select(t); });
  el.addEventListener('auxclick', (e) => { if (e.button === 1) closeTab(t); });
  el.querySelector('.x').addEventListener('click', (e) => { e.stopPropagation(); closeTab(t); });
  el.querySelector('.snd').addEventListener('click', (e) => { e.stopPropagation(); t.muted = !t.muted; try { wv.setAudioMuted(t.muted); } catch (x) {} paintTab(t); });
  hookWv(t);
  const idx = opt.index != null ? opt.index : (opt.bg && cur ? tabs.indexOf(cur) + 1 : tabs.length);
  tabs.splice(idx, 0, t);
  const before = tabs[idx + 1];
  $('tabs').insertBefore(el, before ? before.el : null);
  $('views').appendChild(wv);
  if (!opt.bg || !cur) select(t);
  layoutTabs();
  saveSession();
  return t;
}

function hookWv(t) {
  const wv = t.wv;
  wv.addEventListener('dom-ready', async () => {
    if (!t.ready) { t.ready = true; try { t.wcId = wv.getWebContentsId(); } catch (e) {} if (t.mobile) wv.setUserAgent(MOBILE_UA); }
    const u = wv.getURL();
    if (isHome(u)) {
      wv.executeJavaScript('window.applyUi&&applyUi(' + JSON.stringify(homeCfg()) + ')').catch(() => {});
    } else if (/^https?:/i.test(u)) {
      const h = host(u);
      if (S.adblock) {
        if (/(^|\.)youtube(-nocookie)?\.com$/.test(h)) wv.executeJavaScript(await asset('ytblock.js')).catch(() => {});
        wv.executeJavaScript(await asset('adblock.js')).catch(() => {});
      }
      if (S.night) applyNight(t, true);
    }
    if (t === cur) updNav();
  });
  wv.addEventListener('did-start-loading', () => { t.loading = true; paintTab(t); if (t === cur) { progress(25); updNav(); } });
  wv.addEventListener('did-stop-loading', () => { t.loading = false; paintTab(t); if (t === cur) { progress(100); updNav(); } saveSession(); });
  wv.addEventListener('did-fail-load', (e) => { if (e.isMainFrame && e.errorCode !== -3 && t === cur) toast('Page nahi khula: ' + (e.errorDescription || e.errorCode)); });
  wv.addEventListener('page-title-updated', (e) => {
    t.title = e.title || t.title; paintTab(t);
    if (t === cur) document.title = (INCOG ? '🕶 ' : '') + t.title + ' - Baatora';
    if (!INCOG && HIST[0] && HIST[0].u === t.url) { HIST[0].t = t.title; saveHist(); }
  });
  wv.addEventListener('page-favicon-updated', (e) => { if (e.favicons && e.favicons[0]) { t.icon = e.favicons[0]; paintTab(t); } });
  const nav = (e) => {
    if (e.isMainFrame === false) return;
    t.url = e.url;
    if (isHome(t.url)) { t.title = INCOG ? 'Incognito' : 'Naya tab'; t.icon = null; }
    else if (e.type === 'did-navigate') t.icon = null;
    paintTab(t);
    if (t === cur) { updAddr(); updNav(); }
    if (e.type === 'did-navigate') addHist(t);
    saveSession();
  };
  wv.addEventListener('did-navigate', nav);
  wv.addEventListener('did-navigate-in-page', nav);
  wv.addEventListener('found-in-page', (e) => { const r = e.result; if (r && r.matches != null) $('findc').textContent = (r.activeMatchOrdinal || 0) + '/' + r.matches; });
  wv.addEventListener('enter-html-full-screen', () => document.body.classList.add('fs'));
  wv.addEventListener('leave-html-full-screen', () => document.body.classList.remove('fs'));
  wv.addEventListener('media-started-playing', () => { t.audio = true; paintTab(t); });
  wv.addEventListener('media-paused', () => { t.audio = false; paintTab(t); });
  wv.addEventListener('focus', closePops);
  wv.addEventListener('close', () => closeTab(t));
}

function paintTab(t) {
  const img = t.el.querySelector('img,.spin');
  if (t.loading && !img.classList.contains('spin')) { const s = document.createElement('i'); s.className = 'spin'; img.replaceWith(s); }
  else if (!t.loading) {
    let im = img;
    if (img.classList.contains('spin')) { im = document.createElement('img'); im.alt = ''; im.onerror = () => { im.src = 'logo.png'; }; img.replaceWith(im); }
    const src = t.icon || (isHome(t.url) ? 'logo.png' : (/^https?:/.test(t.url) ? fav(t.url) : 'logo.png'));
    if (im.getAttribute('src') !== src) { im.onerror = () => { im.onerror = null; im.src = 'logo.png'; }; im.src = src; }
  }
  t.el.querySelector('span').textContent = t.title;
  t.el.title = t.title + (isHome(t.url) ? '' : '\n' + t.url);
  t.el.querySelector('.snd').textContent = t.muted ? '🔇' : (t.audio ? '🔊' : '');
}

function select(t) {
  if (!t) return;
  if (cur && cur !== t) { cur.el.classList.remove('on'); cur.wv.classList.remove('on'); if (findOpen) closeFind(); }
  cur = t;
  t.el.classList.add('on'); t.wv.classList.add('on');
  document.title = (INCOG ? '🕶 ' : '') + t.title + ' - Baatora';
  updAddr(); updNav(); progress(t.loading ? 40 : 100);
  $('zval').textContent = Math.round(t.zoom * 100) + '%';
  if (isHome(t.url)) setTimeout(() => $('addr').focus(), 30); else t.wv.focus();
}

function closeTab(t) {
  const i = tabs.indexOf(t);
  if (i < 0) return;
  if (!isHome(t.url)) closed.push(t.url);
  tabs.splice(i, 1);
  t.el.remove(); t.wv.remove();
  if (!tabs.length) { saveSession(); window.bt.closeWindow(); return; }
  if (cur === t) { cur = null; select(tabs[Math.min(i, tabs.length - 1)]); }
  layoutTabs(); saveSession();
}

function layoutTabs() {
  const avail = document.body.clientWidth - 140 - 8 - 28 - 40 - 50;
  const w = Math.max(46, Math.min(220, Math.floor(avail / Math.max(1, tabs.length))));
  tabs.forEach((t) => { t.el.style.flexBasis = w + 'px'; t.el.style.width = w + 'px'; t.el.classList.toggle('narrow', w < 92); });
}
window.addEventListener('resize', layoutTabs);

let sesT = 0;
function saveSession() {
  if (INCOG) return;
  clearTimeout(sesT);
  sesT = setTimeout(() => save('bt_session', { tabs: tabs.map((t) => t.url), cur: tabs.indexOf(cur) }), 400);
}

/* ---------------- Navigation ---------------- */
function navigate(u) { if (!u || !cur) return; if (/^baatora:/i.test(u)) { baatora(u); return; } cur.wv.loadURL(u).catch(() => {}); cur.url = u; updAddr(); }
function goHome() { navigate(homeUrl()); }
function updAddr() {
  if (!cur) return;
  const a = $('addr'), sec = $('secure');
  if (document.activeElement !== a) a.value = isHome(cur.url) ? '' : cur.url;
  sec.className = isHome(cur.url) ? 'home' : (/^https:/.test(cur.url) ? '' : 'warn');
  sec.title = isHome(cur.url) ? 'Baatora Home' : (/^https:/.test(cur.url) ? 'Connection surakshit hai (HTTPS)' : 'Connection surakshit nahi hai');
  updStar();
}
function updNav() {
  if (!cur) return;
  let b = false, f = false;
  try { if (cur.ready) { b = cur.wv.canGoBack(); f = cur.wv.canGoForward(); } } catch (e) {}
  $('back').disabled = !b; $('fwd').disabled = !f;
  $('reloadIc').innerHTML = cur.loading ? '<path d="M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z"/>' : '<path d="M17.65 6.35A7.96 7.96 0 0 0 12 4a8 8 0 1 0 7.73 10h-2.08A6 6 0 1 1 12 6c1.66 0 3.14.69 4.22 1.78L13 11h7V4l-2.35 2.35z"/>';
  $('reload').title = cur.loading ? 'Rokein (Esc)' : 'Reload (F5)';
}
let progT = 0;
function progress(p) {
  const i = $('progress').firstElementChild;
  clearTimeout(progT);
  if (p >= 100) { i.style.width = '100%'; progT = setTimeout(() => { i.style.opacity = 0; setTimeout(() => { i.style.width = 0; }, 400); }, 200); }
  else { i.style.opacity = 1; i.style.width = p + '%'; progT = setTimeout(() => { if (cur && cur.loading) progress(Math.min(90, p + 12)); }, 500); }
}
function addHist(t) {
  if (INCOG || !/^https?:/i.test(t.url)) return;
  if (HIST[0] && HIST[0].u === t.url) { HIST[0].ts = Date.now(); }
  else HIST.unshift({ u: t.url, t: t.title && t.title !== 'Naya tab' ? t.title : host(t.url), ts: Date.now() });
  saveHist();
}

$('back').onclick = () => { try { cur.wv.goBack(); } catch (e) {} };
$('fwd').onclick = () => { try { cur.wv.goForward(); } catch (e) {} };
$('reload').onclick = () => { if (!cur) return; if (cur.loading) cur.wv.stop(); else cur.wv.reload(); };
$('home').onclick = goHome;
$('newtab').onclick = () => newTab();
$('tabbar').addEventListener('dblclick', (e) => { if (e.target.id === 'tabs') newTab(); });

/* ---------------- Address bar + suggestions ---------------- */
const addr = $('addr'), sugg = $('sugg');
let sItems = [], sIdx = -1;
addr.addEventListener('focus', () => setTimeout(() => addr.select(), 0));
addr.addEventListener('input', showSugg);
addr.addEventListener('blur', () => setTimeout(() => { sugg.style.display = 'none'; updAddr(); }, 150));
addr.addEventListener('keydown', (e) => {
  if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
    if (!sItems.length) return; e.preventDefault();
    sIdx = (sIdx + (e.key === 'ArrowDown' ? 1 : -1) + sItems.length) % sItems.length;
    [...sugg.children].forEach((d, i) => d.classList.toggle('on', i === sIdx));
    if (sItems[sIdx].u) addr.value = sItems[sIdx].u; else addr.value = sItems[sIdx].q;
  } else if (e.key === 'Enter') {
    e.preventDefault();
    const it = sIdx >= 0 ? sItems[sIdx] : null;
    const u = it ? (it.u || search(it.q)) : toUrl(addr.value);
    sugg.style.display = 'none';
    if (u) { if (e.altKey) newTab(u); else navigate(u); cur.wv.focus(); }
  } else if (e.key === 'Escape') { sugg.style.display = 'none'; addr.value = isHome(cur.url) ? '' : cur.url; addr.select(); }
});
function showSugg() {
  const q = addr.value.trim().toLowerCase();
  sIdx = -1; sItems = [];
  if (!q) { sugg.style.display = 'none'; return; }
  const seen = new Set();
  const direct = toUrl(addr.value);
  if (direct && direct.indexOf(ENG[S.engine]) !== 0) { sItems.push({ u: direct, t: 'Website kholein' }); seen.add(direct); }
  sItems.push({ q: addr.value.trim(), t: ENGN[S.engine] + ' par khojein' });
  const pool = BM.map((b) => Object.assign({ bm: 1 }, b)).concat(HIST);
  for (const h of pool) {
    if (sItems.length >= 8) break;
    if (seen.has(h.u)) continue;
    if ((h.u || '').toLowerCase().includes(q) || (h.t || '').toLowerCase().includes(q)) { seen.add(h.u); sItems.push(h); }
  }
  sugg.innerHTML = sItems.map((s) => s.q != null
    ? '<div><span>🔎</span><b>' + esc(s.q) + '</b><small>— ' + esc(s.t) + '</small></div>'
    : '<div><img src="' + esc(fav(s.u)) + '" width="16" height="16"><b>' + esc(s.t || s.u) + '</b><small>' + (s.bm ? '⭐ ' : '') + esc(s.u) + '</small></div>').join('');
  [...sugg.children].forEach((d, i) => d.addEventListener('mousedown', (e) => { e.preventDefault(); const it = sItems[i]; sugg.style.display = 'none'; navigate(it.u || search(it.q)); cur.wv.focus(); }));
  sugg.style.display = 'block';
}

/* ---------------- Bookmarks ---------------- */
function isBm(u) { return BM.some((b) => b.u === u); }
function updStar() { const on = cur && isBm(cur.url); $('star').classList.toggle('on', !!on); $('star').title = on ? 'Bookmark hatayein' : 'Bookmark karein (Ctrl+D)'; }
function toggleBm() {
  if (!cur || isHome(cur.url)) { toast('Home page ko bookmark nahi kar sakte'); return; }
  if (isBm(cur.url)) { BM = BM.filter((b) => b.u !== cur.url); toast('Bookmark hata diya'); }
  else { BM.unshift({ u: cur.url, t: cur.title || host(cur.url), ts: Date.now() }); toast('⭐ Bookmark save ho gaya'); }
  saveBm(); updStar(); renderBm();
}
$('star').onclick = toggleBm;
function renderBm() {
  const bar = $('bmbar');
  bar.classList.toggle('hide', !S.bmbar);
  if (!BM.length) { bar.innerHTML = '<span class="empty">⭐ Bookmarks yahan dikhenge — kisi page par star dabayein</span>'; return; }
  bar.innerHTML = '';
  BM.slice(0, 40).forEach((b) => {
    const a = document.createElement('a');
    a.title = b.t + '\n' + b.u;
    a.innerHTML = '<img src="' + esc(fav(b.u)) + '"><span>' + esc(b.t || host(b.u)) + '</span>';
    a.addEventListener('click', (e) => { if (e.ctrlKey) newTab(b.u, { bg: true }); else navigate(b.u); });
    a.addEventListener('auxclick', (e) => { if (e.button === 1) newTab(b.u, { bg: true }); });
    bar.appendChild(a);
  });
}

/* ---------------- Ad blocker ---------------- */
function updShield() { $('shield').classList.toggle('off', !S.adblock); $('shield').title = S.adblock ? 'Ad Blocker ON — click karke band karein' : 'Ad Blocker OFF'; }
$('shield').onclick = () => { S.adblock = !S.adblock; saveSet(); window.bt.adblock(S.adblock); updShield(); toast(S.adblock ? '🛡 Ad Blocker chalu' : 'Ad Blocker band'); };
window.bt.on('blocked', (n) => { const b = $('blk'); b.style.display = 'block'; b.textContent = n > 999 ? Math.floor(n / 1000) + 'k' : n; });

/* ---------------- Downloads ---------------- */
window.bt.on('dl', (d) => {
  const i = DL.findIndex((x) => x.id === d.id);
  if (i < 0) { DL.unshift(d); toast('⬇ Download shuru: ' + d.name); showDlPop(); }
  else { d.ts = DL[i].ts; DL[i] = d; }
  if (d.state === 'completed') toast('✅ Download pura: ' + d.name);
  else if (d.state === 'interrupted') toast('Download ruk gaya: ' + d.name);
  if (d.state !== 'progressing') saveDl();
  updDlRing(); if ($('dlpop').classList.contains('show')) renderDlPop(); if (panelKind === 'downloads') renderPanel();
});
function updDlRing() {
  const act = DL.filter((d) => d.state === 'progressing');
  const r = $('dlring');
  if (!act.length) { r.style.display = 'none'; return; }
  const tot = act.reduce((s, d) => s + (d.total || 0), 0), rec = act.reduce((s, d) => s + (d.received || 0), 0);
  r.style.display = 'block'; r.style.setProperty('--pc', (tot ? Math.round(rec / tot * 100) : 30) + '%');
}
function dlRow(d) {
  const pc = d.total ? Math.round(d.received / d.total * 100) : 0;
  let st = '', acts = '';
  if (d.state === 'progressing') { st = fmtSize(d.received) + (d.total ? ' / ' + fmtSize(d.total) + ' • ' + pc + '%' : '') + (d.paused ? ' • Ruka hua' : ''); acts = '<button class="act" data-x="' + (d.paused ? 'resume' : 'pause') + '">' + (d.paused ? '▶' : '⏸') + '</button><button class="del" data-x="cancel">✕</button>'; }
  else if (d.state === 'completed') { st = fmtSize(d.total || d.received) + ' • ' + host(d.url); acts = '<button class="act" data-x="open">Kholein</button><button class="act" data-x="show">Folder</button>'; }
  else st = d.state === 'cancelled' ? 'Cancel kiya' : 'Fail ho gaya';
  return '<div class="row" data-id="' + esc(d.id) + '"><img src="' + esc(fav(d.url)) + '"><div class="t"><b>' + esc(d.name) + '</b><small>' + esc(st) + '</small>' +
    (d.state === 'progressing' ? '<div class="bar2"><i style="width:' + pc + '%"></i></div>' : '') + '</div>' + acts + '</div>';
}
function bindDl(root) {
  root.querySelectorAll('.row[data-id]').forEach((r) => {
    const d = DL.find((x) => x.id === r.dataset.id); if (!d) return;
    r.querySelectorAll('[data-x]').forEach((b) => b.onclick = (e) => { e.stopPropagation(); window.bt.dl(d.id, b.dataset.x, d.path); });
    r.querySelector('.t').onclick = () => { if (d.state === 'completed') window.bt.dl(d.id, 'open', d.path); };
  });
}
function renderDlPop() {
  const p = $('dlpop');
  p.innerHTML = '<div class="h">Haal ke downloads<a id="dlall">Sab dekhein</a></div>' + (DL.length ? DL.slice(0, 5).map(dlRow).join('') : '<div class="none" style="padding:20px">Abhi koi download nahi</div>');
  bindDl(p);
  $('dlall').onclick = () => { closePops(); openPanel('downloads'); };
}
let dlPopT = 0;
function showDlPop() { closePops(); renderDlPop(); $('dlpop').classList.add('show'); clearTimeout(dlPopT); dlPopT = setTimeout(() => $('dlpop').classList.remove('show'), 4000); }
$('setbtn').onclick = () => openPanel('settings');
$('dlbtn').onclick = (e) => { e.stopPropagation(); const p = $('dlpop'); if (p.classList.contains('show')) { p.classList.remove('show'); return; } closePops(); renderDlPop(); p.classList.add('show'); clearTimeout(dlPopT); };

/* ---------------- Panels ---------------- */
let panelKind = null;
function openPanel(k) {
  closePops();
  panelKind = k;
  const PT = { history: ['hist', '#448AFF,#1A3FD8', 'History'], bookmarks: ['bm', '#FFD740,#FF9100', 'Bookmarks'], downloads: ['dl', '#64FFDA,#00897B', 'Downloads'], settings: ['logo', '', 'Settings'], about: ['info', '#00E5FF,#1E5BFF', 'Baatora ke baare me'] }[k];
  if (PT[0] === 'logo') $('ptitle').innerHTML = '<img class="ptitle-logo" src="logo.png" alt="">' + PT[2]; else
  $('ptitle').innerHTML = '<b class="mi ptitle-ic" style="--c:' + PT[1] + '"><svg><use href="#i-' + PT[0] + '"/></svg></b>' + PT[2];
  $('psearch').style.display = (k === 'history' || k === 'bookmarks' || k === 'downloads') ? '' : 'none';
  $('psearch').value = '';
  $('panel').classList.add('show');
  renderPanel();
  if ($('psearch').style.display === '') setTimeout(() => $('psearch').focus(), 30);
}
function closePanel() { $('panel').classList.remove('show'); panelKind = null; }
$('pclose').onclick = closePanel;
$('panel').addEventListener('mousedown', (e) => { if (e.target.id === 'panel') closePanel(); });
$('psearch').addEventListener('input', renderPanel);

function renderPanel() {
  const body = $('pbody'), q = $('psearch').value.trim().toLowerCase();
  const match = (x) => !q || (x.u || x.url || '').toLowerCase().includes(q) || (x.t || x.name || '').toLowerCase().includes(q);
  if (panelKind === 'history') {
    if (INCOG) { body.innerHTML = '<div class="none">🕶 Incognito me History save nahi hoti</div>'; return; }
    const list = HIST.filter(match).slice(0, 600);
    let h = '<div class="ptop"><button class="btn red" id="hclear">History saaf karein</button></div>', last = '';
    if (!list.length) h += '<div class="none">Koi history nahi mili</div>';
    list.forEach((x) => {
      const d = dayLabel(x.ts); if (d !== last) { h += '<div class="day">' + esc(d) + '</div>'; last = d; }
      h += '<div class="row" data-u="' + esc(x.u) + '" data-ts="' + x.ts + '"><span class="tm">' + fmtTime(x.ts) + '</span><img src="' + esc(fav(x.u)) + '"><div class="t"><b>' + esc(x.t || x.u) + '</b><small>' + esc(x.u) + '</small></div><button class="del">Hatayein</button></div>';
    });
    body.innerHTML = h;
    $('hclear').onclick = () => { if (confirm('Poori history delete karein?')) { HIST = []; saveHist(); renderPanel(); toast('History saaf ho gayi'); } };
    body.querySelectorAll('.row').forEach((r) => {
      r.querySelector('.t').onclick = (e) => { closePanel(); if (e.ctrlKey) newTab(r.dataset.u, { bg: true }); else navigate(r.dataset.u); };
      r.querySelector('.del').onclick = () => { const ts = +r.dataset.ts; HIST = HIST.filter((x) => !(x.ts === ts && x.u === r.dataset.u)); saveHist(); r.remove(); };
    });
  } else if (panelKind === 'bookmarks') {
    const list = BM.filter(match);
    let h = '<div class="ptop"><button class="btn" id="bmtog">' + (S.bmbar ? 'Bookmarks bar chhupayein' : 'Bookmarks bar dikhayein') + '</button></div>';
    if (!list.length) h += '<div class="none">Koi bookmark nahi. Kisi bhi page par ⭐ dabakar save karein.</div>';
    list.forEach((x) => { h += '<div class="row" data-u="' + esc(x.u) + '"><img src="' + esc(fav(x.u)) + '"><div class="t"><b>' + esc(x.t || x.u) + '</b><small>' + esc(x.u) + '</small></div><button class="act ren">Naam badlein</button><button class="del">Hatayein</button></div>'; });
    body.innerHTML = h;
    $('bmtog').onclick = () => { S.bmbar = !S.bmbar; saveSet(); renderBm(); renderPanel(); };
    body.querySelectorAll('.row').forEach((r) => {
      const u = r.dataset.u;
      r.querySelector('.t').onclick = (e) => { closePanel(); if (e.ctrlKey) newTab(u, { bg: true }); else navigate(u); };
      r.querySelector('.del').onclick = () => { BM = BM.filter((b) => b.u !== u); saveBm(); renderBm(); updStar(); r.remove(); };
      r.querySelector('.ren').onclick = () => {
        const b = BM.find((x) => x.u === u); if (!b) return;
        const tEl = r.querySelector('.t b');
        const inp = document.createElement('input'); inp.value = b.t || ''; inp.style.cssText = 'width:100%;background:#040A26;color:#fff;border:1px solid #00E5FF;border-radius:8px;padding:4px 8px;font:inherit';
        tEl.replaceWith(inp); inp.focus(); inp.select();
        const done = () => { b.t = inp.value.trim() || b.t; saveBm(); renderBm(); renderPanel(); };
        inp.onkeydown = (e) => { if (e.key === 'Enter') done(); if (e.key === 'Escape') renderPanel(); };
        inp.onblur = done; inp.onclick = (e) => e.stopPropagation();
      };
    });
  } else if (panelKind === 'downloads') {
    const list = DL.filter(match);
    body.innerHTML = '<div class="ptop"><button class="btn pri" id="dlf">📁 Downloads folder kholein</button><button class="btn" id="dlc">List saaf karein</button></div>' + (list.length ? list.map(dlRow).join('') : '<div class="none">Abhi tak koi download nahi</div>');
    bindDl(body);
    $('dlf').onclick = () => window.bt.dl('', 'folder');
    $('dlc').onclick = () => { DL = DL.filter((d) => d.state === 'progressing'); saveDl(); renderPanel(); };
  } else if (panelKind === 'settings') {
    const sw = (k, t, s, i) => '<div class="set">' + i + '<div class="t"><b>' + t + '</b><small>' + s + '</small></div><div class="sw ' + (S[k] ? 'on' : '') + '" data-k="' + k + '"></div></div>';
    body.innerHTML =
      '<div class="brandcard"><img src="logo.png" alt=""><div class="t"><b>Baatora</b><small id="sver">Tez. Surakshit. Apna Browser.</small></div><span class="flag">' + FLAG_SVG + 'Made in India</span></div>' +
      '<div class="set"><b class="mi" style="--c:#FF8A00,#1E5BFF"><svg><use href="#i-sun"/></svg></b><div class="t"><b>Browser ka rang (Theme)</b><small>Upar ki patti, menu aur Home page ka rang chunein</small></div><div class="themes">' + Object.keys(THEMES).filter((k) => k !== 'incog').map((k) => '<div class="th' + ((S.theme || 'light') === k ? ' on' : '') + '" data-th="' + k + '" style="--b:' + THEMES[k].bar + ';--t:' + THEMES[k].tool + '"><i></i><span>' + THEMES[k].n + '</span></div>').join('') + '</div></div>' +
      '<div class="set"><b class="mi" style="--c:#00E5FF,#00838F"><svg><use href="#i-zoom"/></svg></b><div class="t"><b>Search engine</b><small>Address bar aur Home page se search</small></div><select id="seng">' + Object.keys(ENG).map((k) => '<option value="' + k + '"' + (S.engine === k ? ' selected' : '') + '>' + ENGN[k] + '</option>').join('') + '</select></div>' +
      sw('adblock', 'Ad Blocker', 'Ads, popups aur tracking band (YouTube ads bhi)', '<b class="mi" style="--c:#69F0AE,#00A152"><svg><use href="#i-shield"/></svg></b>') +
      sw('night', 'Night mode', 'Har website ko dark karke dikhaye', '<b class="mi" style="--c:#7C4DFF,#311B92"><svg><use href="#i-moon"/></svg></b>') +
      sw('bmbar', 'Bookmarks bar', 'Address bar ke neeche bookmarks dikhayein', '<b class="mi" style="--c:#FFD740,#FF6D00"><svg><use href="#i-bm"/></svg></b>') +
      sw('restore', 'Purane tabs wapas kholein', 'Baatora band karke kholne par pichhle tabs khulenge', '<b class="mi" style="--c:#40C4FF,#304FFE"><svg><use href="#i-restore"/></svg></b>') +
      '<div class="set"><b class="mi" style="--c:#FF8A00,#FFC107"><svg><use href="#i-globe"/></svg></b><div class="t"><b>Baatora ko Default browser banayein</b><small>Har link Baatora me khulega (Windows Settings khulegi — wahan Baatora chunein)</small></div><button class="btn pri" id="sdef">Default banayein</button></div>' +
      '<div class="set"><b class="mi" style="--c:#FF5252,#B71C1C"><svg><use href="#i-broom"/></svg></b><div class="t"><b>Browsing data saaf karein</b><small>History, cache, cookies (login bhi hat jayega)</small></div><button class="btn" id="sch">History</button><button class="btn" id="scc">Cache</button><button class="btn red" id="sck">Cookies</button></div>' +
      '<div class="set"><b class="mi" style="--c:#64FFDA,#00897B"><svg><use href="#i-folder"/></svg></b><div class="t"><b>Downloads folder</b><small id="sdlp">…</small></div><button class="btn" id="sdlo">Kholein</button></div>' +
      '<div class="set"><b class="mi" style="--c:#90A4AE,#455A64"><svg><use href="#i-key"/></svg></b><div class="t"><b>Keyboard shortcuts</b><small>Ctrl+T naya tab • Ctrl+W band • Ctrl+Shift+T band tab wapas • Ctrl+L address bar • Ctrl+F khojein • Ctrl+D bookmark • Ctrl+H history • Ctrl+J downloads • F11 full screen • Ctrl+Shift+N incognito</small></div></div>';
    body.querySelectorAll('.sw').forEach((s) => s.onclick = () => {
      const k = s.dataset.k; S[k] = !S[k]; saveSet(); s.classList.toggle('on', S[k]);
      if (k === 'adblock') { window.bt.adblock(S.adblock); updShield(); }
      if (k === 'bmbar') renderBm();
      if (k === 'night') tabs.forEach((t) => applyNight(t, S.night));
    });
    body.querySelectorAll('.th').forEach((el) => el.onclick = () => { S.theme = el.dataset.th; saveSet(); applyTheme(); body.querySelectorAll('.th').forEach((x) => x.classList.toggle('on', x === el)); toast('🎨 Rang: ' + THEMES[S.theme].n); });
    $('seng').onchange = (e) => { S.engine = e.target.value; saveSet(); applyTheme(); toast('Search engine: ' + ENGN[S.engine]); };
    $('sdef').onclick = () => window.bt.defaultBrowser();
    $('sch').onclick = () => { HIST = []; saveHist(); toast('History saaf ho gayi'); };
    $('scc').onclick = async () => { await window.bt.clearData({ cache: true }); toast('Cache saaf ho gaya'); };
    $('sck').onclick = async () => { if (!confirm('Sab cookies aur site data delete karein? Websites se logout ho jayenge.')) return; await window.bt.clearData({ cookies: true }); toast('Cookies saaf ho gayi'); };
    $('sdlo').onclick = () => window.bt.dl('', 'folder');
    window.bt.info().then((i) => { const e = $('sdlp'); if (e) e.textContent = i.downloads; const v = $('sver'); if (v) v.textContent = 'Version ' + i.version + ' • Created by Anil Yadav'; });
  } else if (panelKind === 'about') {
    body.innerHTML = '<div class="about">' +
      '<img src="logo.png" alt=""><h1>Baatora</h1><div class="abtag">Tez. Surakshit. Apna Browser.</div><p id="aver" class="abver"></p>' +
      '<div class="story"><div class="maker2"><div class="av">AY</div><div><small>Banane wale</small><b>Anil Yadav</b></div></div>' +
      '<p>Anil Yadav mobile ki duniya se jude ek mehnati vyapari hain. Apni dukaan <b>S.R Mobile Shop</b> par wo roz logon ki mobile se judi har zaroorat poori karte hain — naya phone ho, recharge ho ya repair.</p>' +
      '<p>Technology ka shauk unhe apps banane tak le aaya. Unka maanna hai ki internet sabke liye aasaan, surakshit aur apni bhasha me hona chahiye. Isi soch se janma <b>Baatora</b>.</p></div>' +
      '<div class="story future2"><h3>🚀 Baatora ka Bhavishya</h3>' +
      '<p>Baatora sirf ek browser nahi, ek sapna hai — <b>Bharat ka apna browser</b>.</p>' +
      '<p>Aane wale dino me Baatora har ghar, har dukaan aur har mobile-PC tak pahunchega. Apni bhasha me bolkar khojna, phone aur PC ka ek saath judna, aur bina ads ke surakshit internet — ye safar abhi shuru hua hai.</p>' +
      '<p class="big">Aaj ek chhoti si shuruaat… kal crore Bharatiyon ka bharosa.</p></div>' +
      '<div class="abfoot"><span class="flag">' + FLAG_SVG + 'Made in India</span><span>Dil se banaya, Bharat ke liye ❤️</span></div></div>';
    window.bt.info().then((i) => { $('aver').textContent = 'Version ' + i.version; });
  }
}

/* ---------------- Find in page ---------------- */
let findOpen = false;
function openFind() { if (!cur) return; findOpen = true; $('findbar').classList.add('show'); $('findq').focus(); $('findq').select(); if ($('findq').value) doFind(true); }
function closeFind() { findOpen = false; $('findbar').classList.remove('show'); try { cur.wv.stopFindInPage('clearSelection'); } catch (e) {} $('findc').textContent = '0/0'; }
function doFind(fwd, next) { const q = $('findq').value; if (!q) { try { cur.wv.stopFindInPage('clearSelection'); } catch (e) {} $('findc').textContent = '0/0'; return; } cur.wv.findInPage(q, { forward: fwd !== false, findNext: !!next }); }
$('findq').addEventListener('input', () => doFind(true));
$('findq').addEventListener('keydown', (e) => { if (e.key === 'Enter') doFind(!e.shiftKey, true); if (e.key === 'Escape') closeFind(); });
$('findn').onclick = () => doFind(true, true);
$('findp').onclick = () => doFind(false, true);
$('findx').onclick = closeFind;

/* ---------------- Page tools ---------------- */
function setZoom(z) { if (!cur) return; cur.zoom = Math.max(0.25, Math.min(5, Math.round(z * 100) / 100)); cur.wv.setZoomFactor(cur.zoom); $('zval').textContent = Math.round(cur.zoom * 100) + '%'; toast('Zoom ' + Math.round(cur.zoom * 100) + '%'); }
const NIGHT_CSS = 'html{filter:invert(.9) hue-rotate(180deg)!important;background:#fff!important}img,video,picture,canvas,iframe,svg image,[style*="background-image"]{filter:invert(1) hue-rotate(180deg)!important}';
async function applyNight(t, on) {
  if (!t.ready || isHome(t.url)) return;
  try {
    if (on && !t.nightKey) t.nightKey = await t.wv.insertCSS(NIGHT_CSS);
    else if (!on && t.nightKey) { await t.wv.removeInsertedCSS(t.nightKey); t.nightKey = null; }
  } catch (e) { t.nightKey = null; }
}
const READER_JS = `(function(){var a=document.querySelector('article')||document.querySelector('main')||document.querySelector('[role=main]')||document.body;
var t=document.title;var c=a.cloneNode(true);c.querySelectorAll('script,style,nav,aside,footer,header,form,iframe,button,.ad,.ads,[class*=share],[class*=comment],[id*=comment]').forEach(function(e){e.remove()});
document.documentElement.innerHTML='<head><meta charset=utf-8><title></title><style>body{max-width:760px;margin:40px auto;padding:0 22px;font:19px/1.75 Georgia,serif;background:#FBF7EE;color:#222}h1{font:700 32px/1.3 "Segoe UI",sans-serif;margin-bottom:24px}img,video{max-width:100%;height:auto;border-radius:10px}a{color:#1E5BFF}pre{white-space:pre-wrap}</style></head><body><h1></h1><div id=rd></div></body>';
document.title=t;document.querySelector('h1').textContent=t;document.getElementById('rd').appendChild(c);})()`;

/* ---------------- baatora:// links (Home page) ---------------- */
function baatora(u, wcId) {
  let p; try { p = new URL(u); } catch (e) { return; }
  const what = (p.hostname || p.pathname.replace(/^\/+/, '')).toLowerCase();
  const t = tabs.find((x) => x.wcId === wcId) || cur;
  switch (what) {
    case 'downloads': case 'history': case 'bookmarks': case 'settings': case 'about': openPanel(what); break;
    case 'incognito': window.bt.newWindow({ incog: true }); break;
    case 'home': goHome(); break;
    case 'vpn': toast('🛡 Free VPN abhi sirf Baatora Android app me hai'); break;
    case 'notifications': toast('🔔 Koi nayi notification nahi'); break;
    case 'voice': addr.focus(); toast('🎤 Voice search PC par jald aayega — abhi type karke khojein'); break;
    case 'clip': { const v = p.searchParams.get('u'); if (v && t) { t.wv.loadURL(toUrl(v)).catch(() => {}); } break; }
    case 'clipx': break;
    default: toast('Ye feature PC version me jald aayega');
  }
}
window.bt.on('baatora', baatora);

/* ---------------- Menu ---------------- */
function closePops() { $('menu').classList.remove('show'); $('dlpop').classList.remove('show'); sugg.style.display = 'none'; }
$('menubtn').onclick = (e) => { e.stopPropagation(); const m = $('menu'); const on = m.classList.contains('show'); closePops(); if (!on) { $('zval').textContent = Math.round((cur ? cur.zoom : 1) * 100) + '%'; m.classList.add('show'); } };
document.addEventListener('mousedown', (e) => { if (!e.target.closest('#menu,#menubtn,#dlpop,#dlbtn,#omni')) closePops(); });
$('menu').addEventListener('click', (e) => {
  const b = e.target.closest('[data-a]'); if (!b) return;
  const a = b.dataset.a;
  if (!['zin', 'zout'].includes(a)) closePops();
  action(a);
});

function action(a) {
  const t = cur;
  switch (a) {
    case 'newtab': newTab(); break;
    case 'newwin': window.bt.newWindow({}); break;
    case 'incog': window.bt.newWindow({ incog: true }); break;
    case 'history': case 'downloads': case 'bookmarks': case 'settings': case 'about': openPanel(a); break;
    case 'zin': setZoom((t ? t.zoom : 1) + 0.1); break;
    case 'zout': setZoom((t ? t.zoom : 1) - 0.1); break;
    case 'zreset': setZoom(1); break;
    case 'fs': window.bt.fullscreen(); break;
    case 'find': openFind(); break;
    case 'print': if (t) t.wv.print(); break;
    case 'save': if (t && t.wcId) window.bt.savePage(t.wcId).then((ok) => { if (ok) toast('💾 Page save ho gaya'); }); break;
    case 'desktop': if (t) { t.mobile = !t.mobile; t.wv.setUserAgent(t.mobile ? MOBILE_UA : navigator.userAgent.replace(/\sElectron\/\S+/, '').replace(/\sBaatora\/\S+/i, '').replace(/\sbaatora-pc\/\S+/i, '')); t.wv.reload(); toast(t.mobile ? '📱 Mobile site' : '🖥 Desktop site'); } break;
    case 'reader': if (t && !isHome(t.url)) t.wv.executeJavaScript(READER_JS).catch(() => {}); break;
    case 'night': S.night = !S.night; saveSet(); tabs.forEach((x) => applyNight(x, S.night)); toast(S.night ? '🌙 Night mode chalu' : 'Night mode band'); break;
    case 'devtools': if (t) { if (t.wv.isDevToolsOpened()) t.wv.closeDevTools(); else t.wv.openDevTools(); } break;
    case 'exit': window.bt.quit(); break;
  }
}

/* ---------------- Keyboard shortcuts ---------------- */
function shortcut(c) {
  const t = cur;
  const m = /^ctrl\+([1-9])$/.exec(c);
  if (m) { const n = +m[1]; select(n === 9 ? tabs[tabs.length - 1] : tabs[n - 1]); return true; }
  switch (c) {
    case 'ctrl+t': newTab(); break;
    case 'ctrl+w': if (t) closeTab(t); break;
    case 'ctrl+n': action('newwin'); break;
    case 'ctrl+shift+n': action('incog'); break;
    case 'ctrl+shift+t': { const u = closed.pop(); if (u) newTab(u); break; }
    case 'ctrl+l': case 'alt+d': case 'f6': addr.focus(); addr.select(); break;
    case 'ctrl+r': case 'f5': if (t) t.wv.reload(); break;
    case 'ctrl+f': openFind(); break;
    case 'ctrl+h': openPanel('history'); break;
    case 'ctrl+j': openPanel('downloads'); break;
    case 'ctrl+shift+b': S.bmbar = !S.bmbar; saveSet(); renderBm(); break;
    case 'ctrl+d': toggleBm(); break;
    case 'ctrl+p': action('print'); break;
    case 'ctrl+=': case 'ctrl++': action('zin'); break;
    case 'ctrl+-': action('zout'); break;
    case 'ctrl+0': action('zreset'); break;
    case 'ctrl+tab': if (tabs.length > 1) select(tabs[(tabs.indexOf(t) + 1) % tabs.length]); break;
    case 'ctrl+shift+tab': if (tabs.length > 1) select(tabs[(tabs.indexOf(t) - 1 + tabs.length) % tabs.length]); break;
    case 'alt+arrowleft': try { t.wv.goBack(); } catch (e) {} break;
    case 'alt+arrowright': try { t.wv.goForward(); } catch (e) {} break;
    case 'alt+home': goHome(); break;
    case 'f11': window.bt.fullscreen(); break;
    case 'f12': case 'ctrl+shift+i': action('devtools'); break;
    case 'ctrl+shift+delete': openPanel('settings'); break;
    case 'ctrl+q': window.bt.quit(); break;
    case 'save-page': action('save'); break;
    case 'escape':
      if (findOpen) closeFind();
      else if (panelKind) closePanel();
      else if ($('menu').classList.contains('show') || $('dlpop').classList.contains('show')) closePops();
      else if (t && t.loading) t.wv.stop();
      break;
    default: return false;
  }
  return true;
}
window.bt.on('shortcut', shortcut);
document.addEventListener('keydown', (e) => {
  const k = e.key.toLowerCase(), c = e.ctrlKey || e.metaKey;
  let combo = null;
  if (c && e.shiftKey) combo = 'ctrl+shift+' + k;
  else if (c) combo = 'ctrl+' + k;
  else if (e.altKey) combo = 'alt+' + k;
  else if (/^f\d+$/.test(k)) combo = k;
  else if (k === 'escape' && document.activeElement !== addr && document.activeElement !== $('findq')) combo = 'escape';
  if (!combo) return;
  const typing = /^(input|textarea|select)$/i.test(document.activeElement.tagName);
  if (typing && /^ctrl\+[acvxyz]$/.test(combo)) return;
  if (typing && combo === 'ctrl+shift+z') return;
  if (shortcut(combo)) e.preventDefault();
});

window.bt.on('open-tab', (u, bg) => { if (u) newTab(u, { bg: !!bg }); });
window.bt.on('search-tab', (s) => newTab(search(s), { bg: false }));
window.bt.on('fullscreen', (on) => document.body.classList.toggle('fs', !!on));

/* ---------------- Start ---------------- */
window.bt.adblock(S.adblock);
applyTheme();
updShield(); renderBm();
(function start() {
  const startUrl = Q.get('url');
  const sess = (!INCOG && S.restore) ? load('bt_session', null) : null;
  if (sess && Array.isArray(sess.tabs) && sess.tabs.length && !(sess.tabs.length === 1 && isHome(sess.tabs[0]) && startUrl)) {
    sess.tabs.slice(0, 30).forEach((u) => newTab(isHome(u) ? homeUrl() : u, { bg: true }));
    select(tabs[Math.max(0, Math.min(tabs.length - 1, sess.cur | 0))]);
    if (startUrl) newTab(startUrl);
  } else newTab(startUrl || homeUrl());
  if (INCOG) toast('🕶 Incognito: history, cookies save nahi honge');
})();
