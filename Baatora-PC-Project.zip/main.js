// Baatora Browser — PC (Windows) version
// Made in India • Created by Anil Yadav, Thane
const { app, BrowserWindow, session, ipcMain, Menu, clipboard, shell, webContents, nativeTheme, dialog } = require('electron');
const path = require('path');
const fs = require('fs');
const { pathToFileURL } = require('url');

app.setName('Baatora');
if (process.platform === 'win32') app.setAppUserModelId('com.baatora.browser.pc');

const NORMAL = 'persist:baatora';
const INCOG = 'baatora-incognito';
const HOME = pathToFileURL(path.join(__dirname, 'pages', 'home-pc.html')).href;

let adblockOn = true;
const blocked = new Map(); // host webContents id -> count

const AD_HOSTS = /(^|\.)(doubleclick\.net|googlesyndication\.com|googleadservices\.com|adservice\.google\.[a-z.]+|pagead2\.googlesyndication\.com|google-analytics\.com|exoclick\.com|exosrv\.com|exdynsrv\.com|juicyads\.com|trafficstars\.com|tsyndicate\.com|clickadu\.com|hilltopads\.net|adcash\.com|popcash\.net|propellerads\.com|onclkds\.com|clickaine\.com|realsrv\.com|magsrv\.com|adsterra\.com|a-ads\.com|adskeeper\.com|richpush\.co|admaven\.com|ad-maven\.com|bidvertiser\.com|plugrush\.com|yllix\.com|popads\.net|monetag\.com|profitableratecpm\.com|highperformanceformat\.com|effectivegatecpm\.com|oclasrv\.com|taboola\.com|outbrain\.com|mgid\.com|revcontent\.com|zedo\.com|criteo\.com|criteo\.net|moatads\.com|adnxs\.com|amazon-adsystem\.com|scorecardresearch\.com|quantserve\.com|adform\.net|rubiconproject\.com|pubmatic\.com|openx\.net|smartadserver\.com|33across\.com|media\.net|yieldmo\.com|inmobi\.com|vungle\.com|unityads\.unity3d\.com|applovin\.com|chartboost\.com)$/i;

// YouTube ke ad wale requests
const YT_ADS = /^https?:\/\/(www\.|m\.)?youtube\.com\/(api\/stats\/ads|pagead\/|ptracking|get_midroll_info|youtubei\/v1\/player\/ad_break)|^https?:\/\/[^/]*\.(doubleclick\.net|googleadservices\.com)\/|^https?:\/\/(www\.)?google\.com\/(pagead|ads)\//i;

// ---------- Single instance (link double-click se naya tab) ----------
const gotLock = app.requestSingleInstanceLock();
if (!gotLock) app.quit();
app.on('second-instance', (_e, argv) => {
  const url = urlFromArgs(argv);
  let w = BrowserWindow.getFocusedWindow() || BrowserWindow.getAllWindows().find(x => !x.__incog) || null;
  if (!w) { createWindow({ url }); return; }
  if (w.isMinimized()) w.restore();
  w.focus();
  if (url) w.webContents.send('open-tab', url);
});

function urlFromArgs(argv) {
  const args = argv.slice(app.isPackaged ? 1 : 2);
  for (const a of args) {
    if (!a || a.startsWith('-')) continue;
    if (/^(https?|ftp|file):/i.test(a)) return a;
    try { if (fs.existsSync(a) && fs.statSync(a).isFile()) return pathToFileURL(path.resolve(a)).href; } catch (e) {}
  }
  return null;
}

// ---------- Session setup (adblock, downloads, UA, permissions) ----------
const readySessions = new Set();
function setupSession(part) {
  const ses = session.fromPartition(part);
  if (readySessions.has(part)) return ses;
  readySessions.add(part);

  // Chrome jaisa user-agent (taaki sites sahi chalein)
  ses.setUserAgent(ses.getUserAgent().replace(/\sElectron\/\S+/, '').replace(/\sBaatora\/\S+/i, '').replace(/\sbaatora-pc\/\S+/i, ''));

  ses.webRequest.onBeforeRequest({ urls: ['*://*/*'] }, (details, cb) => {
    if (adblockOn && details.resourceType !== 'mainFrame') {
      try {
        const h = new URL(details.url).hostname;
        if (AD_HOSTS.test(h) || YT_ADS.test(details.url)) {
          const wc = details.webContents;
          const host = wc && wc.hostWebContents;
          if (host && !host.isDestroyed()) {
            const n = (blocked.get(host.id) || 0) + 1;
            blocked.set(host.id, n);
            host.send('blocked', n);
          }
          return cb({ cancel: true });
        }
      } catch (e) {}
    }
    cb({});
  });

  ses.setPermissionRequestHandler((_wc, perm, cb) => {
    cb(['fullscreen', 'media', 'clipboard-read', 'clipboard-sanitized-write', 'pointerLock', 'geolocation', 'notifications', 'openExternal', 'window-management'].includes(perm));
  });

  ses.on('will-download', (_e, item, wc) => {
    const host = (wc && wc.hostWebContents) || wc;
    const dir = app.getPath('downloads');
    let name = item.getFilename() || 'download';
    let p = path.join(dir, name), i = 1;
    const ext = path.extname(name), base = path.basename(name, ext);
    while (fs.existsSync(p)) p = path.join(dir, `${base} (${i++})${ext}`);
    item.setSavePath(p);
    const id = Date.now() + '' + Math.floor(Math.random() * 1000);
    downloads.set(id, item);
    const send = (state) => {
      if (!host || host.isDestroyed()) return;
      host.send('dl', { id, name: path.basename(p), path: p, url: item.getURL(), total: item.getTotalBytes(), received: item.getReceivedBytes(), state, paused: item.isPaused(), ts: Date.now() });
    };
    send('progressing');
    item.on('updated', (_ev, state) => send(state));
    item.once('done', (_ev, state) => { send(state); downloads.delete(id); });
  });
  return ses;
}
const downloads = new Map();

// ---------- Windows ----------
function createWindow({ incog = false, url = null } = {}) {
  setupSession(incog ? INCOG : NORMAL);
  const w = new BrowserWindow({
    width: 1280, height: 820, minWidth: 520, minHeight: 400,
    backgroundColor: incog ? '#1A0B3A' : '#FFFFFF',
    title: incog ? 'Baatora Incognito' : 'Baatora',
    icon: path.join(__dirname, 'ui', 'logo.png'),
    titleBarStyle: 'hidden',
    titleBarOverlay: { color: incog ? '#1A0B3A' : '#DFE3E8', symbolColor: incog ? '#FFFFFF' : '#1F2937', height: 40 },
    show: false,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      webviewTag: true,
      spellcheck: true
    }
  });
  w.__incog = incog;
  const q = { incog: incog ? '1' : '0', home: HOME };
  if (url) q.url = url;
  w.loadFile(path.join(__dirname, 'ui', 'index.html'), { query: q });
  w.once('ready-to-show', () => { w.show(); });
  w.on('enter-full-screen', () => w.webContents.send('fullscreen', true));
  w.on('leave-full-screen', () => w.webContents.send('fullscreen', false));
  w.webContents.setWindowOpenHandler(() => ({ action: 'deny' }));
  return w;
}

// ---------- Webview (tab) handling ----------
app.on('web-contents-created', (_e, wc) => {
  wc.on('will-attach-webview', (_ev, prefs, params) => {
    prefs.preload = path.join(__dirname, 'guest-preload.js');
    prefs.nodeIntegration = false;
    prefs.contextIsolation = true;
    prefs.sandbox = true;
    if (params.partition !== NORMAL && params.partition !== INCOG) params.partition = NORMAL;
  });

  if (wc.getType() !== 'webview') return;

  wc.setWindowOpenHandler(({ url, disposition }) => {
    const host = wc.hostWebContents;
    if (host && !host.isDestroyed()) host.send('open-tab', url, disposition === 'background-tab');
    return { action: 'deny' };
  });

  let lastB = '', lastT = 0;
  const onNav = (ev, url) => {
    if (typeof url === 'object' && url) url = url.url;
    if (url && /^baatora:/i.test(url)) {
      ev.preventDefault();
      const now = Date.now();
      if (url === lastB && now - lastT < 600) return;
      lastB = url; lastT = now;
      const host = wc.hostWebContents;
      if (host && !host.isDestroyed()) host.send('baatora', url, wc.id);
    }
  };
  wc.on('will-navigate', onNav);
  wc.on('will-frame-navigate', (ev) => onNav(ev, ev.url));

  // Keyboard shortcuts page ke andar se bhi chalein
  wc.on('before-input-event', (ev, input) => {
    if (input.type !== 'keyDown') return;
    const k = (input.key || '').toLowerCase();
    const c = input.control || input.meta;
    let combo = null;
    if (c && input.shift && ['n', 't', 'b', 'delete', 'tab', 'i'].includes(k)) combo = 'ctrl+shift+' + k;
    else if (c && ['t', 'w', 'n', 'l', 'r', 'f', 'h', 'j', 'd', 'p', 'tab', '=', '+', '-', '0', 'q', '1', '2', '3', '4', '5', '6', '7', '8', '9'].includes(k)) combo = 'ctrl+' + k;
    else if (input.alt && ['arrowleft', 'arrowright', 'home', 'd'].includes(k)) combo = 'alt+' + k;
    else if (['f5', 'f6', 'f11', 'f12'].includes(k)) combo = k;
    else if (k === 'escape') combo = 'escape';
    if (!combo) return;
    if (combo === 'escape') { const host = wc.hostWebContents; if (host) host.send('shortcut', combo); return; }
    ev.preventDefault();
    const host = wc.hostWebContents;
    if (host && !host.isDestroyed()) host.send('shortcut', combo);
  });

  // Right-click menu
  wc.on('context-menu', (_ev, p) => {
    const host = wc.hostWebContents;
    const send = (...a) => { if (host && !host.isDestroyed()) host.send(...a); };
    const t = [];
    if (p.linkURL) {
      t.push({ label: 'Link naye tab me kholein', click: () => send('open-tab', p.linkURL, true) });
      t.push({ label: 'Link Incognito window me kholein', click: () => createWindow({ incog: true, url: p.linkURL }) });
      t.push({ label: 'Link copy karein', click: () => clipboard.writeText(p.linkURL) });
      t.push({ label: 'Link download karein', click: () => wc.downloadURL(p.linkURL) });
      t.push({ type: 'separator' });
    }
    if (p.mediaType === 'image' && p.srcURL) {
      t.push({ label: 'Photo naye tab me kholein', click: () => send('open-tab', p.srcURL, true) });
      t.push({ label: 'Photo save karein', click: () => wc.downloadURL(p.srcURL) });
      t.push({ label: 'Photo copy karein', click: () => wc.copyImageAt(p.x, p.y) });
      t.push({ label: 'Photo ka link copy karein', click: () => clipboard.writeText(p.srcURL) });
      t.push({ type: 'separator' });
    }
    if ((p.mediaType === 'video' || p.mediaType === 'audio') && p.srcURL && !p.srcURL.startsWith('blob:')) {
      t.push({ label: (p.mediaType === 'video' ? 'Video' : 'Audio') + ' download karein', click: () => wc.downloadURL(p.srcURL) });
      t.push({ type: 'separator' });
    }
    if (p.selectionText && p.selectionText.trim()) {
      const s = p.selectionText.trim();
      t.push({ label: 'Copy', role: 'copy' });
      t.push({ label: `"${s.length > 24 ? s.slice(0, 24) + '…' : s}" Google par khojein`, click: () => send('search-tab', s) });
      t.push({ type: 'separator' });
    }
    if (p.isEditable) {
      if (p.misspelledWord && p.dictionarySuggestions.length) {
        p.dictionarySuggestions.slice(0, 4).forEach(sg => t.push({ label: sg, click: () => wc.replaceMisspelling(sg) }));
        t.push({ type: 'separator' });
      }
      t.push({ label: 'Undo', role: 'undo' }, { label: 'Cut', role: 'cut' }, { label: 'Copy', role: 'copy' }, { label: 'Paste', role: 'paste' }, { label: 'Sab select karein', role: 'selectAll' });
      t.push({ type: 'separator' });
    }
    if (!p.linkURL && !p.isEditable && !(p.selectionText && p.selectionText.trim())) {
      t.push({ label: 'Peeche', enabled: wc.navigationHistory.canGoBack(), click: () => wc.navigationHistory.goBack() });
      t.push({ label: 'Aage', enabled: wc.navigationHistory.canGoForward(), click: () => wc.navigationHistory.goForward() });
      t.push({ label: 'Reload', click: () => wc.reload() });
      t.push({ type: 'separator' });
      t.push({ label: 'Page save karein…', click: () => send('shortcut', 'save-page') });
      t.push({ label: 'Print…', click: () => wc.print() });
      t.push({ label: 'Page ka link copy karein', click: () => clipboard.writeText(wc.getURL()) });
      t.push({ type: 'separator' });
    }
    t.push({ label: 'Inspect (Developer)', click: () => wc.inspectElement(p.x, p.y) });
    Menu.buildFromTemplate(t).popup({ window: BrowserWindow.fromWebContents(host || wc) || undefined });
  });
});

// ---------- IPC from UI ----------
ipcMain.handle('asset', (_e, name) => {
  if (!/^[a-z0-9_-]+\.js$/i.test(name)) return '';
  try { return fs.readFileSync(path.join(__dirname, 'pages', name), 'utf8'); } catch (e) { return ''; }
});
ipcMain.on('adblock', (_e, on) => { adblockOn = !!on; });
ipcMain.on('new-window', (_e, opts) => createWindow(opts || {}));
ipcMain.on('dl-action', (_e, id, act, p) => {
  const item = downloads.get(id);
  if (act === 'cancel' && item) item.cancel();
  else if (act === 'pause' && item) item.pause();
  else if (act === 'resume' && item && item.canResume()) item.resume();
  else if (act === 'open' && p) shell.openPath(p);
  else if (act === 'show' && p) shell.showItemInFolder(p);
  else if (act === 'folder') shell.openPath(app.getPath('downloads'));
});
ipcMain.on('default-browser', () => {
  shell.openExternal('ms-settings:defaultapps?registeredAppUser=Baatora').catch(() => shell.openExternal('ms-settings:defaultapps'));
});
ipcMain.on('open-external', (_e, url) => { if (/^(https?|mailto|tel):/i.test(url)) shell.openExternal(url); });
ipcMain.handle('clear-data', async (_e, what) => {
  const ses = session.fromPartition(NORMAL);
  if (what.cache) await ses.clearCache();
  if (what.cookies) await ses.clearStorageData({ storages: ['cookies', 'localstorage', 'indexdb', 'serviceworkers', 'cachestorage', 'websql', 'filesystem'] });
  return true;
});
ipcMain.handle('save-page', async (e, wcId) => {
  const wc = webContents.fromId(wcId);
  if (!wc) return false;
  const win = BrowserWindow.fromWebContents(e.sender);
  const safe = (wc.getTitle() || 'page').replace(/[\\/:*?"<>|]+/g, ' ').slice(0, 80);
  const r = await dialog.showSaveDialog(win, { defaultPath: path.join(app.getPath('downloads'), safe + '.html'), filters: [{ name: 'Web page', extensions: ['html'] }] });
  if (r.canceled || !r.filePath) return false;
  await wc.savePage(r.filePath, 'HTMLComplete');
  return true;
});
ipcMain.on('title-color', (e, color, symbolColor) => {
  const w = BrowserWindow.fromWebContents(e.sender);
  if (w && w.setTitleBarOverlay) { try { w.setTitleBarOverlay({ color, symbolColor: symbolColor || '#FFFFFF', height: 40 }); } catch (x) {} }
});
ipcMain.on('bt-adblock-on', (e) => { e.returnValue = adblockOn; });
ipcMain.on('fullscreen', (e, on) => { const w = BrowserWindow.fromWebContents(e.sender); if (w) w.setFullScreen(on === undefined ? !w.isFullScreen() : !!on); });
ipcMain.on('close-window', (e) => { const w = BrowserWindow.fromWebContents(e.sender); if (w) w.close(); });
ipcMain.on('quit', () => app.quit());
ipcMain.handle('info', () => ({ version: app.getVersion(), electron: process.versions.electron, chrome: process.versions.chrome, downloads: app.getPath('downloads') }));

// ---------- App start ----------
app.whenReady().then(() => {
  if (!gotLock) return;
  Menu.setApplicationMenu(null);
  nativeTheme.themeSource = 'system';
  setupSession(NORMAL);
  createWindow({ url: urlFromArgs(process.argv) });
  app.on('activate', () => { if (BrowserWindow.getAllWindows().length === 0) createWindow(); });
});
app.on('window-all-closed', () => { app.quit(); });
