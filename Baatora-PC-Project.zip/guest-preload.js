// Baatora — har website ke shuru me chalta hai (page ke scripts se pehle)
// Kaam: YouTube ke ads ko shuru se hi rokna.
const { ipcRenderer, webFrame } = require('electron');

function ytMain() {
  if (window.__btyt) return; window.__btyt = 1;

  /* ---- 1) Video ke data se ad ki list hatao (ad load hi nahi hoga) ---- */
  var PK = ['adPlacements', 'playerAds', 'adSlots', 'adBreakHeartbeatParams'];
  var NOPRUNE = false; try { NOPRUNE = sessionStorage.getItem('bt_noprune') === '1'; } catch (e) {}
  function prune(o) {
    try {
      if (NOPRUNE || !o || typeof o !== 'object') return o;
      var t = [o];
      if (o.playerResponse && typeof o.playerResponse === 'object') t.push(o.playerResponse);
      if (Array.isArray(o)) o.forEach(function (x) { if (x && x.playerResponse) t.push(x.playerResponse); });
      t.forEach(function (x) { PK.forEach(function (k) { if (x && k in x) delete x[k]; }); });
    } catch (e) {}
    return o;
  }

  /* ---- 2) Home / search / side list se "Sponsored" cards hatao ---- */
  var AD_ITEM = /^(adSlotRenderer|promotedSparklesWebRenderer|promotedSparklesTextSearchRenderer|promotedVideoRenderer|compactPromotedVideoRenderer|displayAdRenderer|searchPyvRenderer|inFeedAdLayoutRenderer|bannerPromoRenderer|statementBannerRenderer|brandVideoSingletonRenderer|brandVideoShelfRenderer|actionCompanionAdRenderer|companionAdRenderer|merchandiseShelfRenderer|primetimePromoRenderer)$/;
  function isAdItem(x) {
    if (!x || typeof x !== 'object' || Array.isArray(x)) return false;
    for (var k in x) {
      if (AD_ITEM.test(k)) return true;
      if (k === 'richItemRenderer' || k === 'itemSectionRenderer' || k === 'richSectionRenderer') {
        var c = x[k] && (x[k].content || (x[k].contents && x[k].contents.length === 1 && x[k].contents[0]));
        if (c && typeof c === 'object') for (var j in c) if (AD_ITEM.test(j)) return true;
      }
    }
    return false;
  }
  function strip(o, d) {
    if (!o || typeof o !== 'object' || d > 30) return;
    if (o.streamingData || o.videoDetails) return;
    if (Array.isArray(o)) { for (var i = o.length - 1; i >= 0; i--) { if (isAdItem(o[i])) o.splice(i, 1); else strip(o[i], d + 1); } return; }
    for (var k in o) { if (k === 'playerResponse') continue; var v = o[k]; if (v && typeof v === 'object') strip(v, d + 1); }
  }
  function clean(o) { try { if (o && typeof o === 'object') strip(o, 0); } catch (e) {} return o; }

  function trap(name, fn) {
    try {
      var val = window[name];
      Object.defineProperty(window, name, { configurable: true, get: function () { return val; }, set: function (v) { val = fn(v); } });
    } catch (e) {}
  }
  trap('ytInitialPlayerResponse', prune);
  trap('ytInitialData', clean);

  try {
    var jp = JSON.parse;
    JSON.parse = function () {
      var r = jp.apply(this, arguments);
      try {
        var s = arguments[0];
        if (typeof s === 'string' && s.length > 300) {
          if (/"(adPlacements|playerAds|adSlots)"/.test(s)) prune(r);
          if (/"(adSlotRenderer|promotedSparklesWebRenderer|displayAdRenderer|inFeedAdLayoutRenderer|promotedVideoRenderer|compactPromotedVideoRenderer|bannerPromoRenderer)"/.test(s)) clean(r);
        }
      } catch (e) {}
      return r;
    };
  } catch (e) {}
  try {
    var rj = Response.prototype.json;
    Response.prototype.json = function () {
      var u = this.url || '';
      return rj.apply(this, arguments).then(function (o) {
        if (/\/youtubei\/v1\/(player|next|browse|search|reel)/.test(u)) { prune(o); clean(o); }
        return o;
      });
    };
  } catch (e) {}

  /* ---- 3) Bache hue ad dabbe CSS se chhupao ---- */
  var css = 'ytd-ad-slot-renderer,ytd-in-feed-ad-layout-renderer,ytd-banner-promo-renderer,ytd-statement-banner-renderer,' +
    'ytd-promoted-sparkles-web-renderer,ytd-promoted-sparkles-text-search-renderer,ytd-promoted-video-renderer,ytd-display-ad-renderer,' +
    'ytd-compact-promoted-video-renderer,ytd-companion-slot-renderer,ytd-action-companion-ad-renderer,ytd-player-legacy-desktop-watch-ads-renderer,' +
    'ytd-search-pyv-renderer,ytd-brand-video-singleton-renderer,ytd-merch-shelf-renderer,ytd-engagement-panel-section-list-renderer[target-id="engagement-panel-ads"],' +
    'ytd-rich-item-renderer:has(ytd-ad-slot-renderer),ytd-rich-section-renderer:has(ytd-statement-banner-renderer),' +
    '#masthead-ad,#player-ads,#panels ytd-ads-engagement-panel-content-renderer,.ytd-mealbar-promo-renderer,ytd-mealbar-promo-renderer,' +
    '.ytp-ad-overlay-container,.ytp-ad-image-overlay,.ytp-ad-text-overlay,.ytp-ad-player-overlay,.ytp-ad-player-overlay-layout,' +
    '.ytp-ad-visit-advertiser-button,.ytp-ad-preview-container,.ytp-ad-text,.ytp-suggested-action-badge,' +
    'ytm-promoted-sparkles-web-renderer,ytm-companion-ad-renderer,ytm-ad-slot-renderer,ad-slot-renderer,' +
    'tp-yt-paper-dialog:has(ytd-enforcement-message-view-model),ytd-enforcement-message-view-model{display:none!important}' +
    '.ad-showing video,.ad-interrupting video{opacity:0!important}';
  function addCss() {
    try {
      if (document.getElementById('bt-ytcss')) return;
      var s = document.createElement('style'); s.id = 'bt-ytcss'; s.textContent = css;
      (document.head || document.documentElement).appendChild(s);
    } catch (e) {}
  }
  if (document.documentElement) addCss();
  document.addEventListener('DOMContentLoaded', addCss);

  /* ---- 4) Phir bhi ad aaye to: turant skip / end par kudao ---- */
  var inAd = false, wasMuted = false;
  setInterval(function () {
    try {
      var p = document.querySelector('.html5-video-player.ad-showing,.html5-video-player.ad-interrupting');
      var v = document.querySelector('.html5-video-player video') || document.querySelector('video');
      var b = document.querySelector('.ytp-skip-ad-button,.ytp-ad-skip-button,.ytp-ad-skip-button-modern,.ytp-ad-skip-button-slot button,button[class*="skip-ad"],button[id^="skip-button"]');
      if (b) { try { b.click(); } catch (e) {} }
      if (p && v) {
        if (!inAd) { inAd = true; wasMuted = v.muted; }
        v.muted = true;
        try { v.playbackRate = 16; } catch (e) {}
        if (isFinite(v.duration) && v.duration > 0 && v.currentTime < v.duration - 0.25) { try { v.currentTime = v.duration - 0.1; } catch (e) {} }
        if (v.paused) { try { v.play(); } catch (e) {} }
      } else if (inAd && v) {
        inAd = false;
        try { v.playbackRate = 1; } catch (e) {}
        v.muted = wasMuted;
        if (v.paused && v.readyState >= 2) { try { v.play(); } catch (e) {} }
      }
      var c = document.querySelector('.ytp-ad-overlay-close-button'); if (c) c.click();
      /* "Ad blocker allowed nahi" wala popup aaye to hata kar video chalao */
      var en = document.querySelector('ytd-enforcement-message-view-model');
      if (en) {
        var dlg = en.closest('tp-yt-paper-dialog'); if (dlg) dlg.remove(); else en.remove();
        var bd = document.querySelector('tp-yt-iron-overlay-backdrop'); if (bd) bd.remove();
        try { document.body.style.overflow = ''; } catch (e) {}
        if (v && v.paused) { try { v.play(); } catch (e) {} }
      }
    } catch (e) {}
  }, 200);

  /* ---- 5) Video atak jaye to (bahut kam hota hai): ek baar bina ad-filter ke page dobara kholo ---- */
  var wUrl = '', wAt = 0, wOk = false;
  setInterval(function () {
    try {
      if (!/\/(watch|shorts)/.test(location.pathname)) return;
      if (location.href !== wUrl) { wUrl = location.href; wAt = Date.now(); wOk = false; return; }
      if (wOk || document.visibilityState !== 'visible') return;
      if (document.querySelector('.ad-showing')) { wAt = Date.now(); return; }
      var v = document.querySelector('.html5-video-player video');
      if (v && v.currentTime > 0.5) { wOk = true; return; }
      var age = Date.now() - wAt;
      if (age > 4000) { try { var mp = document.getElementById('movie_player'); if (mp && mp.playVideo) mp.playVideo(); } catch (e) {} }
      if (age > 9000) {
        wOk = true;
        var key = 'bt_rl_' + location.search;
        if (sessionStorage.getItem(key)) return;
        sessionStorage.setItem(key, '1'); sessionStorage.setItem('bt_noprune', '1');
        location.reload();
      }
    } catch (e) {}
  }, 700);
}

try {
  const h = (location.hostname || '').toLowerCase();
  if (/(^|\.)youtube\.com$/.test(h) || /(^|\.)youtube-nocookie\.com$/.test(h)) {
    let on = true;
    try { on = ipcRenderer.sendSync('bt-adblock-on') !== false; } catch (e) {}
    if (on) webFrame.executeJavaScript('(' + ytMain.toString() + ')()');
  }
} catch (e) {}
