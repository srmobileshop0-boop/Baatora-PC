const { contextBridge, ipcRenderer } = require('electron');

const allowedOn = ['open-tab', 'search-tab', 'baatora', 'shortcut', 'dl', 'blocked', 'fullscreen'];

contextBridge.exposeInMainWorld('bt', {
  on: (ch, fn) => { if (allowedOn.includes(ch)) ipcRenderer.on(ch, (_e, ...a) => fn(...a)); },
  asset: (name) => ipcRenderer.invoke('asset', name),
  adblock: (on) => ipcRenderer.send('adblock', on),
  newWindow: (opts) => ipcRenderer.send('new-window', opts),
  dl: (id, act, p) => ipcRenderer.send('dl-action', id, act, p),
  defaultBrowser: () => ipcRenderer.send('default-browser'),
  openExternal: (u) => ipcRenderer.send('open-external', u),
  clearData: (what) => ipcRenderer.invoke('clear-data', what),
  savePage: (wcId) => ipcRenderer.invoke('save-page', wcId),
  titleColor: (c, sym) => ipcRenderer.send('title-color', c, sym),
  fullscreen: (on) => ipcRenderer.send('fullscreen', on),
  closeWindow: () => ipcRenderer.send('close-window'),
  quit: () => ipcRenderer.send('quit'),
  info: () => ipcRenderer.invoke('info')
});
