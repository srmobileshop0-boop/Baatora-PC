/* Baatora PC — host side of the internal pages (Settings, History, Extensions).
   Pages run in a tab (pages/internal.html) and talk to this window through guest-preload's btHost. */
'use strict';
const INTPAGE = HOME.replace(/home-pc\.html.*$/i, 'internal.html');
function isIntPage(u) { return !!u && /^file:/i.test(u) && /\/pages\/internal\.html$/i.test(u.split('#')[0].split('?')[0]); }
function intRoute(u) { const h = (u || '').split('#')[1] || ''; return h || 'settings'; }
function intAddr(u) { return 'baatora://' + intRoute(u); }

/* Open (or switch to) an internal page, e.g. 'settings/appearance', 'history', 'extensions' */
function openInternal(route) {
  route = route || 'settings';
  const top = route.split('/')[0];
  const ex = tabs.find((t) => isIntPage(t.url) && intRoute(t.url).split('/')[0] === top);
  const url = INTPAGE + '#' + route;
  if (ex) {
    select(ex);
    if (intRoute(ex.url) !== route) { try { ex.wv.executeJavaScript('location.hash=' + JSON.stringify('#' + route)).catch(() => {}); } catch (e) {} }
    return;
  }
  if (cur && isHome(cur.url)) navigate(url); else newTab(url, { index: cur ? tabs.indexOf(cur) + 1 : undefined });
}
const SEC_MAP = { google: 'you', autofill: 'autofill', privacy: 'privacy', perf: 'performance', look: 'appearance', engine: 'search', default: 'default', startup: 'startup', lang: 'languages', dl: 'downloads', access: 'accessibility', system: 'system', reset: 'reset', ext: 'extensions', about: 'about' };

/* Push fresh state to every open internal page (theme change, sign-in, etc.) */
let intPushT = 0;
function pushInternal(ev) {
  clearTimeout(intPushT);
  intPushT = setTimeout(() => {
    const st = intState();
    tabs.forEach((t) => { if (t.ready && isIntPage(t.url)) { try { t.wv.send('bt-int-push', ev || 'state', st); } catch (e) {} } });
  }, 60);
}
function intState() {
  const a = typeof curAcct === 'function' ? curAcct() : null;
  const t = curTheme();
  return {
    S, FL, incog: INCOG, dark: !!t.dark, acc: t.acc,
    acct: a ? { name: a.name, email: a.email } : null,
    themes: Object.keys(THEMES).filter((k) => k !== 'incog').map((k) => ({ k, n: THEMES[k].n, bar: THEMES[k].bar, tool: THEMES[k].tool, acc: THEMES[k].acc, dark: !!THEMES[k].dark })),
    engines: Object.keys(ENG).map((k) => [k, ENGN[k]]),
    langs: LANGS, histCount: INCOG ? 0 : HIST.length, bmCount: BM.length, tabs: tabs.length
  };
}

function rangeStart(r) {
  const now = Date.now();
  return { m15: now - 15 * 60e3, h1: now - 3600e3, d1: now - 864e5, d7: now - 7 * 864e5, d28: now - 28 * 864e5 }[r] || 0;
}

/* Every method an internal page may call */
const INT_API = {
  state: () => intState(),
  setS: (k, v) => {
    if (!/^[a-zA-Z]+$/.test(k)) return false;
    S[k] = v; saveSet();
    if (k === 'adblock') { window.bt.adblock(!!v); updShield(); }
    if (k === 'bmbar') renderBm();
    if (k === 'night') tabs.forEach((t) => applyNight(t, !!v));
    if (k === 'reduceMotion') applyMotion();
    if (k === 'theme' || k === 'mode') applyTheme();
    if (k === 'homeBtn') applyHomeBtn();
    if (k === 'startMode') S.restore = v === 'restore';
    pushInternal();
    return true;
  },
  setFlag: async (k, v) => { FL[k] = v; await window.bt.setFlag(k, v); pushInternal(); return true; },
  setPerm: async (p, v) => { FL.perm = Object.assign({}, FL.perm, { [p]: !!v }); await window.bt.setFlag('perm', FL.perm); pushInternal(); return true; },
  bt: async (name, ...a) => {
    const ok = ['relaunch', 'defaultBrowser', 'openOs', 'pickDlDir', 'info', 'setLang', 'spellInfo', 'spellSet', 'extList', 'extAdd', 'extRemove', 'extToggle',
      'pwList', 'pwAdd', 'pwDel', 'pwGet', 'sitePerms', 'sitePermSet', 'memInfo', 'cacheSize', 'flags'];
    if (!ok.includes(name) || typeof window.bt[name] !== 'function') throw new Error('Not allowed');
    const r = await window.bt[name](...a);
    if (name === 'setLang') FL.lang = a[0];
    if (name === 'pickDlDir' && r) FL.dlDir = r;
    return r;
  },
  dlFolder: () => { window.bt.dl('', 'folder'); return true; },
  history: (q, limit) => {
    if (INCOG) return [];
    q = String(q || '').trim().toLowerCase();
    return HIST.filter((x) => !q || (x.u || '').toLowerCase().includes(q) || (x.t || '').toLowerCase().includes(q)).slice(0, limit || 1500);
  },
  histDelete: (items) => {
    const key = new Set((items || []).map((x) => x.ts + '|' + x.u));
    HIST = HIST.filter((x) => !key.has(x.ts + '|' + x.u)); saveHist(); return HIST.length;
  },
  histDeleteSite: (host) => { HIST = HIST.filter((x) => { try { return new URL(x.u).hostname !== host; } catch (e) { return true; } }); saveHist(); return true; },
  counts: async (range) => {
    const from = rangeStart(range);
    let cache = 0; try { cache = await window.bt.cacheSize(); } catch (e) {}
    return {
      history: INCOG ? 0 : HIST.filter((x) => x.ts >= from).length,
      downloads: DL.filter((d) => (d.ts || 0) >= from && d.state !== 'progressing').length,
      cache, passwords: (await window.bt.pwList().catch(() => [])).length,
      sites: Object.keys(await window.bt.sitePerms().catch(() => ({})) || {}).length
    };
  },
  clearBrowsing: async (o) => {
    const from = rangeStart(o.range);
    if (o.history && !INCOG) { HIST = from ? HIST.filter((x) => x.ts < from) : []; saveHist(); }
    if (o.downloads) { DL = DL.filter((d) => d.state === 'progressing' || (from && (d.ts || 0) < from)); saveDl(); updDlRing(); }
    if (o.cookies || o.cache) await window.bt.clearData({ cookies: !!o.cookies, cache: !!o.cache });
    if (o.sitePerms) { const sp = await window.bt.sitePerms(); for (const org of Object.keys(sp || {})) for (const k of Object.keys(sp[org])) await window.bt.sitePermSet(org, k, ''); }
    if (o.passwords) { const l = await window.bt.pwList(); for (const x of l) await window.bt.pwDel(x.id); }
    toast('🧹 Browsing data deleted');
    return true;
  },
  open: (u, inNew) => { if (!/^(https?|file|baatora):/i.test(u)) return false; if (/^baatora:/i.test(u)) { baatora(u, cur && cur.wcId); return true; } if (inNew) newTab(u, { bg: false }); else navigate(u); return true; },
  internal: (route) => { openInternal(route); return true; },
  auth: (mode) => { openAuth(mode === 'up' ? 'up' : 'in'); return true; },
  signOut: () => { signOut(); pushInternal(); return true; },
  rename: (n) => {
    n = String(n || '').trim().slice(0, 40); if (!n) return false;
    const list = load('bt_accts', []), a = curAcct(); if (!a) return false;
    const x = list.find((y) => y.email === a.email); if (x) { x.name = n; save('bt_accts', list); }
    paintProfile(); pushInternal(); return true;
  },
  sleepNow: () => { let n = 0; tabs.forEach((x) => { if (x !== cur && discardTab(x)) n++; }); return n; },
  importBookmarks: async () => {
    const l = await window.bt.importBookmarks(); if (!l) return null;
    let n = 0; l.forEach((b) => { if (!isBm(b.u)) { BM.push(b); n++; } }); saveBm(); renderBm(); updStar(); pushInternal(); return n;
  },
  resetSettings: () => {
    window.bt.resetFlags();
    localStorage.removeItem('bt_set');
    setTimeout(() => window.bt.relaunch(), 300);
    return true;
  },
  toast: (m) => { toast(String(m).slice(0, 160)); return true; },
  copy: async (s) => { await navigator.clipboard.writeText(String(s)); return true; },
  clearSiteStore: () => true
};

async function handleInternal(t, id, m, args) {
  let ok = true, data;
  try {
    if (!isIntPage(t.url) && !isDlPage(t.url)) throw new Error('Not allowed');
    const fn = INT_API[m]; if (!fn) throw new Error('Unknown method');
    data = await fn(...(Array.isArray(args) ? args : []));
  } catch (e) { ok = false; data = String((e && e.message) || e); }
  try { t.wv.send('bt-int-reply', id, ok, data === undefined ? null : JSON.parse(JSON.stringify(data))); } catch (e) {}
}

/* Show/hide the toolbar Home button (Chrome: Appearance › Show home button) */
function applyHomeBtn() { const b = $('home'); if (b) b.style.display = S.homeBtn === false ? 'none' : ''; }
applyHomeBtn();

/* Follow Windows light/dark when Mode = Device */
try { matchMedia('(prefers-color-scheme: dark)').addEventListener('change', () => { if (S.mode === 'device') { applyTheme(); pushInternal(); } }); } catch (e) {}
window.addEventListener('storage', (e) => { if (e.key === 'bt_signed' || e.key === 'bt_accts') pushInternal(); });

/* Omnibox "AI Mode" chip (Chrome-style): shows on the New Tab page and while typing */
function paintAiMode() { const b = $('aimode'); if (!b) return; b.classList.toggle('show', !!cur && (isHome(cur.url) || document.activeElement === $('addr'))); }
$('aimode').addEventListener('mousedown', (e) => {
  e.preventDefault();
  const v = $('addr').value.trim();
  const q = v && !/^(https?:|baatora:|file:)/i.test(v) ? v : '';
  navigate('https://www.google.com/search?udm=50' + (q ? '&q=' + encodeURIComponent(q) : ''));
  $('addr').blur();
});
$('addr').addEventListener('focus', paintAiMode);
$('addr').addEventListener('blur', () => setTimeout(paintAiMode, 160));
