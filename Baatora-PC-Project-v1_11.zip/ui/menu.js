/* Baatora PC — Chrome-style ⋮ menu (with flyout submenus) */
'use strict';
const CLOSED_T = {};
const MI = (ic) => '<svg viewBox="0 0 24 24" class="mic"><use href="#i-' + ic + '"/></svg>';
function mItem(a, ic, label, kbd, opt) {
  opt = opt || {};
  return '<button class="mrow' + (opt.sub ? ' hassub' : '') + '"' + (a ? ' data-a="' + a + '"' : '') + (opt.sub ? ' data-sub="' + opt.sub + '"' : '') +
    (opt.u ? ' data-u="' + esc(opt.u) + '"' : '') + (opt.dis ? ' disabled' : '') + '>' +
    (opt.img ? '<img class="mic" src="' + esc(opt.img) + '" alt="">' : MI(ic)) + '<span class="ml">' + label + '</span>' +
    (kbd ? '<kbd>' + kbd + '</kbd>' : '') + (opt.sub ? '<svg viewBox="0 0 24 24" class="marr"><path d="M10 6L8.59 7.41 13.17 12l-4.58 4.59L10 18l6-6z"/></svg>' : '') + '</button>';
}
const HR = '<hr>';

function renderMenu() {
  const m = $('menu'), t = cur, a = typeof curAcct === 'function' ? curAcct() : null;
  const z = Math.round((t ? t.zoom : 1) * 100);
  let prof;
  if (INCOG) prof = '<button class="mprof" data-a="incoginfo"><span class="av inc"><svg viewBox="0 0 24 24"><use href="#i-incog"/></svg></span><span class="ml">Incognito</span></button>';
  else if (a) prof = '<button class="mprof" data-a="profile"><span class="av on">' + esc(ini(a.name)) + '</span><span class="ml">' + esc(a.name) + '</span><span class="pill">Signed in</span><svg viewBox="0 0 24 24" class="marr"><path d="M10 6L8.59 7.41 13.17 12l-4.58 4.59L10 18l6-6z"/></svg></button>';
  else prof = '<button class="mprof" data-a="signin"><span class="av"><svg viewBox="0 0 24 24"><use href="#i-user"/></svg></span><span class="ml">Not signed in</span><span class="pill">Sign in</span><svg viewBox="0 0 24 24" class="marr"><path d="M10 6L8.59 7.41 13.17 12l-4.58 4.59L10 18l6-6z"/></svg></button>';
  const upd = typeof UPD_STATE !== 'undefined' && UPD_STATE.state === 'ready';
  m.innerHTML = (upd ? '<button class="mupd" data-a="updinstall"><span>Relaunch to update</span><b>Update</b></button>' : '') +
    mItem('newtab', 'tabnew', 'New tab', 'Ctrl+T') +
    mItem('newwin', 'win', 'New window', 'Ctrl+N') +
    mItem('incog', 'incog', 'New Incognito window', 'Ctrl+Shift+N') + HR +
    prof +
    mItem('', 'key', 'Passwords and autofill', '', { sub: 'pw' }) +
    mItem('', 'hist', 'History', '', { sub: 'hist' }) +
    mItem('downloads', 'dl', 'Downloads', 'Ctrl+J') +
    mItem('', 'star', 'Bookmarks and lists', '', { sub: 'bm' }) +
    mItem('', 'tabs', 'Tab search', '', { sub: 'tabs' }) +
    mItem('', 'ext', 'Extensions', '', { sub: 'ext' }) +
    mItem('cleardata', 'trash', 'Delete browsing data…', 'Ctrl+Shift+Del') + HR +
    '<div class="mzoom">' + MI('zoom') + '<span class="ml">Zoom</span><button data-a="zout" title="Zoom out">−</button><span id="zval">' + z + '%</span><button data-a="zin" title="Zoom in">+</button><i></i><button data-a="fs" class="mfs" title="Full screen (F11)"><svg viewBox="0 0 24 24"><path d="M7 14H5v5h5v-2H7v-3zm-2-4h2V7h3V5H5v5zm12 7h-3v2h5v-5h-2v3zM14 5v2h3v3h2V5h-5z"/></svg></button></div>' + HR +
    mItem('print', 'print', 'Print…', 'Ctrl+P') +
    mItem('lens', 'lens', 'Search this tab with Google Lens') +
    mItem('translate', 'lang', 'Translate…') +
    mItem('', 'find', 'Find and edit', '', { sub: 'find' }) +
    mItem('', 'share', 'Cast, save, and share', '', { sub: 'share' }) +
    mItem('', 'tools', 'More tools', '', { sub: 'tools' }) + HR +
    mItem('', 'help', 'Help', '', { sub: 'help' }) +
    mItem('settings', 'gear', 'Settings') +
    mItem('exit', 'exitic', 'Exit', 'Ctrl+Q');
  m.querySelectorAll('[data-sub]').forEach((b) => {
    b.addEventListener('mouseenter', () => openSub(b));
    b.addEventListener('click', (e) => { e.stopPropagation(); openSub(b); });
  });
  m.querySelectorAll('.mrow:not([data-sub]),.mprof').forEach((b) => b.addEventListener('mouseenter', () => closeSub()));
}

function subHtml(k) {
  const t = cur;
  switch (k) {
    case 'pw':
      return mItem('pw', 'key', 'Password Manager') + mItem('pw', 'card', 'Payment methods') + mItem('pw', 'home2', 'Addresses and more');
    case 'hist': {
      let h = mItem('history', 'hist', 'History', 'Ctrl+H') + mItem('reopen', 'restore', 'Reopen closed tab', 'Ctrl+Shift+T', { dis: !closed.length });
      const rc = closed.slice(-8).reverse();
      if (rc.length) h += HR + '<div class="mhead">Recently closed</div>' + rc.map((u) => mItem('openu', '', esc(CLOSED_T[u] || host(u) || u), '', { u, img: fav(u) })).join('');
      const recent = (HIST || []).slice(0, 6);
      if (recent.length && !INCOG) h += HR + '<div class="mhead">Recently visited</div>' + recent.map((x) => mItem('openu', '', esc(x.t || x.u), '', { u: x.u, img: fav(x.u) })).join('');
      return h;
    }
    case 'bm': {
      let h = mItem('bmthis', 'star', (t && isBm(t.url)) ? 'Edit bookmark…' : 'Bookmark this tab…', 'Ctrl+D') +
        mItem('bmall', 'star', 'Bookmark all tabs…', 'Ctrl+Shift+D') +
        mItem('bmbar', 'bm', (S.bmbar ? 'Hide' : 'Show') + ' bookmarks bar', 'Ctrl+Shift+B') +
        mItem('bookmarks', 'bm', 'Bookmark manager', 'Ctrl+Shift+O');
      if (BM.length) h += HR + BM.slice(0, 15).map((b) => mItem('openu', '', esc(b.t || b.u), '', { u: b.u, img: fav(b.u) })).join('');
      return h;
    }
    case 'tabs':
      return '<div class="mhead">Open tabs (' + tabs.length + ')</div>' + tabs.map((x, i) => mItem('gotab', '', esc(x.title || x.url) + (x.sleeping ? ' 💤' : ''), i < 8 ? 'Ctrl+' + (i + 1) : '', { u: String(x.id), img: x.icon || (/^https?:/.test(x.url) ? fav(x.url) : 'logo.png') })).join('');
    case 'ext':
      return mItem('extmgr', 'ext', 'Manage Extensions') + mItem('store', 'store', 'Visit Chrome Web Store');
    case 'find':
      return mItem('find', 'find', 'Find…', 'Ctrl+F') + HR + mItem('cut', 'cut', 'Cut', 'Ctrl+X') + mItem('copy', 'copy', 'Copy', 'Ctrl+C') + mItem('paste', 'paste', 'Paste', 'Ctrl+V');
    case 'share':
      return mItem('copyurl', 'link', 'Copy link') + mItem('qr', 'qr', 'Create QR Code') + HR +
        mItem('save', 'save', 'Save page as…', 'Ctrl+S') + mItem('deskshort', 'desk', 'Create shortcut…') + mItem('openfile', 'file', 'Open file…', 'Ctrl+O');
    case 'tools':
      return mItem('reader', 'book', 'Reading mode') + mItem('night', 'moon', (S.night ? 'Turn off' : 'Turn on') + ' Night mode') +
        mItem('desktop', 'desk', (t && t.mobile) ? 'Request desktop site' : 'Request mobile site') + HR +
        mItem('cleardata', 'trash', 'Delete browsing data…', 'Ctrl+Shift+Del') + mItem('perf', 'speed', 'Performance') + mItem('taskmgr', 'speed', 'Task manager', 'Shift+Esc') + HR +
        mItem('source', 'code', 'View page source', 'Ctrl+U') + mItem('devtools', 'code', 'Developer tools', 'Ctrl+Shift+I');
    case 'help':
      return mItem('about', 'info', 'About Baatora') + mItem('helpcenter', 'help', 'Help center') + mItem('report', 'info', 'Report an issue…') + mItem('shortcuts', 'key', 'Keyboard shortcuts') + mItem('whatsnew', 'help', "What's new");
  }
  return '';
}
function openSub(b) {
  const k = b.dataset.sub, s = $('submenu');
  if (s.dataset.k === k && s.classList.contains('show')) return;
  $('menu').querySelectorAll('.hassub').forEach((x) => x.classList.toggle('open', x === b));
  s.dataset.k = k;
  s.innerHTML = subHtml(k);
  s.classList.add('show');
  const r = b.getBoundingClientRect(), mr = $('menu').getBoundingClientRect();
  const w = s.offsetWidth, h = s.offsetHeight;
  let left = mr.left - w + 4; if (left < 4) left = mr.right - 4;
  let top = r.top - 8; if (top + h > window.innerHeight - 8) top = Math.max(8, window.innerHeight - h - 8);
  s.style.left = left + 'px'; s.style.top = top + 'px';
}
function closeSub() { const s = $('submenu'); s.classList.remove('show'); s.dataset.k = ''; $('menu').querySelectorAll('.hassub.open').forEach((x) => x.classList.remove('open')); }

$('menubtn').onclick = (e) => {
  e.stopPropagation();
  const m = $('menu'), on = m.classList.contains('show');
  closePops();
  if (!on) { renderMenu(); m.classList.add('show'); }
};
$('submenu').addEventListener('click', (e) => {
  const b = e.target.closest('[data-a]'); if (!b || b.disabled) return;
  const a = b.dataset.a, u = b.dataset.u;
  closePops();
  if (a === 'openu') { if (e.ctrlKey) newTab(u, { bg: true }); else if (cur && isHome(cur.url)) navigate(u); else newTab(u); return; }
  if (a === 'gotab') { const t = tabs.find((x) => String(x.id) === u); if (t) select(t); return; }
  action(a);
});
document.addEventListener('mousedown', (e) => { if (!e.target.closest('#menu,#submenu,#menubtn')) closeSub(); });

/* Naye menu ke kaam */
function menuAction(a) {
  const t = cur;
  switch (a) {
    case 'updinstall': window.bt.updInstall(); return true;
    case 'signin': openAuth('in'); return true;
    case 'profile': openPanel('settings', 'google'); return true;
    case 'incoginfo': toast('🕶 You’re Incognito — history and cookies are not saved in this window'); return true;
    case 'pw': openInternal('settings/passwords'); return true;
    case 'bmthis': toggleBm(); return true;
    case 'bmall': {
      let n = 0; tabs.forEach((x) => { if (/^https?:/i.test(x.url) && !isBm(x.url)) { BM.unshift({ u: x.url, t: x.title }); n++; } });
      saveBm(); renderBm(); updStar(); toast(n ? '⭐ ' + n + ' tabs bookmarked' : 'All tabs are already bookmarked'); return true;
    }
    case 'bmbar': S.bmbar = !S.bmbar; saveSet(); renderBm(); return true;
    case 'extmgr': openInternal('extensions'); return true;
    case 'store': newTab('https://chromewebstore.google.com/'); return true;
    case 'cut': if (t) try { t.wv.cut(); } catch (e) {} return true;
    case 'copy': if (t) try { t.wv.copy(); } catch (e) {} return true;
    case 'paste': if (t) try { t.wv.paste(); } catch (e) {} return true;
    case 'perf': case 'taskmgr': openPanel('settings', 'perf'); return true;
    case 'shortcuts': openInternal('extensions/shortcuts'); return true;
    case 'helpcenter': newTab('https://anilyadavapps.blogspot.com/'); return true;
    case 'report': window.bt.openExternal('mailto:srmobileshop0@gmail.com?subject=' + encodeURIComponent('Baatora PC issue')); return true;
    case 'whatsnew': openInternal('settings/about'); return true;
    case 'lens':
      if (!t || !t.wcId || !/^https?:/i.test(t.url)) { toast('Open a website first'); return true; }
      window.bt.lensCapture(t.wcId).then((ok) => { if (ok) { newTab('https://lens.google.com/'); toast('Screenshot copied — press Ctrl+V on Google Lens'); } else toast('Could not capture this tab'); });
      return true;
    case 'tabsearch': { const b = document.createElement('button'); b.dataset.sub = 'tabs'; renderMenu(); $('menu').classList.add('show'); openSub($('menu').querySelector('[data-sub=tabs]')); return true; }
  }
  return false;
}
