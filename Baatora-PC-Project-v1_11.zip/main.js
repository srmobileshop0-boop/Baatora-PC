// Baatora Browser — PC (Windows) version
// Made in India • Created by Anil Yadav, Thane
const { app, BrowserWindow, session, ipcMain, Menu, clipboard, shell, webContents, nativeTheme, dialog, safeStorage } = require('electron');
const path = require('path');
const fs = require('fs');
const os = require('os');
const { pathToFileURL } = require('url');

app.setName('Baatora');

// ---------- PC flags (Settings se) ----------
const FLAGS_FILE = path.join(app.getPath('userData'), 'baatora-flags.json');
let FLAGS = { hwaccel: true, smoothScroll: true, autoplay: true, dnt: false, httpsOnly: false, perm: {}, site: {}, askDl: false, dlDir: '', lang: '', spell: true, spellLangs: [], extensions: [] };
try { FLAGS = Object.assign(FLAGS, JSON.parse(fs.readFileSync(FLAGS_FILE, 'utf8'))); } catch (e) {}
function writeFlags() { try { fs.writeFileSync(FLAGS_FILE, JSON.stringify(FLAGS)); } catch (e) {} }
if (FLAGS.hwaccel === false) app.disableHardwareAcceleration();
if (FLAGS.smoothScroll === false) app.commandLine.appendSwitch('disable-smooth-scrolling');
// Video bina click kiye turant chale (Settings > Performance se band kar sakte hain)
if (FLAGS.autoplay !== false) app.commandLine.appendSwitch('autoplay-policy', 'no-user-gesture-required');
if (process.platform === 'win32') app.setAppUserModelId('com.baatora.browser.pc');
// Location: Chrome ki tarah Windows ki apni Location service se jagah pata karein
// Tez aur smooth: GPU se page banana, downloads ke kai hisse ek saath, Back/Forward turant
app.commandLine.appendSwitch('enable-features', 'WinrtGeolocationImplementation,BackForwardCache,ParallelDownloading');
if (FLAGS.hwaccel !== false) { app.commandLine.appendSwitch('enable-gpu-rasterization'); app.commandLine.appendSwitch('enable-zero-copy'); }
if (FLAGS.smoothScroll !== false) app.commandLine.appendSwitch('enable-smooth-scrolling');
app.commandLine.appendSwitch('disk-cache-size', String(1024 * 1024 * 1024)); // 1 GB cache: dobara khulne par pages turant
app.commandLine.appendSwitch('enable-quic');

const NORMAL = 'persist:baatora';
const INCOG = 'baatora-incognito';
const HOME = pathToFileURL(path.join(__dirname, 'pages', 'home-pc.html')).href;

let adblockOn = true;
const blocked = new Map(); // host webContents id -> count

const AD_HOSTS = /(^|\.)(doubleclick\.net|googlesyndication\.com|googleadservices\.com|adservice\.google\.[a-z.]+|pagead2\.googlesyndication\.com|google-analytics\.com|exoclick\.com|exosrv\.com|exdynsrv\.com|juicyads\.com|trafficstars\.com|tsyndicate\.com|clickadu\.com|hilltopads\.net|adcash\.com|popcash\.net|propellerads\.com|onclkds\.com|clickaine\.com|realsrv\.com|magsrv\.com|adsterra\.com|a-ads\.com|adskeeper\.com|richpush\.co|admaven\.com|ad-maven\.com|bidvertiser\.com|plugrush\.com|yllix\.com|popads\.net|monetag\.com|profitableratecpm\.com|highperformanceformat\.com|effectivegatecpm\.com|oclasrv\.com|taboola\.com|outbrain\.com|mgid\.com|revcontent\.com|zedo\.com|criteo\.com|criteo\.net|moatads\.com|adnxs\.com|amazon-adsystem\.com|scorecardresearch\.com|quantserve\.com|adform\.net|rubiconproject\.com|pubmatic\.com|openx\.net|smartadserver\.com|33across\.com|media\.net|yieldmo\.com|inmobi\.com|vungle\.com|unityads\.unity3d\.com|applovin\.com|chartboost\.com)$/i;

// YouTube par ads aane dete hain (video bina rukawat chale) — isliye YouTube ke requests kabhi nahi roke jate
const YT_PAGE = /^https?:\/\/([^/]*\.)?(youtube\.com|youtube-nocookie\.com|googlevideo\.com|ytimg\.com)(\/|:|$)/i;
function isYT(d) {
  try { const u = (d.webContents && d.webContents.getURL()) || ''; if (YT_PAGE.test(u)) return true; return YT_PAGE.test(d.referrer || ''); } catch (e) { return false; }
}

// Ad domains ke URL patterns: Chromium khud match karta hai, JS sirf ad wali request par chalta hai
const AD_DOMAINS = ['doubleclick.net', 'googlesyndication.com', 'googleadservices.com', 'adservice.google.com', 'adservice.google.co.in', 'google-analytics.com', 'exoclick.com', 'exosrv.com', 'exdynsrv.com', 'juicyads.com', 'trafficstars.com', 'tsyndicate.com', 'clickadu.com', 'hilltopads.net', 'adcash.com', 'popcash.net', 'propellerads.com', 'onclkds.com', 'clickaine.com', 'realsrv.com', 'magsrv.com', 'adsterra.com', 'a-ads.com', 'adskeeper.com', 'richpush.co', 'admaven.com', 'ad-maven.com', 'bidvertiser.com', 'plugrush.com', 'yllix.com', 'popads.net', 'monetag.com', 'profitableratecpm.com', 'highperformanceformat.com', 'effectivegatecpm.com', 'oclasrv.com', 'taboola.com', 'outbrain.com', 'mgid.com', 'revcontent.com', 'zedo.com', 'criteo.com', 'criteo.net', 'moatads.com', 'adnxs.com', 'amazon-adsystem.com', 'scorecardresearch.com', 'quantserve.com', 'adform.net', 'rubiconproject.com', 'pubmatic.com', 'openx.net', 'smartadserver.com', '33across.com', 'media.net', 'yieldmo.com', 'inmobi.com', 'vungle.com', 'unityads.unity3d.com', 'applovin.com', 'chartboost.com'];
const AD_PATTERNS = [].concat(...AD_DOMAINS.map((d) => ['*://' + d + '/*', '*://*.' + d + '/*']));
function applyNetHooks(ses) {
  // Do Not Track: sirf tab jab chalu ho
  if (FLAGS.dnt) ses.webRequest.onBeforeSendHeaders({ urls: ['*://*/*'] }, (d, cb) => cb({ requestHeaders: Object.assign({}, d.requestHeaders, { DNT: '1', 'Sec-GPC': '1' }) }));
  else ses.webRequest.onBeforeSendHeaders(null);
  const urls = AD_PATTERNS.concat(FLAGS.httpsOnly ? ['http://*/*'] : []);
  ses.webRequest.onBeforeRequest({ urls }, (details, cb) => {
    if (FLAGS.httpsOnly && details.resourceType === 'mainFrame' && /^http:\/\//i.test(details.url)) {
      try {
        const h = new URL(details.url).hostname;
        if (!/^(localhost|.*\.local|\d+\.\d+\.\d+\.\d+|\[.*\])$/i.test(h)) return cb({ redirectURL: details.url.replace(/^http:/i, 'https:') });
      } catch (e) {}
      return cb({});
    }
    if (adblockOn && details.resourceType !== 'mainFrame' && !isYT(details)) {
      try {
        if (AD_HOSTS.test(new URL(details.url).hostname)) {
          const wc = details.webContents, host = wc && wc.hostWebContents;
          if (host && !host.isDestroyed()) { const n = (blocked.get(host.id) || 0) + 1; blocked.set(host.id, n); host.send('blocked', n); }
          return cb({ cancel: true });
        }
      } catch (e) {}
    }
    cb({});
  });
}
// Secure DNS (DNS-over-HTTPS) + Chromium ka apna tez DNS resolver
const DOH = { google: 'https://dns.google/dns-query', cloudflare: 'https://cloudflare-dns.com/dns-query', quad9: 'https://dns.quad9.net/dns-query' };
function applyDns() {
  try {
    const mode = FLAGS.secureDns === false ? 'off' : (FLAGS.dohProvider && DOH[FLAGS.dohProvider] ? 'secure' : 'automatic');
    app.configureHostResolver({ enableBuiltInResolver: true, secureDnsMode: mode, secureDnsServers: mode === 'secure' ? [DOH[FLAGS.dohProvider]] : [] });
  } catch (e) {}
}

// ---------- Single instance (link double-click se naya tab) ----------
const gotLock = app.requestSingleInstanceLock();
if (!gotLock) app.quit();
app.on('second-instance', (_e, argv) => {
  const url = urlFromArgs(argv);
  let w = BrowserWindow.getFocusedWindow() || BrowserWindow.getAllWindows().find(x => !x.__incog) || null;
  if (!w) { createWindow({ url }); return; }
  if (w.isMinimized()) w.restore();
  w.focus();
  if (url) w.webContents.send('open-tab', url);
});

function urlFromArgs(argv) {
  const args = argv.slice(app.isPackaged ? 1 : 2);
  for (const a of args) {
    if (!a || a.startsWith('-')) continue;
    if (/^(https?|ftp|file):/i.test(a)) return a;
    try { if (fs.existsSync(a) && fs.statSync(a).isFile()) return pathToFileURL(path.resolve(a)).href; } catch (e) {}
  }
  return null;
}

// ---------- Session setup (adblock, downloads, UA, permissions) ----------
const readySessions = new Set();
function setupSession(part) {
  const ses = session.fromPartition(part);
  if (readySessions.has(part)) return ses;
  readySessions.add(part);

  // Chrome jaisa user-agent (taaki sites sahi chalein)
  const ua = ses.getUserAgent().replace(/\sElectron\/\S+/, '').replace(/\sBaatora\/\S+/i, '').replace(/\sbaatora-pc\/\S+/i, '');
  if (FLAGS.lang) ses.setUserAgent(ua, FLAGS.lang); else ses.setUserAgent(ua);

  // Spell check
  try {
    ses.setSpellCheckerEnabled(FLAGS.spell !== false);
    const av = ses.availableSpellCheckerLanguages || [];
    const sl = (FLAGS.spellLangs || []).filter((l) => av.includes(l));
    if (sl.length) ses.setSpellCheckerLanguages(sl);
  } catch (e) {}

  // Extensions (unpacked folders)
  if (part === NORMAL) (FLAGS.extensions || []).forEach((p) => { if (!(FLAGS.extOff || []).includes(p)) loadExt(ses, p); });

  // Network hooks — sirf zaroori URLs par (har request JavaScript se nahi guzarti, isliye pages tez khulte hain)
  applyNetHooks(ses);

  // Chrome jaisa: har site pehle poochhe (Location, Camera, Mic, Notifications...)
  ses.setPermissionRequestHandler((wc, perm, cb, details) => askPermission(ses, wc, perm, cb, details || {}));

  ses.on('will-download', (_e, item, wc) => {
    const host = (wc && wc.hostWebContents) || wc;
    const dir = dlDir();
    let name = item.getFilename() || 'download';
    let p = path.join(dir, name), i = 1;
    const ext = path.extname(name), base = path.basename(name, ext);
    while (fs.existsSync(p)) p = path.join(dir, `${base} (${i++})${ext}`);
    if (!FLAGS.askDl) item.setSavePath(p); // askDl chalu ho to Windows ka "Save as" dialog khulega
    const curPath = () => item.getSavePath() || p;
    const id = Date.now() + '' + Math.floor(Math.random() * 1000);
    downloads.set(id, item);
    let lastSend = 0;
    const send = (state) => {
      if (!host || host.isDestroyed()) return;
      // progress har 300ms me ek baar hi bhejein (UI na atke)
      const now = Date.now();
      if (state === 'progressing' && now - lastSend < 300 && lastSend) return;
      lastSend = now;
      host.send('dl', { id, name: path.basename(curPath()), path: curPath(), url: item.getURL(), total: item.getTotalBytes(), received: item.getReceivedBytes(), state, paused: item.isPaused(), ts: Date.now() });
    };
    send('progressing');
    item.on('updated', (_ev, state) => send(state));
    item.once('done', (_ev, state) => { send(state); downloads.delete(id); });
  });
  return ses;
}
const downloads = new Map();
function dlDir() { try { if (FLAGS.dlDir && fs.existsSync(FLAGS.dlDir)) return FLAGS.dlDir; } catch (e) {} return app.getPath('downloads'); }
async function loadExt(ses, p) { try { const api = ses.extensions || ses; return await api.loadExtension(p, { allowFileAccess: true }); } catch (e) { return null; } }
function extName(p) { try { const m = JSON.parse(fs.readFileSync(path.join(p, 'manifest.json'), 'utf8')); return m.name && !/^__MSG/.test(m.name) ? m.name : path.basename(p); } catch (e) { return path.basename(p); } }

// ---------- Permissions (Chrome jaisa prompt) ----------
const PERM_ASK = { geolocation: 'location', notifications: 'notifications', media: 'media', 'clipboard-read': 'clipboard', midiSysex: 'midi', 'window-management': 'windows', 'idle-detection': 'idle' };
const PERM_FREE = ['fullscreen', 'pointerLock', 'clipboard-sanitized-write', 'openExternal', 'keyboardLock', 'speaker-selection'];
const onceAllow = new Set();   // "Sirf is baar" + Incognito ke allow (app band hote hi khatam)
const pendingPerm = new Map();
let permSeq = 0;
function permKeys(perm, d) {
  if (perm === 'media') {
    const t = d.mediaTypes || []; const k = [];
    if (t.includes('video')) k.push('camera');
    if (t.includes('audio')) k.push('microphone');
    return k;
  }
  return [PERM_ASK[perm]];
}
function globalOff(k) {
  const P = FLAGS.perm || {};
  if (k === 'location') return P.geolocation === false;
  if (k === 'camera' || k === 'microphone') return P.media === false;
  if (k === 'notifications') return P.notifications === false;
  return false;
}
function siteVal(origin, k) { return ((FLAGS.site || {})[origin] || {})[k]; }
function setSiteVal(origin, k, v) {
  FLAGS.site = FLAGS.site || {};
  const o = Object.assign({}, FLAGS.site[origin]);
  if (v) o[k] = v; else delete o[k];
  if (Object.keys(o).length) FLAGS.site[origin] = o; else delete FLAGS.site[origin];
}
function permUsed(wc, keys) { const h = wc && wc.hostWebContents; if (h && !h.isDestroyed()) h.send('perm-used', wc.id, keys); }
function askPermission(ses, wc, perm, cb, d) {
  if (!PERM_ASK[perm]) return cb(PERM_FREE.includes(perm));
  let origin = '';
  try { origin = new URL(d.requestingUrl || wc.getURL()).origin; } catch (e) {}
  if (!origin || origin === 'null' || /^file:/i.test(origin)) return cb(true); // Baatora ke apne pages
  const keys = permKeys(perm, d);
  if (!keys.length) return cb(true);
  const incog = ses === session.fromPartition(INCOG);
  if (keys.some(globalOff)) return cb(false);
  const st = keys.map((k) => {
    if (onceAllow.has((incog ? 'i|' : 'n|') + wc.id + '|' + origin + '|' + k) || onceAllow.has((incog ? 'i|' : 'n|') + origin + '|' + k)) return 'allow';
    const v = siteVal(origin, k);
    return incog && v === 'allow' ? undefined : v; // Incognito me sirf "Block" yaad rehta hai
  });
  if (st.includes('block')) return cb(false);
  if (st.every((x) => x === 'allow')) { permUsed(wc, keys); return cb(true); }
  const host = wc.hostWebContents;
  if (!host || host.isDestroyed()) return cb(false);
  const id = ++permSeq;
  const onGone = () => done(false);
  const onNavStart = (ev, _u, inPage, isMain) => {
    const main = ev && ev.isMainFrame !== undefined ? ev.isMainFrame : isMain;
    const same = ev && ev.isSameDocument !== undefined ? ev.isSameDocument : inPage;
    if (main && !same) done(false);
  };
  const done = (ok) => {
    if (!pendingPerm.has(id)) return;
    pendingPerm.delete(id);
    if (!wc.isDestroyed()) { wc.removeListener('did-start-navigation', onNavStart); wc.removeListener('destroyed', onGone); }
    try { cb(!!ok); } catch (e) {}
    if (ok && !wc.isDestroyed()) permUsed(wc, keys);
    if (!host.isDestroyed()) host.send('perm-cancel', id);
  };
  pendingPerm.set(id, { done, origin, keys, wcId: wc.id, incog });
  wc.on('destroyed', onGone);
  wc.on('did-start-navigation', onNavStart);
  host.send('perm-ask', { id, origin, keys, wcId: wc.id });
}
ipcMain.on('perm-reply', (e, id, how) => {
  const p = pendingPerm.get(id); if (!p) return;
  const pre = p.incog ? 'i|' : 'n|';
  if (how === 'allow') { p.keys.forEach((k) => { if (p.incog) onceAllow.add(pre + p.origin + '|' + k); else setSiteVal(p.origin, k, 'allow'); }); if (!p.incog) writeFlags(); p.done(true); }
  else if (how === 'once') { p.keys.forEach((k) => onceAllow.add(pre + p.wcId + '|' + p.origin + '|' + k)); p.done(true); }
  else if (how === 'block') { p.keys.forEach((k) => setSiteVal(p.origin, k, 'block')); writeFlags(); p.done(false); }
  else p.done(false);
});
ipcMain.handle('site-perms', () => FLAGS.site || {});
ipcMain.handle('site-perm-set', (e, origin, k, v) => {
  if (!fromUI(e)) return FLAGS.site;
  if (!/^https?:\/\/[^\s]+$/i.test(String(origin)) || !/^[a-z]+$/.test(String(k))) return FLAGS.site;
  setSiteVal(String(origin), k, v === 'allow' || v === 'block' ? v : '');
  [...onceAllow].forEach((x) => { if (x.endsWith('|' + origin + '|' + k)) onceAllow.delete(x); });
  writeFlags();
  return FLAGS.site;
});

// ---------- Print (Chrome jaisa Print Preview) ----------
const PAPERS = { A3: 1, A4: 1, A5: 1, Letter: 1, Legal: 1, Tabloid: 1, Ledger: 1 };
const PREV_DIR = path.join(os.tmpdir(), 'baatora-print');
const HDR = '<div style="font-family:Arial,sans-serif;font-size:8px;color:#000;width:100%;margin:0 1cm;display:flex;-webkit-print-color-adjust:exact"><span class="date" style="flex:1"></span><span class="title" style="flex:2;text-align:center;overflow:hidden;white-space:nowrap;text-overflow:ellipsis"></span><span style="flex:1"></span></div>';
const FTR = '<div style="font-family:Arial,sans-serif;font-size:8px;color:#000;width:100%;margin:0 1cm;display:flex;-webkit-print-color-adjust:exact"><span class="url" style="flex:1;overflow:hidden;white-space:nowrap;text-overflow:ellipsis"></span><span style="margin-left:12px"><span class="pageNumber"></span>/<span class="totalPages"></span></span></div>';
const clampN = (v, a, b, d) => { v = Math.round(+v); return isFinite(v) ? Math.min(b, Math.max(a, v)) : d; };
function marginIn(o) {
  const mm = (v) => clampN(v, 0, 100, 10) / 25.4;
  if (o.margins === 'none') return { top: 0, bottom: 0, left: 0, right: 0 };
  if (o.margins === 'min') return { top: 0.2, bottom: 0.2, left: 0.2, right: 0.2 };
  if (o.margins === 'custom') return { top: mm(o.mt), bottom: mm(o.mb), left: mm(o.ml), right: mm(o.mr) };
  return { top: 0.4, bottom: 0.4, left: 0.4, right: 0.4 };
}
function pdfOpts(o, ranges) {
  const m = marginIn(o);
  const r = { landscape: !!o.landscape, printBackground: !!o.bg, scale: clampN(o.scale, 10, 200, 100) / 100, pageSize: PAPERS[o.paper] ? o.paper : 'A4', margins: m, preferCSSPageSize: false };
  if (o.hf && m.top >= 0.25 && m.bottom >= 0.25) { r.displayHeaderFooter = true; r.headerTemplate = HDR; r.footerTemplate = FTR; }
  if (ranges) r.pageRanges = ranges.map(([a, b]) => (a === b ? String(a) : a + '-' + b)).join(',');
  return r;
}
function printMargins(o) {
  const px = (v) => Math.round(clampN(v, 0, 100, 10) * 96 / 25.4);
  if (o.margins === 'none') return { marginType: 'none' };
  if (o.margins === 'min') return { marginType: 'printableArea' };
  if (o.margins === 'custom') return { marginType: 'custom', top: px(o.mt), bottom: px(o.mb), left: px(o.ml), right: px(o.mr) };
  return { marginType: 'default' };
}
function countPages(buf) { const m = buf.toString('latin1').match(/\/Type\s*\/Page(?![a-zA-Z])/g); return m ? m.length : 1; }
function parseRanges(s, total) {
  s = String(s || '').trim().toLowerCase();
  if (!s || s === 'all') return null;
  const out = [];
  if (s === 'odd' || s === 'even') { for (let i = s === 'odd' ? 1 : 2; i <= total; i += 2) out.push([i, i]); return out.length ? out : false; }
  for (const raw of s.split(',')) {
    const p = raw.trim(); if (!p) continue;
    let a, b, m;
    if ((m = /^(\d+)$/.exec(p))) { a = b = +m[1]; }
    else if ((m = /^(\d*)\s*-\s*(\d*)$/.exec(p)) && (m[1] || m[2])) { a = m[1] ? +m[1] : 1; b = m[2] ? +m[2] : total; }
    else return false;
    if (a < 1 || b < a || a > total) return false;
    out.push([a, Math.min(b, total)]);
  }
  return out.length ? out : false;
}
function cleanPrev() {
  try { fs.mkdirSync(PREV_DIR, { recursive: true }); for (const f of fs.readdirSync(PREV_DIR)) { const fp = path.join(PREV_DIR, f); try { if (Date.now() - fs.statSync(fp).mtimeMs > 60000) fs.unlinkSync(fp); } catch (x) {} } } catch (e) {}
}
ipcMain.handle('print-printers', async (e, wcId) => {
  const wc = webContents.fromId(wcId);
  if (!wc || wc.isDestroyed()) return [];
  try {
    const list = await wc.getPrintersAsync();
    return (list || []).map((p) => ({ name: p.name, label: p.displayName || p.name, isDefault: !!(p.isDefault || (p.options && String(p.options.isDefault || p.options['printer-is-default']) === 'true')) }));
  } catch (err) { return []; }
});
ipcMain.handle('print-preview', async (e, wcId, o) => {
  if (!fromUI(e)) return { err: 'Not allowed' };
  const wc = webContents.fromId(wcId);
  if (!wc || wc.isDestroyed()) return { err: 'Page not found' };
  try {
    const full = await wc.printToPDF(pdfOpts(o));
    const total = countPages(full);
    const ranges = parseRanges(o.pages, total);
    if (ranges === false) return { err: 'range', total };
    const buf = ranges ? await wc.printToPDF(pdfOpts(o, ranges)) : full;
    cleanPrev();
    const f = path.join(PREV_DIR, 'preview-' + Date.now() + '-' + Math.floor(Math.random() * 1e6) + '.pdf');
    fs.writeFileSync(f, buf);
    return { url: pathToFileURL(f).href, total, pages: ranges ? countPages(buf) : total };
  } catch (err) { return { err: String((err && err.message) || err) }; }
});
ipcMain.handle('print-do', async (e, wcId, o) => {
  if (!fromUI(e)) return { ok: false, err: 'Not allowed' };
  const wc = webContents.fromId(wcId);
  if (!wc || wc.isDestroyed()) return { ok: false, err: 'Page not found' };
  try {
    let ranges = null;
    if (o.pages && o.pages !== 'all') {
      ranges = parseRanges(o.pages, countPages(await wc.printToPDF(pdfOpts(o))));
      if (ranges === false) return { ok: false, err: 'Invalid page range, use e.g. 1-5, 8, 11-13' };
    }
    if (o.dest === 'pdf') {
      const buf = await wc.printToPDF(pdfOpts(o, ranges));
      const safe = (wc.getTitle() || 'page').replace(/[\\/:*?"<>|]+/g, ' ').trim().slice(0, 80) || 'page';
      const r = await dialog.showSaveDialog(BrowserWindow.fromWebContents(e.sender), { defaultPath: path.join(dlDir(), safe + '.pdf'), filters: [{ name: 'PDF', extensions: ['pdf'] }] });
      if (r.canceled || !r.filePath) return { ok: false, canceled: true };
      fs.writeFileSync(r.filePath, buf);
      return { ok: true, path: r.filePath };
    }
    const opts = {
      silent: true, deviceName: String(o.dest || ''), printBackground: !!o.bg, color: o.color !== 'bw', landscape: !!o.landscape,
      copies: clampN(o.copies, 1, 999, 1), collate: o.collate !== false, pagesPerSheet: [1, 2, 4, 6, 9, 16].includes(+o.pps) ? +o.pps : 1,
      scaleFactor: clampN(o.scale, 10, 200, 100), pageSize: PAPERS[o.paper] ? o.paper : 'A4', margins: printMargins(o)
    };
    if (o.duplex === 'longEdge' || o.duplex === 'shortEdge') opts.duplexMode = o.duplex;
    if (+o.dpi) opts.dpi = { horizontal: +o.dpi, vertical: +o.dpi };
    if (o.hf) { opts.header = wc.getTitle(); opts.footer = wc.getURL(); }
    if (ranges) opts.pageRanges = ranges.map(([a, b]) => ({ from: a - 1, to: b - 1 }));
    return await new Promise((res) => wc.print(opts, (ok, why) => res({ ok, err: ok ? '' : (why || '') })));
  } catch (err) { return { ok: false, err: String((err && err.message) || err) }; }
});
const iconCache = new Map();
ipcMain.handle('dl-info', async (e, paths) => {
  if (!fromUI(e) || !Array.isArray(paths)) return [];
  const out = [];
  for (const p of paths.slice(0, 300)) {
    let exists = false, icon = '';
    try { exists = !!p && fs.existsSync(p); } catch (x) {}
    if (exists) {
      const key = path.extname(p).toLowerCase() === '.exe' ? p : path.extname(p).toLowerCase() || p;
      if (iconCache.has(key)) icon = iconCache.get(key);
      else { try { icon = (await app.getFileIcon(p, { size: 'normal' })).toDataURL(); } catch (x) {} iconCache.set(key, icon); }
    }
    out.push({ exists, icon });
  }
  return out;
});
ipcMain.handle('lens-capture', async (e, wcId) => {
  if (!fromUI(e)) return false;
  const wc = webContents.fromId(wcId);
  if (!wc || wc.isDestroyed()) return false;
  try { const img = await wc.capturePage(); if (img.isEmpty()) return false; clipboard.writeImage(img); return true; } catch (x) { return false; }
});
ipcMain.on('kill-tab', (e, wcId) => {
  if (!fromUI(e)) return;
  const wc = webContents.fromId(wcId);
  if (!wc || wc.isDestroyed() || wc.getType() !== 'webview') return;
  try { wc.forcefullyCrashRenderer(); } catch (x) {}
  setTimeout(() => { try { if (!wc.isDestroyed()) wc.reload(); } catch (x) {} }, 400);
});
ipcMain.handle('mem-info', async () => {
  try { const m = app.getAppMetrics(); return { mb: Math.round(m.reduce((s, x) => s + ((x.memory && x.memory.workingSetSize) || 0), 0) / 1024), procs: m.length }; } catch (e) { return null; }
});
ipcMain.on('print-system', (e, wcId) => { const wc = webContents.fromId(wcId); if (wc && !wc.isDestroyed()) wc.print({ silent: false, printBackground: true }); });

// ---------- Chrome ke aur kaam ----------
ipcMain.handle('desk-shortcut', (e, url, title) => {
  if (!fromUI(e) || !/^(https?|file):/i.test(String(url))) return null;
  const safe = (String(title || 'Baatora').replace(/[\\/:*?"<>|]+/g, ' ').trim().slice(0, 60)) || 'Baatora';
  const f = path.join(app.getPath('desktop'), safe + '.url');
  try { fs.writeFileSync(f, '[InternetShortcut]\r\nURL=' + url + '\r\n'); return f; } catch (err) { return null; }
});
ipcMain.handle('open-file', async (e) => {
  if (!fromUI(e)) return null;
  const r = await dialog.showOpenDialog(BrowserWindow.fromWebContents(e.sender), { title: 'Open file', properties: ['openFile'], filters: [{ name: 'Web pages, PDFs, images and text', extensions: ['html', 'htm', 'pdf', 'png', 'jpg', 'jpeg', 'gif', 'webp', 'svg', 'txt', 'json', 'xml', 'mp4', 'webm', 'mp3'] }, { name: 'All files', extensions: ['*'] }] });
  if (r.canceled || !r.filePaths[0]) return null;
  return pathToFileURL(r.filePaths[0]).href;
});

// ---------- Windows ----------
function createWindow({ incog = false, url = null } = {}) {
  setupSession(incog ? INCOG : NORMAL);
  const w = new BrowserWindow({
    width: 1280, height: 820, minWidth: 520, minHeight: 400,
    backgroundColor: incog ? '#1A0B3A' : '#FFFFFF',
    title: incog ? 'Baatora Incognito' : 'Baatora',
    icon: path.join(__dirname, 'ui', 'logo.png'),
    titleBarStyle: 'hidden',
    titleBarOverlay: { color: incog ? '#1A0B3A' : '#DFE3E8', symbolColor: incog ? '#FFFFFF' : '#1F2937', height: 40 },
    show: false,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      webviewTag: true,
      plugins: true,
      spellcheck: true
    }
  });
  w.__incog = incog;
  const q = { incog: incog ? '1' : '0', home: HOME };
  if (url) q.url = url;
  w.loadFile(path.join(__dirname, 'ui', 'index.html'), { query: q });
  w.once('ready-to-show', () => { w.show(); });
  w.on('enter-full-screen', () => w.webContents.send('fullscreen', true));
  w.on('leave-full-screen', () => w.webContents.send('fullscreen', false));
  w.webContents.setWindowOpenHandler(() => ({ action: 'deny' }));
  // Baatora ki apni window atke to Wait / Dobara kholne ka option
  let asking = false;
  w.on('unresponsive', async () => {
    if (asking || w.isDestroyed()) return; asking = true;
    const r = await dialog.showMessageBox(w, { type: 'warning', title: 'Baatora', message: 'Baatora isn’t responding', detail: 'You can wait for it to respond or reload the window (your tabs will reopen).', buttons: ['Wait', 'Reload'], defaultId: 0, cancelId: 0 });
    asking = false;
    if (r.response === 1 && !w.isDestroyed()) w.webContents.reload();
  });
  w.webContents.on('render-process-gone', () => { if (!w.isDestroyed()) setTimeout(() => { try { w.webContents.reload(); } catch (e) {} }, 500); });
  return w;
}

// ---------- Webview (tab) handling ----------
app.on('web-contents-created', (_e, wc) => {
  wc.on('will-attach-webview', (_ev, prefs, params) => {
    prefs.preload = path.join(__dirname, 'guest-preload.js');
    prefs.nodeIntegration = false;
    prefs.contextIsolation = true;
    prefs.sandbox = true;
    prefs.plugins = true; // PDF ko browser ke andar hi kholein (Chrome jaisa)
    prefs.backgroundThrottling = true; // peeche ke tabs CPU kam lein
    prefs.v8CacheOptions = 'bypassHeatCheck';
    if (FLAGS.fontSize) { prefs.defaultFontSize = FLAGS.fontSize; prefs.defaultMonospaceFontSize = Math.round(FLAGS.fontSize * 0.8125); } // websites ka JavaScript dobara jaldi chale
    prefs.autoplayPolicy = FLAGS.autoplay !== false ? 'no-user-gesture-required' : 'document-user-activation-required';
    if (params.partition !== NORMAL && params.partition !== INCOG) params.partition = NORMAL;
  });

  if (wc.getType() !== 'webview') return;

  // Page atak jaye (hang) ya crash ho to UI ko batayein — browser kabhi poora na atke
  const tell = (ch, ...a) => { const h = wc.hostWebContents; if (h && !h.isDestroyed()) h.send(ch, wc.id, ...a); };
  wc.on('unresponsive', () => tell('tab-hang'));
  wc.on('responsive', () => tell('tab-ok'));

  wc.setWindowOpenHandler(({ url, disposition }) => {
    const host = wc.hostWebContents;
    if (host && !host.isDestroyed()) host.send('open-tab', url, disposition === 'background-tab');
    return { action: 'deny' };
  });

  let lastB = '', lastT = 0;
  const onNav = (ev, url) => {
    if (typeof url === 'object' && url) url = url.url;
    if (url && /^baatora:/i.test(url)) {
      ev.preventDefault();
      const now = Date.now();
      if (url === lastB && now - lastT < 600) return;
      lastB = url; lastT = now;
      const host = wc.hostWebContents;
      if (host && !host.isDestroyed()) host.send('baatora', url, wc.id);
    }
  };
  wc.on('will-navigate', onNav);
  wc.on('will-frame-navigate', (ev) => onNav(ev, ev.url));

  // Keyboard shortcuts page ke andar se bhi chalein
  wc.on('before-input-event', (ev, input) => {
    if (input.type !== 'keyDown') return;
    const k = (input.key || '').toLowerCase();
    const c = input.control || input.meta;
    let combo = null;
    if (c && input.shift && ['n', 't', 'b', 'delete', 'tab', 'i', 'p', 'r', 'j', 'c', 'w', 'o', 'd', 'a'].includes(k)) combo = 'ctrl+shift+' + k;
    else if (c && ['t', 'w', 'n', 'l', 'r', 'f', 'h', 'j', 'd', 'p', 'tab', '=', '+', '-', '0', 'q', 'u', 's', 'o', 'pagedown', 'pageup', 'f4', '1', '2', '3', '4', '5', '6', '7', '8', '9'].includes(k)) combo = 'ctrl+' + k;
    else if (input.alt && ['arrowleft', 'arrowright', 'home', 'd'].includes(k)) combo = 'alt+' + k;
    else if (input.shift && k === 'f5') combo = 'shift+f5';
    else if (['f3', 'f5', 'f6', 'f11', 'f12'].includes(k)) combo = k;
    else if (k === 'escape') combo = 'escape';
    if (!combo) return;
    if (combo === 'escape') { const host = wc.hostWebContents; if (host) host.send('shortcut', combo); return; }
    ev.preventDefault();
    const host = wc.hostWebContents;
    if (host && !host.isDestroyed()) host.send('shortcut', combo);
  });

  // Right-click menu
  wc.on('context-menu', (_ev, p) => {
    const host = wc.hostWebContents;
    const send = (...a) => { if (host && !host.isDestroyed()) host.send(...a); };
    const t = [];
    if (p.linkURL) {
      t.push({ label: 'Open link in new tab', click: () => send('open-tab', p.linkURL, true) });
      t.push({ label: 'Open link in new window', click: () => createWindow({ url: p.linkURL }) });
      t.push({ label: 'Open link in Incognito window', click: () => createWindow({ incog: true, url: p.linkURL }) });
      t.push({ label: 'Copy link address', click: () => clipboard.writeText(p.linkURL) });
      if (p.linkText && p.linkText.trim()) t.push({ label: 'Copy link text', click: () => clipboard.writeText(p.linkText.trim()) });
      t.push({ label: 'Save link as…', click: () => wc.downloadURL(p.linkURL) });
      t.push({ type: 'separator' });
    }
    if (p.mediaType === 'image' && p.srcURL) {
      t.push({ label: 'Open image in new tab', click: () => send('open-tab', p.srcURL, true) });
      t.push({ label: 'Save image as…', click: () => wc.downloadURL(p.srcURL) });
      t.push({ label: 'Copy image', click: () => wc.copyImageAt(p.x, p.y) });
      t.push({ label: 'Copy image address', click: () => clipboard.writeText(p.srcURL) });
      if (/^https?:/i.test(p.srcURL)) t.push({ label: 'Search image with Google', click: () => send('open-tab', 'https://lens.google.com/uploadbyurl?url=' + encodeURIComponent(p.srcURL)) });
      t.push({ type: 'separator' });
    }
    if (p.mediaType === 'video' || p.mediaType === 'audio') {
      const fr = p.frame || wc.mainFrame;
      const run = (js) => { try { fr.executeJavaScript(js, true).catch(() => {}); } catch (x) {} };
      const pick = "[...document.querySelectorAll('video,audio')].sort((a,b)=>(b.clientWidth*b.clientHeight)-(a.clientWidth*a.clientHeight))[0]";
      t.push({ label: 'Loop', type: 'checkbox', checked: !!(p.mediaFlags && p.mediaFlags.isLooping), click: () => run('(()=>{const v=' + pick + ';if(v)v.loop=!v.loop})()') });
      t.push({ label: 'Show controls', type: 'checkbox', checked: !!(p.mediaFlags && p.mediaFlags.isControlsVisible), click: () => run('(()=>{const v=' + pick + ';if(v)v.controls=!v.controls})()') });
      if (p.mediaType === 'video') t.push({ label: 'Picture in picture', click: () => run("(()=>{if(document.pictureInPictureElement){document.exitPictureInPicture();return}const v=[...document.querySelectorAll('video')].sort((a,b)=>(b.clientWidth*b.clientHeight)-(a.clientWidth*a.clientHeight))[0];if(v)v.requestPictureInPicture().catch(()=>{})})()") });
      if (p.srcURL && !p.srcURL.startsWith('blob:')) t.push({ label: (p.mediaType === 'video' ? 'Save video as…' : 'Save audio as…'), click: () => wc.downloadURL(p.srcURL) });
      t.push({ type: 'separator' });
    }
    if (p.selectionText && p.selectionText.trim()) {
      const s = p.selectionText.trim();
      t.push({ label: 'Copy', role: 'copy' });
      t.push({ label: `Search Google for “${s.length > 24 ? s.slice(0, 24) + '…' : s}”`, click: () => send('search-tab', s) });
      t.push({ label: 'Translate selection to Hindi', click: () => send('open-tab', 'https://translate.google.com/?sl=auto&tl=hi&op=translate&text=' + encodeURIComponent(s.slice(0, 4000))) });
      t.push({ label: 'Print…', click: () => send('shortcut', 'ctrl+p') });
      t.push({ type: 'separator' });
    }
    if (p.isEditable) {
      if (p.misspelledWord && p.dictionarySuggestions.length) {
        p.dictionarySuggestions.slice(0, 4).forEach(sg => t.push({ label: sg, click: () => wc.replaceMisspelling(sg) }));
        t.push({ type: 'separator' });
      }
      t.push({ label: 'Undo', role: 'undo' }, { label: 'Redo', role: 'redo' }, { type: 'separator' }, { label: 'Cut', role: 'cut' }, { label: 'Copy', role: 'copy' }, { label: 'Paste', role: 'paste' }, { label: 'Paste as plain text', role: 'pasteAndMatchStyle' }, { label: 'Select all', role: 'selectAll' });
      if (process.platform === 'win32' || process.platform === 'darwin') t.push({ type: 'separator' }, { label: 'Emoji', click: () => app.showEmojiPanel() });
      t.push({ type: 'separator' });
    }
    if (!p.linkURL && !p.isEditable && !(p.selectionText && p.selectionText.trim())) {
      t.push({ label: 'Back', enabled: wc.navigationHistory.canGoBack(), click: () => wc.navigationHistory.goBack() });
      t.push({ label: 'Forward', enabled: wc.navigationHistory.canGoForward(), click: () => wc.navigationHistory.goForward() });
      t.push({ label: 'Reload', click: () => wc.reload() });
      t.push({ type: 'separator' });
      t.push({ label: 'Save as…', click: () => send('shortcut', 'save-page') });
      t.push({ label: 'Print…', click: () => send('shortcut', 'ctrl+p') });
      if (/^https?:/i.test(wc.getURL())) {
        t.push({ label: 'Search with Google Lens', click: () => send('shortcut', 'lens') });
        t.push({ label: 'Translate to Hindi', click: () => send('shortcut', 'translate') });
        t.push({ label: 'Create QR Code for this page', click: () => send('shortcut', 'qr') });
      }
      t.push({ label: 'Copy page link', click: () => clipboard.writeText(wc.getURL()) });
      t.push({ type: 'separator' });
      if (!/^view-source:/i.test(wc.getURL())) t.push({ label: 'View page source', click: () => send('open-tab', 'view-source:' + wc.getURL()) });
    }
    t.push({ label: 'Inspect', click: () => wc.inspectElement(p.x, p.y) });
    Menu.buildFromTemplate(t).popup({ window: BrowserWindow.fromWebContents(host || wc) || undefined });
  });
});

// ---------- IPC from UI ----------
ipcMain.handle('asset', (_e, name) => {
  if (!/^[a-z0-9_-]+\.js$/i.test(name)) return '';
  try { return fs.readFileSync(path.join(__dirname, 'pages', name), 'utf8'); } catch (e) { return ''; }
});
ipcMain.on('adblock', (_e, on) => { adblockOn = !!on; });
ipcMain.on('new-window', (_e, opts) => createWindow(opts || {}));
ipcMain.on('dl-action', (_e, id, act, p) => {
  const item = downloads.get(id);
  if (act === 'cancel' && item) item.cancel();
  else if (act === 'pause' && item) item.pause();
  else if (act === 'resume' && item && item.canResume()) item.resume();
  else if (act === 'open' && p) shell.openPath(p);
  else if (act === 'show' && p) shell.showItemInFolder(p);
  else if (act === 'folder') shell.openPath(dlDir());
});
ipcMain.on('default-browser', () => {
  shell.openExternal('ms-settings:defaultapps?registeredAppUser=Baatora').catch(() => shell.openExternal('ms-settings:defaultapps'));
});
ipcMain.on('open-external', (_e, url) => { if (/^(https?|mailto|tel):/i.test(url)) shell.openExternal(url); });
ipcMain.handle('clear-data', async (_e, what) => {
  const ses = session.fromPartition(NORMAL);
  if (what.cache) await ses.clearCache();
  if (what.cookies) await ses.clearStorageData({ storages: ['cookies', 'localstorage', 'indexdb', 'serviceworkers', 'cachestorage', 'websql', 'filesystem'] });
  return true;
});
ipcMain.handle('save-page', async (e, wcId) => {
  const wc = webContents.fromId(wcId);
  if (!wc) return false;
  const win = BrowserWindow.fromWebContents(e.sender);
  const safe = (wc.getTitle() || 'page').replace(/[\\/:*?"<>|]+/g, ' ').slice(0, 80);
  const r = await dialog.showSaveDialog(win, { defaultPath: path.join(app.getPath('downloads'), safe + '.html'), filters: [{ name: 'Web page', extensions: ['html'] }] });
  if (r.canceled || !r.filePath) return false;
  await wc.savePage(r.filePath, 'HTMLComplete');
  return true;
});
ipcMain.on('title-color', (e, color, symbolColor) => {
  const w = BrowserWindow.fromWebContents(e.sender);
  if (w && w.setTitleBarOverlay) { try { w.setTitleBarOverlay({ color, symbolColor: symbolColor || '#FFFFFF', height: 40 }); } catch (x) {} }
});
ipcMain.on('bt-adblock-on', (e) => { e.returnValue = adblockOn; });
ipcMain.handle('flags', () => FLAGS);
ipcMain.handle('set-flag', (_e, k, v) => {
  if (!/^[a-zA-Z]+$/.test(k) || k === 'extensions') return FLAGS;
  FLAGS[k] = v; writeFlags();
  if (k === 'dnt' || k === 'httpsOnly') readySessions.forEach((p) => applyNetHooks(session.fromPartition(p)));
  if (k === 'secureDns' || k === 'dohProvider') applyDns();
  return FLAGS;
});
// Preload pages: address bar me type karte hi site se connection pehle bana lein (Chrome jaisa)
const preconnDone = new Map();
ipcMain.on('preconnect', (e, url, incog) => {
  try {
    const o = new URL(url); if (!/^https?:$/.test(o.protocol)) return;
    const k = o.origin, now = Date.now();
    if (now - (preconnDone.get(k) || 0) < 20000) return;
    preconnDone.set(k, now);
    session.fromPartition(incog ? INCOG : NORMAL).preconnect({ url: k, numSockets: 2 });
  } catch (x) {}
});
ipcMain.on('relaunch', () => { app.relaunch(); app.quit(); });
// ---------- Settings ke naye kaam ----------
const fromUI = (e) => { try { return e.sender.getType() === 'window'; } catch (x) { return false; } };
ipcMain.handle('pick-dl-dir', async (e) => {
  if (!fromUI(e)) return null;
  const r = await dialog.showOpenDialog(BrowserWindow.fromWebContents(e.sender), { properties: ['openDirectory', 'createDirectory'], defaultPath: dlDir() });
  if (r.canceled || !r.filePaths[0]) return null;
  FLAGS.dlDir = r.filePaths[0]; writeFlags();
  return FLAGS.dlDir;
});
ipcMain.handle('set-lang', (e, lang) => {
  if (!fromUI(e)) return false;
  FLAGS.lang = String(lang || '').slice(0, 80); writeFlags();
  [NORMAL, INCOG].forEach((p) => { if (readySessions.has(p)) { const s = session.fromPartition(p); try { s.setUserAgent(s.getUserAgent(), FLAGS.lang || app.getLocale()); } catch (x) {} } });
  return true;
});
ipcMain.handle('spell-info', () => { const s = session.fromPartition(NORMAL); return { enabled: FLAGS.spell !== false, langs: s.getSpellCheckerLanguages(), available: s.availableSpellCheckerLanguages }; });
ipcMain.handle('spell-set', (e, enabled, langs) => {
  if (!fromUI(e)) return false;
  FLAGS.spell = !!enabled; if (Array.isArray(langs)) FLAGS.spellLangs = langs.slice(0, 3); writeFlags();
  [NORMAL, INCOG].forEach((p) => { if (!readySessions.has(p)) return; const s = session.fromPartition(p); try { s.setSpellCheckerEnabled(FLAGS.spell); const av = s.availableSpellCheckerLanguages; const sl = (FLAGS.spellLangs || []).filter((l) => av.includes(l)); if (sl.length) s.setSpellCheckerLanguages(sl); } catch (x) {} });
  return true;
});
ipcMain.handle('ext-list', () => (FLAGS.extensions || []).map((p) => {
  let m = {}; try { m = JSON.parse(fs.readFileSync(path.join(p, 'manifest.json'), 'utf8')); } catch (e) {}
  let icon = '';
  try {
    const ic = m.icons || {}; const k = Object.keys(ic).sort((a, b) => (+b) - (+a))[0];
    if (k) { const f = path.join(p, ic[k]); if (fs.existsSync(f)) icon = 'data:image/png;base64,' + fs.readFileSync(f).toString('base64'); }
  } catch (e) {}
  const msg = (v) => (typeof v === 'string' && !/^__MSG_/.test(v) ? v : '');
  return { path: p, name: extName(p), desc: msg(m.description), version: m.version || '', icon, on: !(FLAGS.extOff || []).includes(p) };
}));
ipcMain.handle('ext-toggle', async (e, p, on) => {
  if (!fromUI(e) || !(FLAGS.extensions || []).includes(p)) return false;
  FLAGS.extOff = (FLAGS.extOff || []).filter((x) => x !== p);
  const ses = session.fromPartition(NORMAL);
  const api = ses.extensions || ses;
  if (on) { if (!(await loadExt(ses, p))) return false; }
  else { FLAGS.extOff.push(p); try { const x = api.getAllExtensions().find((y) => y.path === p); if (x) api.removeExtension(x.id); } catch (x) {} }
  writeFlags(); return true;
});
ipcMain.handle('cache-size', async () => { try { return await session.fromPartition(NORMAL).getCacheSize(); } catch (e) { return 0; } });
ipcMain.handle('import-bookmarks', async (e) => {
  if (!fromUI(e)) return null;
  const r = await dialog.showOpenDialog(BrowserWindow.fromWebContents(e.sender), { title: 'Import bookmarks', properties: ['openFile'], filters: [{ name: 'Bookmarks HTML file', extensions: ['html', 'htm'] }] });
  if (r.canceled || !r.filePaths[0]) return null;
  try {
    const h = fs.readFileSync(r.filePaths[0], 'utf8'); const out = [];
    const re = /<A\s[^>]*HREF="([^"]+)"[^>]*>([^<]*)<\/A>/gi; let m;
    while ((m = re.exec(h)) && out.length < 5000) if (/^https?:/i.test(m[1])) out.push({ u: m[1], t: m[2].replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&#39;/g, "'") });
    return out;
  } catch (x) { return []; }
});
ipcMain.handle('ext-add', async (e) => {
  if (!fromUI(e)) return { ok: false, err: 'Not allowed' };
  const r = await dialog.showOpenDialog(BrowserWindow.fromWebContents(e.sender), { title: 'Select the extension directory (with manifest.json)', properties: ['openDirectory'] });
  if (r.canceled || !r.filePaths[0]) return { ok: false, err: '' };
  const p = r.filePaths[0];
  if (!fs.existsSync(path.join(p, 'manifest.json'))) return { ok: false, err: 'Manifest file is missing in this folder' };
  const x = await loadExt(session.fromPartition(NORMAL), p);
  if (!x) return { ok: false, err: 'Failed to load extension' };
  if (!FLAGS.extensions.includes(p)) FLAGS.extensions.push(p);
  writeFlags();
  return { ok: true };
});
ipcMain.handle('ext-remove', (e, p) => {
  if (!fromUI(e)) return false;
  FLAGS.extensions = (FLAGS.extensions || []).filter((x) => x !== p); writeFlags();
  try { const api = session.fromPartition(NORMAL); const a = api.extensions || api; const ex = (a.getAllExtensions ? a.getAllExtensions() : []).find((x) => x.path === p); if (ex) a.removeExtension(ex.id); } catch (x) {}
  return true;
});
// Password manager (Windows ke encryption se)
const vaultFile = () => path.join(app.getPath('userData'), 'baatora-vault.json');
function vaultRead() { try { return JSON.parse(fs.readFileSync(vaultFile(), 'utf8')); } catch (e) { return []; } }
function vaultWrite(v) { try { fs.writeFileSync(vaultFile(), JSON.stringify(v)); } catch (e) {} }
ipcMain.handle('pw-list', (e) => fromUI(e) ? vaultRead().map((x) => ({ id: x.id, site: x.site, user: x.user })) : []);
ipcMain.handle('pw-add', (e, site, user, pw) => {
  if (!fromUI(e)) return { ok: false, err: 'Not allowed' };
  if (!safeStorage.isEncryptionAvailable()) return { ok: false, err: 'Encryption isn’t available on this computer' };
  site = String(site || '').trim().slice(0, 200); user = String(user || '').trim().slice(0, 200); pw = String(pw || '').slice(0, 500);
  if (!site || !pw) return { ok: false, err: 'Site and password are required' };
  const v = vaultRead();
  v.unshift({ id: Date.now() + '' + Math.floor(Math.random() * 1000), site, user, pw: safeStorage.encryptString(pw).toString('base64') });
  vaultWrite(v.slice(0, 500));
  return { ok: true };
});
ipcMain.handle('pw-get', (e, id) => {
  if (!fromUI(e)) return null;
  const x = vaultRead().find((y) => y.id === id); if (!x) return null;
  try { return safeStorage.decryptString(Buffer.from(x.pw, 'base64')); } catch (err) { return null; }
});
ipcMain.handle('pw-del', (e, id) => { if (!fromUI(e)) return false; vaultWrite(vaultRead().filter((y) => y.id !== id)); return true; });
ipcMain.on('open-os', (_e, u) => { if (/^ms-settings:[a-z-]+$/i.test(u)) shell.openExternal(u).catch(() => {}); });
ipcMain.on('reset-flags', (e) => { if (!fromUI(e)) return; try { fs.rmSync(FLAGS_FILE, { force: true }); } catch (x) {} app.relaunch(); app.quit(); });

ipcMain.handle('clear-site', async (_e, origin, incog) => {
  try { await session.fromPartition(incog ? INCOG : NORMAL).clearStorageData({ origin }); return true; } catch (e) { return false; }
});
ipcMain.on('fullscreen', (e, on) => { const w = BrowserWindow.fromWebContents(e.sender); if (w) w.setFullScreen(on === undefined ? !w.isFullScreen() : !!on); });
ipcMain.on('close-window', (e) => { const w = BrowserWindow.fromWebContents(e.sender); if (w) w.close(); });
ipcMain.on('quit', () => app.quit());
ipcMain.handle('info', () => ({ version: app.getVersion(), electron: process.versions.electron, chrome: process.versions.chrome, downloads: dlDir() }));

// ---------- App start ----------
// ---------- Auto update (Chrome jaisa: "Updating Baatora…") ----------
let autoUpdater = null;
try { autoUpdater = require('electron-updater').autoUpdater; } catch (e) {}
const UPD = { state: 'idle', pct: 0, version: '', err: '' };
function updSend() { BrowserWindow.getAllWindows().forEach((w) => { try { w.webContents.send('upd', UPD); } catch (e) {} }); }
function updSet(o) { Object.assign(UPD, o); updSend(); }
if (autoUpdater) {
  autoUpdater.autoDownload = true;
  autoUpdater.autoInstallOnAppQuit = true;
  autoUpdater.on('checking-for-update', () => updSet({ state: 'checking', err: '' }));
  autoUpdater.on('update-available', (i) => updSet({ state: 'downloading', pct: 0, version: (i && i.version) || '' }));
  autoUpdater.on('update-not-available', () => updSet({ state: 'uptodate', pct: 0 }));
  autoUpdater.on('download-progress', (p) => updSet({ state: 'downloading', pct: Math.round((p && p.percent) || 0) }));
  autoUpdater.on('update-downloaded', (i) => updSet({ state: 'ready', pct: 100, version: (i && i.version) || UPD.version }));
  autoUpdater.on('error', (e) => updSet({ state: 'error', err: String((e && e.message) || e).slice(0, 200) }));
}
function updCheck() {
  if (!autoUpdater || !app.isPackaged) { updSet({ state: 'uptodate' }); return; }
  if (UPD.state === 'downloading' || UPD.state === 'ready') return;
  autoUpdater.checkForUpdates().catch((e) => updSet({ state: 'error', err: String((e && e.message) || e).slice(0, 200) }));
}
ipcMain.handle('upd-state', () => UPD);
ipcMain.on('open-certs', () => { if (process.platform === 'win32') shell.openPath(path.join(process.env.SystemRoot || 'C:\\Windows', 'System32', 'certmgr.msc')).catch(() => {}); });
ipcMain.on('upd-check', () => updCheck());
ipcMain.on('upd-install', () => { if (autoUpdater && UPD.state === 'ready') { try { autoUpdater.quitAndInstall(true, true); } catch (e) {} } });

app.whenReady().then(() => {
  applyDns();
  setTimeout(updCheck, 15000);
  setInterval(updCheck, 6 * 3600e3);
  if (!gotLock) return;
  Menu.setApplicationMenu(null);
  nativeTheme.themeSource = 'system';
  setupSession(NORMAL);
  createWindow({ url: urlFromArgs(process.argv) });
  app.on('activate', () => { if (BrowserWindow.getAllWindows().length === 0) createWindow(); });
});
app.on('window-all-closed', () => { app.quit(); });
