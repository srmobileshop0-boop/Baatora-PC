// Baatora — website ke shuru me chalta hai (page ke scripts se pehle).
// Sirf Baatora ke apne pages (Settings, History, Extensions, Downloads) ko browser se baat karne ka rasta milta hai.
const { contextBridge, ipcRenderer } = require('electron');

const isInternal = location.protocol === 'file:' && /\/pages\/(internal|downloads)\.html$/i.test(decodeURIComponent(location.pathname));
if (isInternal) {
  let seq = 0;
  const pend = new Map();
  const subs = [];
  ipcRenderer.on('bt-int-reply', (_e, id, ok, data) => {
    const p = pend.get(id); if (!p) return;
    pend.delete(id); if (ok) p.res(data); else p.rej(new Error(String(data)));
  });
  ipcRenderer.on('bt-int-push', (_e, ev, data) => { subs.forEach((f) => { try { f(ev, data); } catch (x) {} }); });
  contextBridge.exposeInMainWorld('btHost', {
    call: (m, ...a) => new Promise((res, rej) => { const id = ++seq; pend.set(id, { res, rej }); ipcRenderer.sendToHost('bt-int', id, String(m), a); }),
    on: (f) => { if (typeof f === 'function') subs.push(f); }
  });
}
