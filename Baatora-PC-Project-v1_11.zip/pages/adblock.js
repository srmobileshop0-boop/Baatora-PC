(function(){
if(window.__btgen)return;window.__btgen=1;
try{Notification.requestPermission=function(){return Promise.resolve('denied')};}catch(e){}
try{Object.defineProperty(Notification,'permission',{get:function(){return 'denied'}});}catch(e){}
var host=(location.hostname||'').toLowerCase();
if(/(^|\.)(youtube\.com|google\.[a-z.]+|instagram\.com|facebook\.com|twitter\.com|x\.com|wikipedia\.org|amazon\.[a-z.]+|flipkart\.com|whatsapp\.com|github\.com)$/.test(host))return;
var adHost=/(doubleclick|googlesyndication|adservice\.google|exoclick|exosrv|exdynsrv|juicyads|trafficstars|clickadu|hilltopads|adcash|popcash|propellerads|onclkds|clickaine|realsrv|magsrv|tsyndicate|adsterra|a-ads|adskeeper|richpush|admaven|ad-maven|bidvertiser|plugrush|ero-advertising|yllix|popads|monetag|profitableratecpm|highperformanceformat|effectivegatecpm|oclasrv|taboola|outbrain|mgid|revcontent|zedo|criteo|moatads|adnxs|4rabet|1xbet|mostbet|1win|melbet|parimatch|linebet|betwinner)/i;
var bad=/(welcome pack|welcome bonus|bonus up to|\u20b9\s?[\d,]+\s?(welcome )?bonus|\d{2,4}\s?% bonus|casino|jackpot|you(?:'|\u2019)?ve won|you have won|congratulations.{0,40}(prize|won|winner)|click allow|press allow|allow notifications|your (phone|device) (is|has been) (infected|hacked)|virus detected)/i;
var fakeHuman=/(verify you.?re human|i.?m human|i am human)/i;
function kill(e){try{e.style.setProperty('display','none','important');e.style.setProperty('pointer-events','none','important');}catch(x){}}
function rect(e){return e.getBoundingClientRect();}
var adLbl=/^(ad|ads|advert|advertisement|sponsored|\u0935\u093f\u091c\u094d\u091e\u093e\u092a\u0928|\u092a\u094d\u0930\u093e\u092f\u094b\u091c\u093f\u0924)$/i;
var skipRe=/^(skip|skip ad|skip ads|skip in \d+|\u091b\u094b\u0921\u093c\u0947\u0902|\u0938\u094d\u0915\u093f\u092a)/i;
var sped=null,spedBy=null;
/* Pakka ad hone ke nishaan: player par ad wali class, ya video ke UPAR "Skip Ad"/ad ginti likhi ho.
   Sirf "Ad" shabd kahin bhi hone se video tez nahi karte (warna asli video bhaagne lagta tha). */
var adCls=/(^|[\s_-])(ad-playing|ads-playing|ad-showing|vjs-ad-playing|vjs-ad-loading|jw-flag-ads|fp-ad|ima-ad-playing|vast-playing|preroll-playing|is-ad|playing-ad|fluid_vast)([\s_-]|$)/i;
var cntRe=/^(ad|ads|advertisement|sponsored|विज्ञापन)\s*[:·\-|]?\s*(\d|\(|in\s+\d|1 of|0:\d)/i;
function inRect(e,r){var q=e.getBoundingClientRect();if(q.width<=0||q.height<=0)return false;
 var cx=q.left+q.width/2,cy=q.top+q.height/2;return cx>=r.left&&cx<=r.right&&cy>=r.top&&cy<=r.bottom;}
function adState(v,c,r){
 /* 1) player/ancestor par ad class */
 for(var e=v,i=0;e&&i<7;e=e.parentElement,i++){if(typeof e.className==='string'&&adCls.test(e.className))return {skip:null,strong:true};}
 /* 2) video ke upar skip button ya "Ad 0:05" jaisa countdown */
 var skip=null,count=false;
 try{var els=c.querySelectorAll('button,div,a,span,p');var m=Math.min(els.length,350);
  for(var k=0;k<m;k++){var el=els[k];if(el.children.length>2)continue;var t=(el.textContent||'').trim();if(!t||t.length>32)continue;
   if(/^(skip|skip ads?|skip ad\W*|skip in \d+.*|\u091b\u094b\u0921\u093c\u0947\u0902|\u0938\u094d\u0915\u093f\u092a)$/i.test(t)&&inRect(el,r)){skip=el;}
   else if(cntRe.test(t)&&inRect(el,r)){count=true;}}
 }catch(x){}
 if(skip||count)return {skip:skip,strong:count};
 return null;
}
function playerAd(){
 if(document.hidden)return;
 try{
  var vs=document.getElementsByTagName('video');if(!vs.length)return;
  for(var k=0;k<vs.length;k++){
   var v=vs[k];if(v.paused&&sped!==v)continue;var r=v.getBoundingClientRect();if(r.width<120||r.height<80)continue;
   var c=v.parentElement;
   for(var u=0;u<4&&c&&c.parentElement&&c.parentElement!==document.body;u++)c=c.parentElement;
   if(!c)continue;
   var st=adState(v,c,r);
   if(st){
    if(st.skip){try{st.skip.click();}catch(e){}}
    /* sirf chhote ad clip (1.5 min se kam) ko hi mute + tez karo; asli lamba video kabhi nahi */
    var d=v.duration;
    if(st.strong&&isFinite(d)&&d>0&&d<90){
     if(sped!==v){sped=v;spedBy={m:v.muted,r:v.playbackRate||1,src:v.currentSrc};}
     v.muted=true;try{v.playbackRate=8;}catch(e){}
    }
   }else if(sped===v){
    try{v.muted=spedBy?spedBy.m:false;v.playbackRate=1;}catch(e){}sped=null;spedBy=null;
   }
   /* video ka source badal gaya (ad khatam, asli video aaya) to speed normal */
   if(sped===v&&spedBy&&v.currentSrc!==spedBy.src&&!st){try{v.playbackRate=1;v.muted=spedBy.m;}catch(e){}sped=null;spedBy=null;}
   if(sped!==v&&v.playbackRate>2&&v.__btFixed!==1){try{v.playbackRate=1;}catch(e){}v.__btFixed=1;}
  }
 }catch(x){}
}
setInterval(playerAd,800);
/* "Ad / Sponsored / Vigyapan" likha hua dabba (player ke bahar) hata do */
function killSponsored(){
 try{
  if(!document.body)return;
  var els=document.body.querySelectorAll('span,div,a,p,small');var m=Math.min(els.length,1500);
  for(var i=0;i<m;i++){var e=els[i];if(e.children.length||e.__bts)continue;
   var t=(e.textContent||'').trim();if(!t||t.length>20||!adLbl.test(t))continue;
   e.__bts=1;
   if(e.closest('video')||e.closest('[class*=player],[id*=player]'))continue;
   var c=e;
   for(var u=0;u<3&&c.parentElement&&c.parentElement!==document.body;u++){
    var p=c.parentElement;
    if(p.getBoundingClientRect().height>innerHeight*0.85||p.querySelector('video,input,nav,form')||p.querySelectorAll('a[href]').length>6)break;
    c=p;
   }
   kill(c);
  }
 }catch(x){}
}
function killPromoLinks(){
 try{document.querySelectorAll('a[href*="faphouse.com"]').forEach(function(a){
  kill(a);var p=a.parentElement;if(p&&p!==document.body&&(p.innerText||'').length<90)kill(p);
 });}catch(x){}
}
var pending=0,lastScan=0;
/* Page ko bina atkaye: scan sirf tab jab browser khali ho (idle), aur 2.5 sec me ek baar se zyada nahi */
var idle=window.requestIdleCallback?function(f){requestIdleCallback(f,{timeout:1500});}:function(f){setTimeout(f,200);};
function scan(){
 pending=0;
 if(document.hidden)return;
 lastScan=Date.now();
 try{
  var killed=0;
 killSponsored();killPromoLinks();
  document.querySelectorAll('iframe').forEach(function(f){var s=f.src||'';if(s&&adHost.test(s)){kill(f);killed++;}});
  document.querySelectorAll('ins.adsbygoogle,[id^="google_ads"],[class*="popunder"],[class*="pop-under"],[id*="popunder"],[class*="ad-overlay"],[id*="ad-overlay"],a[href*="exoclick"],a[href*="juicyads"],a[href*="clickadu"],a[href*="adsterra"],a[href*="hilltopads"]').forEach(function(e){kill(e);});
  if(!document.body)return;
  var all=document.body.querySelectorAll('div,section,aside,a,iframe,ins,span');
  var lim=Math.min(all.length,1800);
  for(var i=0;i<lim;i++){
   var e=all[i];
   if(e.style&&e.style.display==='none')continue;
   var cs=getComputedStyle(e);
   var pos=cs.position;
   if(pos!=='fixed'&&pos!=='absolute'&&pos!=='sticky')continue;
   var z=parseInt(cs.zIndex)||0;
   if(z<100)continue;
   var r=rect(e);
   if(r.width<40||r.height<20)continue;
   var t=(e.innerText||'').slice(0,800);
   if(t){
     if(bad.test(t)){kill(e);killed++;continue;}
     if(fakeHuman.test(t)&&e.querySelector('input[type=password]')){kill(e);killed++;continue;}
   }else if(pos==='fixed'||pos==='absolute'){
     var full=r.width>=innerWidth*0.9&&r.height>=innerHeight*0.9;
     var clear=parseFloat(cs.opacity)<=0.05||cs.backgroundColor==='rgba(0, 0, 0, 0)'||cs.backgroundColor==='transparent';
     if(full&&z>=1000&&clear&&(e.tagName==='A'||e.tagName==='DIV'||e.tagName==='IFRAME')&&!e.querySelector('video,canvas')){kill(e);killed++;}
   }
  }
  if(killed>0){
   for(var j=0;j<lim;j++){
    var b=all[j];var c2=getComputedStyle(b);
    if(c2.position==='fixed'&&!(b.innerText||'').trim()&&(parseInt(c2.zIndex)||0)>=100){
     var rr=rect(b);
     if(rr.width>=innerWidth*0.9&&rr.height>=innerHeight*0.9&&!b.querySelector('video,canvas,img')) kill(b);
    }
   }
   document.body.style.setProperty('overflow','auto','important');
   document.documentElement.style.setProperty('overflow','auto','important');
  }
 }catch(x){}
}
function later(){if(pending)return;pending=1;var w=Math.max(700,2500-(Date.now()-lastScan));setTimeout(function(){idle(scan);},w);}
document.addEventListener('click',function(ev){
 try{var a=ev.target&&ev.target.closest&&ev.target.closest('a[href]');
  if(a&&a.target==='_blank'&&adHost.test(a.href)){ev.preventDefault();ev.stopPropagation();}}catch(e){}
},true);
try{new MutationObserver(later).observe(document.documentElement,{childList:true,subtree:true});}catch(e){}
var n=0,iv=setInterval(function(){idle(scan);if(++n>12)clearInterval(iv);},2500);
idle(scan);
document.addEventListener('visibilitychange',function(){if(!document.hidden)later();});
})();
