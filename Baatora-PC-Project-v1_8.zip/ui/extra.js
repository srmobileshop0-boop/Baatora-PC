/* Baatora PC — Chrome jaise aur kaam:
   Location/Camera/Mic ki ijaazat ka prompt, address bar me icons, Site settings,
   Tab ka right-click menu (Pin, Duplicate, Mute...), QR code, Translate, Desktop shortcut */
'use strict';

/* ---------------- Permissions ---------------- */
const PERM_INFO = {
  location: ['loc', 'Location', 'Aapki location jaanna'],
  camera: ['cam', 'Camera', 'Aapka camera use karna'],
  microphone: ['mic', 'Microphone', 'Aapka microphone use karna'],
  notifications: ['bell', 'Notifications', 'Notifications dikhana'],
  clipboard: ['copy', 'Clipboard', 'Copy kiya hua text/photo dekhna'],
  midi: ['ext', 'MIDI devices', 'MIDI devices ko control karna'],
  windows: ['win', 'Window management', 'Aapki screens ki jaankari lena'],
  idle: ['hist', 'Device use', 'Jaanna ki aap device use kar rahe hain ya nahi']
};
const pIcon = (k) => '<svg viewBox="0 0 24 24"><use href="#i-' + (PERM_INFO[k] || ['info'])[0] + '"/></svg>';
let permQ = [], permShown = null, SITEP = {};
function loadSitePerms() { return window.bt.sitePerms().then((x) => { SITEP = x || {}; return SITEP; }).catch(() => SITEP); }
loadSitePerms();
function originOf(u) { try { const o = new URL(u).origin; return o === 'null' ? '' : o; } catch (e) { return ''; } }

window.bt.on('perm-ask', (req) => { permQ.push(req); showPermPrompt(); });
window.bt.on('perm-cancel', (id) => {
  permQ = permQ.filter((x) => x.id !== id);
  if (permShown && permShown.id === id) { permShown = null; $('permpop').classList.remove('show'); showPermPrompt(); }
});
window.bt.on('perm-used', (wcId, keys) => {
  const t = tabs.find((x) => x.wcId === wcId); if (!t) return;
  const o = originOf(t.url);
  if (t.usedOrigin !== o) { t.used = new Set(); t.usedOrigin = o; }
  (keys || []).forEach((k) => t.used.add(k));
  if (t === cur) paintPermIc();
});

function showPermPrompt() {
  const pop = $('permpop');
  if (permShown) return;
  const req = cur && permQ.find((x) => x.wcId === cur.wcId);
  if (!req) { pop.classList.remove('show'); return; }
  permShown = req;
  let host = req.origin; try { host = new URL(req.origin).host; } catch (e) {}
  const loc = req.keys.includes('location');
  pop.innerHTML =
    '<button class="pm-x" data-h="dismiss" title="Band karein">✕</button>' +
    '<div class="pm-h"><b>' + esc(host) + '</b> ye chahta hai:</div>' +
    req.keys.map((k) => '<div class="pm-row">' + pIcon(k) + '<span>' + esc((PERM_INFO[k] || [0, 0, k])[2]) + '</span></div>').join('') +
    (loc ? '<div class="pm-note">Location na mile to Windows me Location chalu karein. <a href="#" data-h="winloc">Windows Location settings</a></div>' : '') +
    (INCOG ? '<div class="pm-note">🕶 Incognito: “Allow” sirf is window ke band hone tak rahega</div>' : '') +
    '<div class="pm-btns">' +
      '<button data-h="allow">Site par rehte hue Allow karein<small>Allow while visiting the site</small></button>' +
      '<button data-h="once">Sirf is baar Allow karein<small>Allow this time</small></button>' +
      '<button data-h="block">Kabhi Allow nahi<small>Never allow</small></button>' +
    '</div>';
  pop.querySelectorAll('[data-h]').forEach((b) => b.onclick = (e) => {
    e.preventDefault();
    const h = b.dataset.h;
    if (h === 'winloc') { window.bt.openOs('ms-settings:privacy-location'); return; }
    window.bt.permReply(req.id, h);
    permQ = permQ.filter((x) => x.id !== req.id);
    permShown = null; pop.classList.remove('show');
    if (h === 'block') toast('🚫 ' + host + ' ke liye block kar diya — 🔒 icon se badal sakte hain');
    if (h === 'allow' || h === 'block') setTimeout(loadSitePerms, 300);
    showPermPrompt();
  });
  pop.classList.add('show');
}

/* Address bar me 📍 🎥 🎤 icons (jab site use kar rahi ho) */
function paintPermIc() {
  const box = $('permic'); if (!box) return;
  const t = cur;
  if (!t || !t.used || t.usedOrigin !== originOf(t.url)) { box.innerHTML = ''; return; }
  box.innerHTML = [...t.used].filter((k) => PERM_INFO[k]).map((k) => '<button class="pic" title="' + esc(PERM_INFO[k][1]) + ' ki ijaazat — badalne ke liye click karein">' + pIcon(k) + '</button>').join('');
  box.querySelectorAll('button').forEach((b) => b.onmousedown = (e) => { e.preventDefault(); e.stopPropagation(); siteInfo(); });
}
function onTabSelect() { paintTabState(); paintPermIc(); if (permShown && (!cur || permShown.wcId !== cur.wcId)) { permShown = null; $('permpop').classList.remove('show'); } showPermPrompt(); }

/* 🔒 popup ke andar: is site ki ijaazatein */
function permSectionHtml(origin) {
  if (!origin || !/^https?:/i.test(origin)) return '';
  const cfg = SITEP[origin] || {};
  const keys = ['location', 'camera', 'microphone', 'notifications'].concat(Object.keys(cfg).filter((k) => !['location', 'camera', 'microphone', 'notifications'].includes(k)));
  return '<div class="sp-perm"><b class="sp-pt">Is site ki ijaazat (Permissions)</b>' +
    keys.map((k) => '<div class="sp-prow">' + pIcon(k) + '<span>' + esc((PERM_INFO[k] || [0, k])[1]) + '</span>' +
      '<select data-pk="' + k + '">' + selOpts([['', 'Poochhein (default)'], ['allow', 'Allow'], ['block', 'Block']], cfg[k] || '') + '</select></div>').join('') +
    '<div class="sp-btns"><button data-x="siteset">⚙ Site settings</button><button data-x="reload2" class="sp-rl" style="display:none">↻ Badlav lagane ke liye Reload</button></div></div>';
}
function bindPermSection(p, origin) {
  p.querySelectorAll('select[data-pk]').forEach((s) => s.onchange = async () => {
    SITEP = await window.bt.sitePermSet(origin, s.dataset.pk, s.value) || {};
    const r = p.querySelector('.sp-rl'); if (r) r.style.display = '';
    toast('Save ho gaya');
  });
  const ss = p.querySelector('[data-x="siteset"]'); if (ss) ss.onclick = () => { p.classList.remove('show'); openPanel('settings', 'privacy'); };
  const rl = p.querySelector('[data-x="reload2"]'); if (rl) rl.onclick = () => { p.classList.remove('show'); if (cur) cur.wv.reload(); };
}

/* Settings > Privacy > Site settings ki list */
async function renderSitePerms() {
  const box = $('sitepermList'); if (!box) return;
  await loadSitePerms();
  const list = Object.keys(SITEP).sort();
  if (!list.length) { box.innerHTML = '<div class="none sm">Abhi kisi site ko Allow/Block nahi kiya gaya. Jab koi site Location, Camera ya Mic maangegi, Baatora aapse poochhega.</div>'; return; }
  box.innerHTML = list.map((o) => '<div class="sprow"><img src="' + esc(fav(o)) + '" alt=""><b>' + esc(o.replace(/^https?:\/\//, '')) + '</b><div class="chips">' +
    Object.keys(SITEP[o]).map((k) => '<span class="chip ' + SITEP[o][k] + '">' + pIcon(k) + esc((PERM_INFO[k] || [0, k])[1]) + ': ' + (SITEP[o][k] === 'allow' ? 'Allow' : 'Block') +
      '<button data-o="' + esc(o) + '" data-k="' + esc(k) + '" title="Hatayein (dobara poochhega)">✕</button></span>').join('') + '</div></div>').join('');
  box.querySelectorAll('button[data-o]').forEach((b) => b.onclick = async () => { SITEP = await window.bt.sitePermSet(b.dataset.o, b.dataset.k, '') || {}; renderSitePerms(); toast('Hata diya — site dobara poochhegi'); });
}

/* ---------------- Tab ka right-click menu (Chrome jaisa) ---------------- */
function tabMenu(t, e) {
  e.preventDefault(); closePops();
  const m = $('tabmenu');
  const idx = tabs.indexOf(t);
  const right = tabs.slice(idx + 1).filter((x) => !x.pinned).length;
  const others = tabs.filter((x) => x !== t && !x.pinned).length;
  const items = [
    ['newright', 'Naya tab right me'], '-',
    ['reload', 'Reload'], ['dup', 'Duplicate'], ['pin', t.pinned ? 'Unpin' : 'Pin'], ['mute', t.muted ? 'Site unmute karein' : 'Site mute karein'], ['bm', isBm(t.url) ? 'Bookmark hatayein' : 'Tab bookmark karein'], ['sleep', 'Tab ko sulayein (RAM khali)', '', t === cur || t.sleeping || t.audio], '-',
    ['move', 'Tab nayi window me le jaayein'], '-',
    ['close', 'Band karein', 'Ctrl+W'], ['others', 'Baaki tabs band karein', '', !others], ['right', 'Right ke tabs band karein', '', !right], '-',
    ['reopen', 'Band kiya tab wapas kholein', 'Ctrl+Shift+T', !closed.length]
  ];
  m.innerHTML = items.map((x) => x === '-' ? '<hr>' : '<button data-t="' + x[0] + '"' + (x[3] ? ' disabled' : '') + '>' + esc(x[1]) + (x[2] ? '<kbd>' + x[2] + '</kbd>' : '') + '</button>').join('');
  m.style.left = Math.min(e.clientX, window.innerWidth - 270) + 'px';
  m.style.top = Math.min(e.clientY, window.innerHeight - 380) + 'px';
  m.classList.add('show');
  m.querySelectorAll('button[data-t]').forEach((b) => b.onclick = () => {
    m.classList.remove('show');
    switch (b.dataset.t) {
      case 'newright': newTab(null, { index: tabs.indexOf(t) + 1 }); break;
      case 'reload': if (t.sleeping) wake(t); else t.wv.reload(); break;
      case 'sleep': if (discardTab(t)) toast('💤 Tab so gaya — click karte hi wapas aayega'); else toast('Ye tab abhi nahi so sakta'); break;
      case 'dup': newTab(t.url, { index: tabs.indexOf(t) + 1 }); break;
      case 'pin': togglePin(t); break;
      case 'mute': t.muted = !t.muted; try { t.wv.setAudioMuted(t.muted); } catch (x) {} paintTab(t); toast(t.muted ? '🔇 Tab mute' : '🔊 Tab unmute'); break;
      case 'bm': { const c = cur; cur = t; toggleBm(); cur = c; updStar(); break; }
      case 'move': if (tabs.length > 1) { window.bt.newWindow({ url: t.url }); closeTab(t); } else toast('Ye pehle se akela tab hai'); break;
      case 'close': closeTab(t); break;
      case 'others': tabs.filter((x) => x !== t && !x.pinned).forEach(closeTab); select(t); break;
      case 'right': tabs.slice(tabs.indexOf(t) + 1).filter((x) => !x.pinned).forEach(closeTab); break;
      case 'reopen': { const u = closed.pop(); if (u) newTab(u); break; }
    }
  });
}
document.addEventListener('mousedown', (e) => { if (!e.target.closest('#tabmenu')) $('tabmenu').classList.remove('show'); }, true);
window.addEventListener('blur', () => $('tabmenu').classList.remove('show'));

function togglePin(t) {
  t.pinned = !t.pinned;
  tabs.splice(tabs.indexOf(t), 1);
  const pins = tabs.filter((x) => x.pinned).length;
  const at = pins; // pinned tabs hamesha left me
  tabs.splice(at, 0, t);
  const next = tabs[at + 1];
  $('tabs').insertBefore(t.el, next ? next.el : null);
  layoutTabs(); saveSession();
  toast(t.pinned ? '📌 Tab pin ho gaya' : 'Tab unpin ho gaya');
}

/* ---------------- QR code, Translate, Shortcut, File ---------------- */
function showQr() {
  if (!cur || !/^https?:/i.test(cur.url)) { toast('Is page ka QR code nahi ban sakta'); return; }
  closePops();
  const u = cur.url;
  const img = 'https://api.qrserver.com/v1/create-qr-code/?size=480x480&margin=12&data=' + encodeURIComponent(u);
  const p = $('qrpop');
  p.innerHTML = '<div class="qr-box"><button class="pm-x" data-q="x">✕</button><b>Is page ka QR code</b><small>Phone ke camera se scan karke yahi page kholein</small>' +
    '<div class="qr-img"><img src="' + esc(img) + '" alt="QR code"></div><input class="in" readonly value="' + esc(u) + '">' +
    '<div class="qr-b"><button class="btn" data-q="copy">🔗 Link copy</button><button class="btn pri" data-q="dl">⬇ Download</button></div></div>';
  p.querySelectorAll('[data-q]').forEach((b) => b.onclick = async () => {
    const q = b.dataset.q;
    if (q === 'copy') { try { await navigator.clipboard.writeText(u); toast('🔗 Link copy ho gaya'); } catch (e) {} return; }
    if (q === 'dl' && cur) cur.wv.downloadURL(img);
    p.classList.remove('show');
  });
  p.onmousedown = (e) => { if (e.target === p) p.classList.remove('show'); };
  p.classList.add('show');
}
function translatePage() {
  if (!cur || !/^https?:/i.test(cur.url)) { toast('Is page ko translate nahi kar sakte'); return; }
  if (/translate\.goog|translate\.google\./i.test(cur.url)) { toast('Page pehle se translate ho raha hai'); return; }
  navigate('https://translate.google.com/translate?sl=auto&tl=hi&u=' + encodeURIComponent(cur.url));
  toast('🌐 Hindi me translate ho raha hai');
}
async function deskShortcut() {
  if (!cur || isHome(cur.url)) { toast('Kisi website par jaakar shortcut banayein'); return; }
  const f = await window.bt.deskShortcut(cur.url, cur.title);
  toast(f ? '🖥 Desktop par shortcut ban gaya' : 'Shortcut nahi ban paya');
}
async function openFileDlg() { const u = await window.bt.openFile(); if (u) newTab(u); }
function viewSource() { if (cur && !isHome(cur.url) && !/^view-source:/i.test(cur.url)) newTab('view-source:' + cur.url, { index: tabs.indexOf(cur) + 1 }); }
function hardReload() { if (!cur) return; try { cur.wv.reloadIgnoringCache(); } catch (e) { cur.wv.reload(); } toast('↻ Cache ke bina reload'); }


/* ---------------- Smooth & bina hang: Memory Saver, Crash/Hang ---------------- */
if (S.memSaver === undefined) { S.memSaver = true; saveSet(); }
if (!S.sleepMin) S.sleepMin = 15;
setInterval(() => {
  if (!S.memSaver) return;
  const lim = (S.sleepMin || 15) * 60000, now = Date.now();
  tabs.forEach((t) => { if (t !== cur && !t.pinned && now - (t.lastActive || now) > lim) discardTab(t); });
}, 60000);

window.bt.on('tab-hang', (wcId) => { const t = tabs.find((x) => x.wcId === wcId); if (!t) return; t.hung = true; if (t === cur) paintTabState(); });
window.bt.on('tab-ok', (wcId) => { const t = tabs.find((x) => x.wcId === wcId); if (!t) return; t.hung = false; if (t === cur) paintTabState(); });

function paintTabState() {
  let ov = $('crashov'), bar = $('hangbar');
  if (!ov) {
    ov = document.createElement('div'); ov.id = 'crashov';
    ov.innerHTML = '<div class="cr-box"><div class="cr-ic">😵</div><b>Oh! Ye page band ho gaya</b><small id="crwhy">Page me kuch gadbad hui. Baaki tabs aur Baatora theek chal rahe hain.</small><button class="btn pri" id="crrl">↻ Dobara load karein</button></div>';
    $('content').appendChild(ov);
    $('crrl').onclick = () => { const t = cur; if (!t) return; t.crashed = null; paintTabState(); try { t.wv.reload(); } catch (e) { const old = t.wv; makeWv(t); old.remove(); $('views').appendChild(t.wv); select(t); } };
    bar = document.createElement('div'); bar.id = 'hangbar';
    bar.innerHTML = '<span>⏳ Ye page jawab nahi de raha (atak gaya hai).</span><button class="btn" id="hgwait">Wait karein</button><button class="btn red" id="hgkill">Page band karke dobara kholein</button>';
    $('content').appendChild(bar);
    $('hgwait').onclick = () => { if (cur) cur.hung = false; paintTabState(); };
    $('hgkill').onclick = () => { const t = cur; if (!t || !t.wcId) return; t.hung = false; paintTabState(); window.bt.killTab(t.wcId); toast('↻ Page dobara khul raha hai'); };
  }
  const t = cur;
  ov.classList.toggle('show', !!(t && t.crashed));
  if (t && t.crashed) $('crwhy').textContent = t.crashed === 'oom' ? 'Is page ko bahut zyada RAM chahiye thi. Kuch tabs band karke dobara try karein.' : 'Page me kuch gadbad hui. Baaki tabs aur Baatora theek chal rahe hain.';
  bar.classList.toggle('show', !!(t && t.hung && !t.crashed));
}
