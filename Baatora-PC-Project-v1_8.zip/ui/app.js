/* Baatora PC — browser UI (tabs, address bar, panels) */
'use strict';
const Q = new URLSearchParams(location.search);
const INCOG = Q.get('incog') === '1';
const HOME = Q.get('home');
const PART = INCOG ? 'baatora-incognito' : 'persist:baatora';
const $ = (id) => document.getElementById(id);
const MOBILE_UA = 'Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Mobile Safari/537.36';
const ENG = { google: 'https://www.google.com/search?q=', bing: 'https://www.bing.com/search?q=', duckduckgo: 'https://duckduckgo.com/?q=', yahoo: 'https://search.yahoo.com/search?p=' };
const ENGN = { google: 'Google', bing: 'Bing', duckduckgo: 'DuckDuckGo', yahoo: 'Yahoo' };

document.addEventListener('error', (e) => { const im = e.target; if (!im || im.tagName !== 'IMG') return; const m = /url=https:\/\/([^&]+)/.exec(im.src); if (m && !im.dataset.f) { im.dataset.f = '1'; im.src = 'https://www.google.com/s2/favicons?domain=' + m[1] + '&sz=32'; } else if (im.dataset.f !== '2') { im.dataset.f = '2'; im.src = 'logo.png'; } }, true);
if (INCOG) { document.body.classList.add('incog'); document.title = 'Baatora Incognito'; }

/* ---------------- Storage ---------------- */
function load(k, d) { try { const v = JSON.parse(localStorage.getItem(k)); return v == null ? d : v; } catch (e) { return d; } }
function save(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) {} }
const S = Object.assign({ engine: 'google', adblock: true, theme: 'light', bmbar: false, restore: true, night: false }, load('bt_set', {}));
if (!S.v15) { S.v15 = 1; S.bmbar = false; try { localStorage.setItem('bt_set', JSON.stringify(S)); } catch (e) {} }
function saveSet() { save('bt_set', S); }
let HIST = load('bt_hist', []);
let BM = load('bt_bm', []);
let DL = INCOG ? [] : load('bt_dl', []);
let histT = 0;
function saveHist() { if (INCOG) return; clearTimeout(histT); histT = setTimeout(() => save('bt_hist', HIST.slice(0, 3000)), 800); }
window.addEventListener('beforeunload', () => { if (!INCOG) { clearTimeout(histT); save('bt_hist', HIST.slice(0, 3000)); } });
function saveBm() { save('bt_bm', BM); }
function saveDl() { if (!INCOG) save('bt_dl', DL.slice(0, 200)); }
window.addEventListener('storage', (e) => {
  if (e.key === 'bt_bm') { BM = load('bt_bm', []); renderBm(); updStar(); }
  if (e.key === 'bt_hist') HIST = load('bt_hist', []);
  if (e.key === 'bt_set') { Object.assign(S, load('bt_set', {})); renderBm(); updShield(); applyTheme(); }
});


/* ---------------- Browser ka rang (Themes) ---------------- */
const FLAG_SVG = '<svg viewBox="0 0 30 20"><rect width="30" height="20" fill="#fff"/><rect width="30" height="6.67" fill="#FF9933"/><rect y="13.33" width="30" height="6.67" fill="#138808"/><circle cx="15" cy="10" r="2.7" fill="none" stroke="#000080" stroke-width=".7"/><circle cx="15" cy="10" r=".7" fill="#000080"/></svg>';
const LIGHT_BASE = { omni: '#F1F3F4', field: '#FFFFFF', pan: '#FFFFFF', line: 'rgba(0,0,0,.12)', hov: 'rgba(0,0,0,.07)', hov2: 'rgba(0,0,0,.12)', chip: 'rgba(0,0,0,.05)', shadow: 'rgba(15,23,42,.18)', dim: 'rgba(15,23,42,.35)', sec: '#0F9D58', brandg: 'linear-gradient(90deg,#FF6D00,#FF9100 45%,#1E5BFF)' };
const DARK_BASE = { line: 'rgba(255,255,255,.14)', hov: 'rgba(255,255,255,.09)', hov2: 'rgba(255,255,255,.16)', chip: 'rgba(255,255,255,.08)', shadow: 'rgba(0,0,0,.5)', dim: 'rgba(0,0,0,.55)', sec: '#69F0AE', txt: '#FFFFFF', brandg: 'linear-gradient(90deg,#FF8A00,#FFC107 45%,#00E5FF)' };
function LT(o) { return Object.assign({ dark: false }, LIGHT_BASE, o); }
function DK(o) { return Object.assign({ dark: true }, DARK_BASE, o); }
const THEMES = {
  light: LT({ n: 'Safed (Light)', bar: '#DFE3E8', tool: '#FFFFFF', tabon: '#FFFFFF', pan2: '#F6F8FB', txt: '#1F2937', mu: '#5F6B7A', ic: '#3C4552', tabtxt: '#3C4552', acc: '#1E5BFF', hb: ['#F8FAFF', '#EEF3FF', '#E4ECFF'] }),
  grey: LT({ n: 'Grey', bar: '#C8CDD4', tool: '#ECEFF3', tabon: '#ECEFF3', omni: '#FFFFFF', pan2: '#F1F3F6', txt: '#202124', mu: '#5F6368', ic: '#3C4043', tabtxt: '#3C4043', acc: '#1A73E8', hb: ['#F4F5F7', '#ECEEF1', '#E2E5E9'] }),
  sky: LT({ n: 'Aasmani (Sky)', bar: '#B9E0FF', tool: '#EAF6FF', tabon: '#EAF6FF', omni: '#FFFFFF', pan2: '#F2F9FF', txt: '#0B2545', mu: '#4A6585', ic: '#1D4E89', tabtxt: '#1D4E89', acc: '#0288D1', hb: ['#F3FAFF', '#E3F3FF', '#D3ECFF'] }),
  saffron: LT({ n: 'Kesariya', bar: '#FFD3A6', tool: '#FFF4E8', tabon: '#FFF4E8', omni: '#FFFFFF', pan2: '#FFF9F2', txt: '#3A2200', mu: '#7A5A3A', ic: '#8A4B00', tabtxt: '#8A4B00', acc: '#E65100', hb: ['#FFFAF3', '#FFF0E0', '#FFE6CC'] }),
  mint: LT({ n: 'Hara (Mint)', bar: '#BDE8D3', tool: '#EEFBF5', tabon: '#EEFBF5', omni: '#FFFFFF', pan2: '#F3FCF8', txt: '#0B3D2E', mu: '#4B6F62', ic: '#0F5C45', tabtxt: '#0F5C45', acc: '#00897B', hb: ['#F4FCF8', '#E6F7EF', '#D7F2E5'] }),
  pink: LT({ n: 'Gulabi', bar: '#F7C6DA', tool: '#FFF0F6', tabon: '#FFF0F6', omni: '#FFFFFF', pan2: '#FFF6FA', txt: '#4A1030', mu: '#80506A', ic: '#8E1D55', tabtxt: '#8E1D55', acc: '#C2185B', hb: ['#FFF7FB', '#FFEAF3', '#FFDDEB'] }),
  navy: DK({ n: 'Baatora Neela', bar: '#06103A', tool: '#0B1A5E', tabon: '#0B1A5E', omni: '#040A26', field: '#040A26', pan: '#0E1C66', pan2: '#0A1650', mu: '#B3C0EE', ic: '#E6EBFF', tabtxt: '#CFD8FF', acc: '#00E5FF', hb: ['#0B1A5E', '#06103A', '#040A26'] }),
  black: DK({ n: 'Kaala (Dark)', bar: '#0F0F10', tool: '#202124', tabon: '#202124', omni: '#303134', field: '#303134', pan: '#292A2D', pan2: '#1F2023', txt: '#E8EAED', mu: '#9AA0A6', ic: '#E8EAED', tabtxt: '#BDC1C6', acc: '#8AB4F8', hb: ['#202124', '#18191B', '#111113'] }),
  purple: DK({ n: 'Jamuni', bar: '#24104F', tool: '#341A72', tabon: '#341A72', omni: '#1A0B3A', field: '#1A0B3A', pan: '#3A1F7E', pan2: '#2A1460', mu: '#CDBDF2', ic: '#F0E9FF', tabtxt: '#D9CCFF', acc: '#B388FF', hb: ['#341A72', '#24104F', '#170A35'] }),
  incog: DK({ n: 'Incognito', bar: '#1A0B3A', tool: '#2A1260', tabon: '#2A1260', omni: '#12062A', field: '#12062A', pan: '#2E1666', pan2: '#22104F', mu: '#C9B8F0', ic: '#EDE4FF', tabtxt: '#D9CCFF', acc: '#B388FF', hb: ['#2A1260', '#1A0B3A', '#12062A'] })
};
function curTheme() { return INCOG ? THEMES.incog : (THEMES[S.theme] || THEMES.light); }
function homeTheme() {
  const t = curTheme();
  return { b1: t.hb[0], b2: t.hb[1], b3: t.hb[2], txt: t.txt, mu: t.mu, acc: t.acc, brandg: t.brandg,
    card: t.dark ? 'rgba(255,255,255,.07)' : 'rgba(255,255,255,.8)', cardb: t.line, tile: t.dark ? 'rgba(255,255,255,.10)' : '#FFFFFF',
    field: t.dark ? t.field : '#FFFFFF', hov: t.hov, shadow: t.dark ? 'rgba(0,0,0,.45)' : 'rgba(15,23,42,.12)', o: t.dark ? '.45' : '.22' };
}
function applyTheme() {
  const t = curTheme(), r = document.documentElement.style;
  ['bar', 'tool', 'tabon', 'omni', 'field', 'pan', 'pan2', 'txt', 'mu', 'ic', 'tabtxt', 'line', 'hov', 'hov2', 'chip', 'shadow', 'dim', 'sec', 'acc', 'brandg'].forEach((k) => { if (t[k]) r.setProperty('--' + k, t[k]); });
  window.bt.titleColor(t.bar, t.dark ? '#FFFFFF' : '#1F2937');
  document.body.classList.toggle('dark', !!t.dark);
  if (typeof tabs !== 'undefined') tabs.forEach((x) => { if (isHome(x.url) && x.ready) x.wv.executeJavaScript('window.applyUi&&applyUi(' + JSON.stringify(homeCfg()) + ')').catch(() => {}); });
}
function homeCfg() { return { engine: S.engine, incog: INCOG, home: homeTheme() }; }

/* ---------------- Helpers ---------------- */
function isHome(u) { return !!u && /^file:/i.test(u) && /\/pages\/home(-pc)?\.html$/i.test(u.split('#')[0].split('?')[0]); }
function homeUrl() { return HOME + (INCOG ? '#incog' : ''); }
function host(u) { try { return new URL(u).hostname; } catch (e) { return ''; } }
function fav(u) { const h = host(u); return h ? 'https://t1.gstatic.com/faviconV2?client=SOCIAL&type=FAVICON&fallback_opts=TYPE,SIZE,URL&url=https://' + encodeURIComponent(h) + '&size=64' : 'logo.png'; }
function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c])); }
function search(q) { return (ENG[S.engine] || ENG.google) + encodeURIComponent(q); }
function toUrl(q) {
  q = q.trim();
  if (!q) return null;
  if (/^(baatora:\/\/)?home$/i.test(q)) return homeUrl();
  if (/^[a-z][a-z0-9+.-]*:\/\//i.test(q) || /^(about|data|mailto|view-source):/i.test(q)) return q;
  if (/^(localhost|\d{1,3}(\.\d{1,3}){3})(:\d+)?(\/.*)?$/i.test(q)) return 'http://' + q;
  if (!/\s/.test(q) && /^[^\s/]+\.[a-z]{2,}(:\d+)?(\/.*)?$/i.test(q)) return 'https://' + q;
  return search(q);
}
function fmtSize(b) { if (!b || b < 0) return ''; const u = ['B', 'KB', 'MB', 'GB']; let i = 0; while (b >= 1024 && i < 3) { b /= 1024; i++; } return b.toFixed(i ? 1 : 0) + ' ' + u[i]; }
function fmtTime(ts) { const d = new Date(ts); return d.toLocaleTimeString('hi-IN', { hour: '2-digit', minute: '2-digit' }); }
function dayLabel(ts) {
  const d = new Date(ts), n = new Date(); const a = new Date(d.getFullYear(), d.getMonth(), d.getDate()), b = new Date(n.getFullYear(), n.getMonth(), n.getDate());
  const diff = Math.round((b - a) / 864e5);
  if (diff === 0) return 'AAJ'; if (diff === 1) return 'KAL';
  return d.toLocaleDateString('hi-IN', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' }).toUpperCase();
}
let toastT = 0;
function toast(m) { const t = $('toast'); t.textContent = m; t.classList.add('show'); clearTimeout(toastT); toastT = setTimeout(() => t.classList.remove('show'), 2600); }

/* ---------------- Tabs ---------------- */
let tabs = [], cur = null, seq = 0;
const closed = [];
const ASSETS = {};
async function asset(n) { if (!(n in ASSETS)) ASSETS[n] = await window.bt.asset(n); return ASSETS[n]; }

function newTab(url, opt) {
  opt = opt || {};
  const t = { id: ++seq, url: url || homeUrl(), title: opt.title || 'Naya tab', icon: null, loading: false, ready: false, wcId: null, zoom: 1, mobile: false, audio: false, muted: false, nightKey: null, lastActive: Date.now(), sleeping: false };
  makeWv(t);
  const el = document.createElement('div');
  el.className = 'tab';
  el.innerHTML = '<img src="logo.png" alt=""><span>' + esc(t.title) + '</span><i class="snd"></i><button class="x" title="Band karein (Ctrl+W)">✕</button>';
  el.title = 'Naya tab';
  t.el = el;
  el.addEventListener('mousedown', (e) => { if (e.button === 0 && !e.target.classList.contains('x')) select(t); });
  el.addEventListener('auxclick', (e) => { if (e.button === 1) closeTab(t); });
  el.addEventListener('contextmenu', (e) => tabMenu(t, e));
  el.querySelector('.x').addEventListener('click', (e) => { e.stopPropagation(); closeTab(t); });
  el.querySelector('.snd').addEventListener('click', (e) => { e.stopPropagation(); t.muted = !t.muted; try { t.wv.setAudioMuted(t.muted); } catch (x) {} paintTab(t); });
  const idx = Math.max(tabs.filter((x) => x.pinned).length, opt.index != null ? opt.index : (opt.bg && cur ? tabs.indexOf(cur) + 1 : tabs.length));
  tabs.splice(idx, 0, t);
  const before = tabs[idx + 1];
  $('tabs').insertBefore(el, before ? before.el : null);
  // Lazy: peeche khule (restore kiye) tabs tabhi load honge jab aap unpar click karein — startup tez
  if (opt.lazy && cur) { t.sleeping = true; el.classList.add('sleep'); paintTab(t); }
  else $('views').appendChild(t.wv);
  if (!opt.bg || !cur) select(t);
  layoutTabs();
  saveSession();
  return t;
}

function makeWv(t) {
  const wv = document.createElement('webview');
  wv.setAttribute('partition', PART);
  wv.setAttribute('allowpopups', '');
  wv.setAttribute('webpreferences', 'contextIsolation=yes,sandbox=yes');
  wv.src = t.url;
  t.wv = wv;
  hookWv(t);
  return wv;
}
/* Soya hua (sleeping) tab jagayein */
function wake(t) {
  if (!t || !t.sleeping) return;
  t.sleeping = false; t.ready = false; t.wcId = null; t.nightKey = null;
  t.el.classList.remove('sleep');
  $('views').appendChild(t.wv);
}
/* Memory Saver: der se band pade tab ko sula dein (RAM/CPU khali) — Chrome jaisa */
function discardTab(t) {
  if (!t || t.sleeping || t === cur || t.audio || t.loading || isHome(t.url) || !/^(https?|file):/i.test(t.url)) return false;
  const old = t.wv;
  t.ready = false; t.wcId = null; t.nightKey = null; t.used = null;
  makeWv(t);
  t.sleeping = true; t.el.classList.add('sleep');
  try { old.remove(); } catch (e) {}
  paintTab(t);
  return true;
}
function hookWv(t) {
  const wv = t.wv;
  const _add = wv.addEventListener.bind(wv);
  // purane (sulaye gaye) webview ke events naye tab ko na chhedein
  wv.addEventListener = (ev, fn, o) => _add(ev, (e) => { if (t.wv === wv) fn(e); }, o);
  wv.addEventListener('dom-ready', async () => {
    if (!t.ready) { t.ready = true; try { t.wcId = wv.getWebContentsId(); } catch (e) {} if (t.mobile) wv.setUserAgent(MOBILE_UA); if (t.muted) try { wv.setAudioMuted(true); } catch (e) {} if (t.zoomSet && t.zoom !== 1) try { wv.setZoomFactor(t.zoom); } catch (e) {} }
    if (!t.zoomSet) { t.zoomSet = true; if (S.zoomDef && S.zoomDef !== 100 && !isHome(wv.getURL())) { t.zoom = S.zoomDef / 100; try { wv.setZoomFactor(t.zoom); } catch (e) {} } }
    if (t.crashed || t.hung) { t.crashed = null; t.hung = false; if (t === cur && typeof paintTabState === 'function') paintTabState(); }
    const u = wv.getURL();
    if (isHome(u)) {
      wv.executeJavaScript('window.applyUi&&applyUi(' + JSON.stringify(homeCfg()) + ')').catch(() => {});
    } else if (/^https?:/i.test(u)) {
      const h = host(u);
      if (S.adblock) {
        wv.executeJavaScript(await asset('adblock.js')).catch(() => {});
      }
      if (S.night) applyNight(t, true);
    }
    if (t === cur) updNav();
  });
  wv.addEventListener('did-start-loading', () => { t.loading = true; paintTab(t); if (t === cur) { progress(25); updNav(); } });
  wv.addEventListener('did-stop-loading', () => { t.loading = false; paintTab(t); if (t === cur) { progress(100); updNav(); } saveSession(); });
  wv.addEventListener('did-fail-load', (e) => { if (e.isMainFrame && e.errorCode !== -3 && t === cur) toast('Page nahi khula: ' + (e.errorDescription || e.errorCode)); });
  wv.addEventListener('page-title-updated', (e) => {
    t.title = e.title || t.title; paintTab(t);
    if (t === cur) document.title = (INCOG ? '🕶 ' : '') + t.title + ' - Baatora';
    if (!INCOG && HIST[0] && HIST[0].u === t.url) { HIST[0].t = t.title; saveHist(); }
  });
  wv.addEventListener('page-favicon-updated', (e) => { if (e.favicons && e.favicons[0]) { t.icon = e.favicons[0]; paintTab(t); } });
  const nav = (e) => {
    if (e.isMainFrame === false) return;
    t.url = e.url;
    if (isHome(t.url)) { t.title = INCOG ? 'Incognito' : 'Naya tab'; t.icon = null; }
    else if (e.type === 'did-navigate') t.icon = null;
    paintTab(t);
    if (t === cur) { updAddr(); updNav(); }
    if (e.type === 'did-navigate') addHist(t);
    saveSession();
  };
  wv.addEventListener('did-navigate', nav);
  wv.addEventListener('did-navigate-in-page', nav);
  wv.addEventListener('found-in-page', (e) => { const r = e.result; if (r && r.matches != null) $('findc').textContent = (r.activeMatchOrdinal || 0) + '/' + r.matches; });
  wv.addEventListener('enter-html-full-screen', () => document.body.classList.add('fs'));
  wv.addEventListener('leave-html-full-screen', () => document.body.classList.remove('fs'));
  wv.addEventListener('media-started-playing', () => { t.audio = true; paintTab(t); });
  wv.addEventListener('media-paused', () => { t.audio = false; paintTab(t); });
  wv.addEventListener('focus', closePops);
  wv.addEventListener('close', () => closeTab(t));
  wv.addEventListener('render-process-gone', (e) => {
    const r = (e.details && e.details.reason) || e.reason || 'crashed';
    if (r === 'clean-exit') return;
    t.crashed = r; t.hung = false; t.loading = false; t.audio = false; paintTab(t);
    if (t === cur && typeof paintTabState === 'function') paintTabState();
  });
}

function paintTab(t) {
  const img = t.el.querySelector('img,.spin');
  if (t.loading && !img.classList.contains('spin')) { const s = document.createElement('i'); s.className = 'spin'; img.replaceWith(s); }
  else if (!t.loading) {
    let im = img;
    if (img.classList.contains('spin')) { im = document.createElement('img'); im.alt = ''; im.onerror = () => { im.src = 'logo.png'; }; img.replaceWith(im); }
    const src = t.icon || (isHome(t.url) ? 'logo.png' : (/^https?:/.test(t.url) ? fav(t.url) : 'logo.png'));
    if (im.getAttribute('src') !== src) { im.onerror = () => { im.onerror = null; im.src = 'logo.png'; }; im.src = src; }
  }
  t.el.querySelector('span').textContent = t.title;
  t.el.title = t.title + (isHome(t.url) ? '' : '\n' + t.url);
  t.el.querySelector('.snd').textContent = t.muted ? '🔇' : (t.audio ? '🔊' : '');
}

function select(t) {
  if (!t) return;
  if (cur && cur !== t) cur.lastActive = Date.now();
  wake(t);
  t.lastActive = Date.now();
  if (cur && cur !== t) { cur.el.classList.remove('on'); cur.wv.classList.remove('on'); if (findOpen) closeFind(); }
  cur = t;
  t.el.classList.add('on'); t.wv.classList.add('on');
  document.title = (INCOG ? '🕶 ' : '') + t.title + ' - Baatora';
  updAddr(); updNav(); progress(t.loading ? 40 : 100);
  $('zval').textContent = Math.round(t.zoom * 100) + '%';
  if (isHome(t.url)) setTimeout(() => $('addr').focus(), 30); else t.wv.focus();
  if (typeof onTabSelect === 'function') onTabSelect();
}

function closeTab(t) {
  const i = tabs.indexOf(t);
  if (i < 0) return;
  if (!isHome(t.url)) closed.push(t.url);
  tabs.splice(i, 1);
  t.el.remove(); t.wv.remove();
  if (!tabs.length) { saveSession(); window.bt.closeWindow(); return; }
  if (cur === t) { cur = null; select(tabs[Math.min(i, tabs.length - 1)]); }
  layoutTabs(); saveSession();
}

function layoutTabs() {
  const pins = tabs.filter((t) => t.pinned).length;
  const avail = document.body.clientWidth - 140 - 8 - 28 - 40 - 50 - pins * 42;
  const w = Math.max(46, Math.min(220, Math.floor(avail / Math.max(1, tabs.length - pins))));
  tabs.forEach((t) => {
    const pw = t.pinned ? 40 : w;
    t.el.style.flexBasis = pw + 'px'; t.el.style.width = pw + 'px';
    t.el.classList.toggle('pinned', !!t.pinned);
    t.el.classList.toggle('narrow', !!t.pinned || w < 92);
  });
}
let layRaf = 0;
window.addEventListener('resize', () => { if (!layRaf) layRaf = requestAnimationFrame(() => { layRaf = 0; layoutTabs(); }); });

let sesT = 0;
function saveSession() {
  if (INCOG) return;
  clearTimeout(sesT);
  sesT = setTimeout(() => save('bt_session', { tabs: tabs.map((t) => t.url), titles: tabs.map((t) => t.title), pins: tabs.map((t) => !!t.pinned), cur: tabs.indexOf(cur) }), 400);
}

/* ---------------- Navigation ---------------- */
function navigate(u) { if (!u || !cur) return; if (/^baatora:/i.test(u)) { baatora(u); return; } cur.wv.loadURL(u).catch(() => {}); cur.url = u; updAddr(); }
function goHome() { navigate(homeUrl()); }
function updAddr() {
  if (!cur) return;
  const a = $('addr'), sec = $('secure');
  if (document.activeElement !== a) a.value = isHome(cur.url) ? '' : cur.url;
  sec.className = isHome(cur.url) ? 'home' : (/^https:/.test(cur.url) ? '' : 'warn');
  sec.title = isHome(cur.url) ? 'Baatora Home' : (/^https:/.test(cur.url) ? 'Connection surakshit hai (HTTPS)' : 'Connection surakshit nahi hai');
  updStar();
  if (typeof paintPermIc === 'function') paintPermIc();
}
function updNav() {
  if (!cur) return;
  let b = false, f = false;
  try { if (cur.ready) { b = cur.wv.canGoBack(); f = cur.wv.canGoForward(); } } catch (e) {}
  $('back').disabled = !b; $('fwd').disabled = !f;
  $('reloadIc').innerHTML = cur.loading ? '<path d="M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z"/>' : '<path d="M17.65 6.35A7.96 7.96 0 0 0 12 4a8 8 0 1 0 7.73 10h-2.08A6 6 0 1 1 12 6c1.66 0 3.14.69 4.22 1.78L13 11h7V4l-2.35 2.35z"/>';
  $('reload').title = cur.loading ? 'Rokein (Esc)' : 'Reload (F5)';
}
let progT = 0;
function progress(p) {
  const i = $('progress').firstElementChild;
  clearTimeout(progT);
  if (p >= 100) { i.style.width = '100%'; progT = setTimeout(() => { i.style.opacity = 0; setTimeout(() => { i.style.width = 0; }, 400); }, 200); }
  else { i.style.opacity = 1; i.style.width = p + '%'; progT = setTimeout(() => { if (cur && cur.loading) progress(Math.min(90, p + 12)); }, 500); }
}
function addHist(t) {
  if (INCOG || !/^https?:/i.test(t.url)) return;
  if (HIST[0] && HIST[0].u === t.url) { HIST[0].ts = Date.now(); }
  else HIST.unshift({ u: t.url, t: t.title && t.title !== 'Naya tab' ? t.title : host(t.url), ts: Date.now() });
  saveHist();
}

$('back').onclick = () => { try { cur.wv.goBack(); } catch (e) {} };
$('fwd').onclick = () => { try { cur.wv.goForward(); } catch (e) {} };
$('reload').onclick = () => { if (!cur) return; if (cur.loading) cur.wv.stop(); else cur.wv.reload(); };
$('home').onclick = goHome;
$('newtab').onclick = () => newTab();
$('tabbar').addEventListener('dblclick', (e) => { if (e.target.id === 'tabs') newTab(); });

/* ---------------- Tala (🔒) — site ki jaankari ---------------- */
function siteInfo() {
  const p = $('sitepop');
  if (p.classList.contains('show')) { p.classList.remove('show'); return; }
  closePops();
  const u = cur ? cur.url : '';
  const home = isHome(u), https = /^https:/i.test(u);
  let h = '';
  try { h = new URL(u).hostname; } catch (e) {}
  const n = $('blk').style.display === 'block' ? $('blk').textContent : '0';
  p.innerHTML = home
    ? '<div class="sp-h"><img src="logo.png" alt=""><div><b>Baatora Home</b><small>Ye Baatora ka apna page hai — poori tarah surakshit</small></div></div>'
    : '<div class="sp-h"><img src="' + esc(fav(u)) + '" alt=""><div><b>' + esc(h || u) + '</b><small>' + esc(cur ? cur.title : '') + '</small></div></div>' +
      '<div class="sp-row ' + (https ? 'ok' : 'bad') + '"><svg viewBox="0 0 24 24"><use href="#i-' + (https ? 'shield' : 'info') + '"/></svg><div><b>' + (https ? 'Connection surakshit hai' : 'Connection surakshit nahi hai') + '</b><small>' + (https ? 'Aapki jaankari (password, card) is site tak surakshit (encrypted) jaati hai.' : 'Is site par password ya card ki jaankari na daalein.') + '</small></div></div>' +
      '<div class="sp-row"><svg viewBox="0 0 24 24"><use href="#i-shield"/></svg><div><b>Ad Blocker: ' + (S.adblock ? 'Chalu' : 'Band') + '</b><small>Is window me ab tak ' + esc(n) + ' ads/trackers roke gaye</small></div></div>' +
      '<div class="sp-btns"><button data-x="copy">🔗 Link copy</button>' + (INCOG ? '' : '<button data-x="clear">🧹 Is site ka data saaf</button>') + '<button data-x="reload">↻ Reload</button></div>' +
      (typeof permSectionHtml === 'function' ? permSectionHtml(originOf(u)) : '');
  if (!home && typeof bindPermSection === 'function') bindPermSection(p, originOf(u));
  p.querySelectorAll('.sp-btns:not(.sp-perm .sp-btns) [data-x]').forEach((b) => b.onclick = async () => {
    const x = b.dataset.x;
    if (x === 'copy') { try { await navigator.clipboard.writeText(u); toast('🔗 Link copy ho gaya'); } catch (e) { toast('Copy nahi ho paya'); } }
    if (x === 'clear') { if (confirm(h + ' ka saara data (cookies, login) saaf karein?')) { await window.bt.clearSite(new URL(u).origin, INCOG); toast('🧹 ' + h + ' ka data saaf'); cur.wv.reload(); } }
    if (x === 'reload') cur.wv.reload();
    p.classList.remove('show');
  });
  p.classList.add('show');
}
$('secure').addEventListener('mousedown', (e) => { e.preventDefault(); e.stopPropagation(); siteInfo(); });

/* ---------------- Address bar + suggestions ---------------- */
const addr = $('addr'), sugg = $('sugg');
let sItems = [], sIdx = -1;
addr.addEventListener('focus', () => setTimeout(() => addr.select(), 0));
addr.addEventListener('input', showSugg);
addr.addEventListener('blur', () => setTimeout(() => { sugg.style.display = 'none'; updAddr(); }, 150));
addr.addEventListener('keydown', (e) => {
  if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
    if (!sItems.length) return; e.preventDefault();
    sIdx = (sIdx + (e.key === 'ArrowDown' ? 1 : -1) + sItems.length) % sItems.length;
    [...sugg.children].forEach((d, i) => d.classList.toggle('on', i === sIdx));
    if (sItems[sIdx].u) addr.value = sItems[sIdx].u; else addr.value = sItems[sIdx].q;
  } else if (e.key === 'Enter') {
    e.preventDefault();
    const it = sIdx >= 0 ? sItems[sIdx] : null;
    const raw = addr.value.trim();
    const u = it && !e.ctrlKey ? (it.u || search(it.q)) : (e.ctrlKey && /^[a-z0-9-]+$/i.test(raw) ? 'https://www.' + raw + '.com' : toUrl(addr.value));
    sugg.style.display = 'none';
    if (u) { if (e.altKey) newTab(u); else navigate(u); cur.wv.focus(); }
  } else if (e.key === 'Escape') { sugg.style.display = 'none'; addr.value = isHome(cur.url) ? '' : cur.url; addr.select(); }
});
function showSugg() {
  const q = addr.value.trim().toLowerCase();
  sIdx = -1; sItems = [];
  if (!q) { sugg.style.display = 'none'; return; }
  const seen = new Set();
  const direct = toUrl(addr.value);
  if (direct && direct.indexOf(ENG[S.engine]) !== 0) { sItems.push({ u: direct, t: 'Website kholein' }); seen.add(direct); }
  sItems.push({ q: addr.value.trim(), t: ENGN[S.engine] + ' par khojein' });
  const pool = BM.map((b) => Object.assign({ bm: 1 }, b)).concat(HIST);
  for (const h of pool) {
    if (sItems.length >= 8) break;
    if (seen.has(h.u)) continue;
    if ((h.u || '').toLowerCase().includes(q) || (h.t || '').toLowerCase().includes(q)) { seen.add(h.u); sItems.push(h); }
  }
  sugg.innerHTML = sItems.map((s) => s.q != null
    ? '<div><span>🔎</span><b>' + esc(s.q) + '</b><small>— ' + esc(s.t) + '</small></div>'
    : '<div><img src="' + esc(fav(s.u)) + '" width="16" height="16"><b>' + esc(s.t || s.u) + '</b><small>' + (s.bm ? '⭐ ' : '') + esc(s.u) + '</small></div>').join('');
  [...sugg.children].forEach((d, i) => d.addEventListener('mousedown', (e) => { e.preventDefault(); const it = sItems[i]; sugg.style.display = 'none'; navigate(it.u || search(it.q)); cur.wv.focus(); }));
  sugg.style.display = 'block';
}

/* ---------------- Bookmarks ---------------- */
function isBm(u) { return BM.some((b) => b.u === u); }
function updStar() { const on = cur && isBm(cur.url); $('star').classList.toggle('on', !!on); $('star').title = on ? 'Bookmark hatayein' : 'Bookmark karein (Ctrl+D)'; }
function toggleBm() {
  if (!cur || isHome(cur.url)) { toast('Home page ko bookmark nahi kar sakte'); return; }
  if (isBm(cur.url)) { BM = BM.filter((b) => b.u !== cur.url); toast('Bookmark hata diya'); }
  else { BM.unshift({ u: cur.url, t: cur.title || host(cur.url), ts: Date.now() }); toast('⭐ Bookmark save ho gaya'); }
  saveBm(); updStar(); renderBm();
}
$('star').onclick = toggleBm;
function renderBm() {
  const bar = $('bmbar');
  bar.classList.toggle('hide', !S.bmbar || !BM.length);
  if (!BM.length) { bar.innerHTML = ''; return; }
  bar.innerHTML = '';
  BM.slice(0, 40).forEach((b) => {
    const a = document.createElement('a');
    a.title = b.t + '\n' + b.u;
    a.innerHTML = '<img src="' + esc(fav(b.u)) + '"><span>' + esc(b.t || host(b.u)) + '</span>';
    a.addEventListener('click', (e) => { if (e.ctrlKey) newTab(b.u, { bg: true }); else navigate(b.u); });
    a.addEventListener('auxclick', (e) => { if (e.button === 1) newTab(b.u, { bg: true }); });
    bar.appendChild(a);
  });
}

/* ---------------- Ad blocker ---------------- */
function updShield() { $('shield').classList.toggle('off', !S.adblock); $('shield').title = S.adblock ? 'Ad Blocker ON — click karke band karein' : 'Ad Blocker OFF'; }
$('shield').onclick = () => { S.adblock = !S.adblock; saveSet(); window.bt.adblock(S.adblock); updShield(); toast(S.adblock ? '🛡 Ad Blocker chalu' : 'Ad Blocker band'); };
window.bt.on('blocked', (n) => { const b = $('blk'); b.style.display = 'block'; b.textContent = n > 999 ? Math.floor(n / 1000) + 'k' : n; });

/* ---------------- Downloads ---------------- */
window.bt.on('dl', (d) => {
  const i = DL.findIndex((x) => x.id === d.id);
  if (i < 0) { DL.unshift(d); toast('⬇ Download shuru: ' + d.name); showDlPop(); }
  else { d.ts = DL[i].ts; DL[i] = d; }
  if (d.state === 'completed') toast('✅ Download pura: ' + d.name);
  else if (d.state === 'interrupted') toast('Download ruk gaya: ' + d.name);
  if (d.state !== 'progressing') saveDl();
  updDlRing(); if ($('dlpop').classList.contains('show')) renderDlPop(); if (panelKind === 'downloads') renderPanel();
});
function updDlRing() {
  const act = DL.filter((d) => d.state === 'progressing');
  const r = $('dlring');
  if (!act.length) { r.style.display = 'none'; return; }
  const tot = act.reduce((s, d) => s + (d.total || 0), 0), rec = act.reduce((s, d) => s + (d.received || 0), 0);
  r.style.display = 'block'; r.style.setProperty('--pc', (tot ? Math.round(rec / tot * 100) : 30) + '%');
}
function dlRow(d) {
  const pc = d.total ? Math.round(d.received / d.total * 100) : 0;
  let st = '', acts = '';
  if (d.state === 'progressing') { st = fmtSize(d.received) + (d.total ? ' / ' + fmtSize(d.total) + ' • ' + pc + '%' : '') + (d.paused ? ' • Ruka hua' : ''); acts = '<button class="act" data-x="' + (d.paused ? 'resume' : 'pause') + '">' + (d.paused ? '▶' : '⏸') + '</button><button class="del" data-x="cancel">✕</button>'; }
  else if (d.state === 'completed') { st = fmtSize(d.total || d.received) + ' • ' + host(d.url); acts = '<button class="act" data-x="open">Kholein</button><button class="act" data-x="show">Folder</button>'; }
  else st = d.state === 'cancelled' ? 'Cancel kiya' : 'Fail ho gaya';
  return '<div class="row" data-id="' + esc(d.id) + '"><img src="' + esc(fav(d.url)) + '"><div class="t"><b>' + esc(d.name) + '</b><small>' + esc(st) + '</small>' +
    (d.state === 'progressing' ? '<div class="bar2"><i style="width:' + pc + '%"></i></div>' : '') + '</div>' + acts + '</div>';
}
function bindDl(root) {
  root.querySelectorAll('.row[data-id]').forEach((r) => {
    const d = DL.find((x) => x.id === r.dataset.id); if (!d) return;
    r.querySelectorAll('[data-x]').forEach((b) => b.onclick = (e) => { e.stopPropagation(); window.bt.dl(d.id, b.dataset.x, d.path); });
    r.querySelector('.t').onclick = () => { if (d.state === 'completed') window.bt.dl(d.id, 'open', d.path); };
  });
}
function renderDlPop() {
  const p = $('dlpop');
  p.innerHTML = '<div class="h">Haal ke downloads<a id="dlall">Sab dekhein</a></div>' + (DL.length ? DL.slice(0, 5).map(dlRow).join('') : '<div class="none" style="padding:20px">Abhi koi download nahi</div>');
  bindDl(p);
  $('dlall').onclick = () => { closePops(); openPanel('downloads'); };
}
let dlPopT = 0;
function showDlPop() { closePops(); renderDlPop(); $('dlpop').classList.add('show'); clearTimeout(dlPopT); dlPopT = setTimeout(() => $('dlpop').classList.remove('show'), 4000); }
$('setbtn').onclick = () => openPanel('settings');
$('dlbtn').onclick = (e) => { e.stopPropagation(); const p = $('dlpop'); if (p.classList.contains('show')) { p.classList.remove('show'); return; } closePops(); renderDlPop(); p.classList.add('show'); clearTimeout(dlPopT); };

/* ---------------- Panels ---------------- */
let panelKind = null;
function openPanel(k, sec) {
  closePops();
  panelKind = k;
  if (sec) setSec = sec;
  const PT = { history: ['hist', '#448AFF,#1A3FD8', 'History'], bookmarks: ['bm', '#FFD740,#FF9100', 'Bookmarks'], downloads: ['dl', '#64FFDA,#00897B', 'Downloads'], settings: ['logo', '', 'Settings'], about: ['logo', '', 'Baatora ke baare me'] }[k];
  if (PT[0] === 'logo') $('ptitle').innerHTML = '<img class="ptitle-logo" src="logo.png" alt="">' + PT[2]; else
  $('ptitle').innerHTML = '<b class="mi ptitle-ic" style="--c:' + PT[1] + '"><svg><use href="#i-' + PT[0] + '"/></svg></b>' + PT[2];
  $('psearch').style.display = (k === 'history' || k === 'bookmarks' || k === 'downloads') ? '' : 'none';
  $('psearch').value = '';
  $('panel').classList.toggle('wide', k === 'settings');
  $('panel').classList.add('show');
  renderPanel();
  if ($('psearch').style.display === '') setTimeout(() => $('psearch').focus(), 30);
}
function closePanel() { $('panel').classList.remove('show'); panelKind = null; }
$('pclose').onclick = closePanel;
$('panel').addEventListener('mousedown', (e) => { if (e.target.id === 'panel') closePanel(); });
$('psearch').addEventListener('input', renderPanel);

function renderPanel() {
  const body = $('pbody'), q = $('psearch').value.trim().toLowerCase();
  const match = (x) => !q || (x.u || x.url || '').toLowerCase().includes(q) || (x.t || x.name || '').toLowerCase().includes(q);
  if (panelKind === 'history') {
    if (INCOG) { body.innerHTML = '<div class="none">🕶 Incognito me History save nahi hoti</div>'; return; }
    const list = HIST.filter(match).slice(0, 600);
    let h = '<div class="ptop"><button class="btn red" id="hclear">History saaf karein</button></div>', last = '';
    if (!list.length) h += '<div class="none">Koi history nahi mili</div>';
    list.forEach((x) => {
      const d = dayLabel(x.ts); if (d !== last) { h += '<div class="day">' + esc(d) + '</div>'; last = d; }
      h += '<div class="row" data-u="' + esc(x.u) + '" data-ts="' + x.ts + '"><span class="tm">' + fmtTime(x.ts) + '</span><img src="' + esc(fav(x.u)) + '"><div class="t"><b>' + esc(x.t || x.u) + '</b><small>' + esc(x.u) + '</small></div><button class="del">Hatayein</button></div>';
    });
    body.innerHTML = h;
    $('hclear').onclick = () => { if (confirm('Poori history delete karein?')) { HIST = []; saveHist(); renderPanel(); toast('History saaf ho gayi'); } };
    body.querySelectorAll('.row').forEach((r) => {
      r.querySelector('.t').onclick = (e) => { closePanel(); if (e.ctrlKey) newTab(r.dataset.u, { bg: true }); else navigate(r.dataset.u); };
      r.querySelector('.del').onclick = () => { const ts = +r.dataset.ts; HIST = HIST.filter((x) => !(x.ts === ts && x.u === r.dataset.u)); saveHist(); r.remove(); };
    });
  } else if (panelKind === 'bookmarks') {
    const list = BM.filter(match);
    let h = '<div class="ptop"><button class="btn" id="bmtog">' + (S.bmbar ? 'Bookmarks bar chhupayein' : 'Bookmarks bar dikhayein') + '</button></div>';
    if (!list.length) h += '<div class="none">Koi bookmark nahi. Kisi bhi page par ⭐ dabakar save karein.</div>';
    list.forEach((x) => { h += '<div class="row" data-u="' + esc(x.u) + '"><img src="' + esc(fav(x.u)) + '"><div class="t"><b>' + esc(x.t || x.u) + '</b><small>' + esc(x.u) + '</small></div><button class="act ren">Naam badlein</button><button class="del">Hatayein</button></div>'; });
    body.innerHTML = h;
    $('bmtog').onclick = () => { S.bmbar = !S.bmbar; saveSet(); renderBm(); renderPanel(); };
    body.querySelectorAll('.row').forEach((r) => {
      const u = r.dataset.u;
      r.querySelector('.t').onclick = (e) => { closePanel(); if (e.ctrlKey) newTab(u, { bg: true }); else navigate(u); };
      r.querySelector('.del').onclick = () => { BM = BM.filter((b) => b.u !== u); saveBm(); renderBm(); updStar(); r.remove(); };
      r.querySelector('.ren').onclick = () => {
        const b = BM.find((x) => x.u === u); if (!b) return;
        const tEl = r.querySelector('.t b');
        const inp = document.createElement('input'); inp.value = b.t || ''; inp.style.cssText = 'width:100%;background:#040A26;color:#fff;border:1px solid #00E5FF;border-radius:8px;padding:4px 8px;font:inherit';
        tEl.replaceWith(inp); inp.focus(); inp.select();
        const done = () => { b.t = inp.value.trim() || b.t; saveBm(); renderBm(); renderPanel(); };
        inp.onkeydown = (e) => { if (e.key === 'Enter') done(); if (e.key === 'Escape') renderPanel(); };
        inp.onblur = done; inp.onclick = (e) => e.stopPropagation();
      };
    });
  } else if (panelKind === 'downloads') {
    const list = DL.filter(match);
    body.innerHTML = '<div class="ptop"><button class="btn pri" id="dlf">📁 Downloads folder kholein</button><button class="btn" id="dlc">List saaf karein</button></div>' + (list.length ? list.map(dlRow).join('') : '<div class="none">Abhi tak koi download nahi</div>');
    bindDl(body);
    $('dlf').onclick = () => window.bt.dl('', 'folder');
    $('dlc').onclick = () => { DL = DL.filter((d) => d.state === 'progressing'); saveDl(); renderPanel(); };
  } else if (panelKind === 'settings') {
    renderSettings(body);
  } else if (panelKind === 'about') {
    body.innerHTML = '<div class="about">' +
      '<div class="hero2"><img src="logo.png" alt=""><div class="h2t"><div class="h2name">Baatora <span>Browser</span></div>' +
      '<div class="founder"><i>Founder</i><b>Anil Yadav</b></div><p id="aver" class="abver"></p></div></div>' +
      '<blockquote class="motto">“Internet sabka hai — tez, surakshit aur apni bhasha me.<br>Isi soch ka naam hai <b>Baatora</b>.”</blockquote>' +
      '<h3 class="fh">🚀 Baatora ka Bhavishya</h3>' +
      '<div class="road">' +
      '<div class="st now"><i>1</i><div><small>Aaj</small><b>Tez, saaf aur ad-free browser</b><span>Android aur PC dono par — bina faltu ads ke, aapki privacy ke saath.</span></div></div>' +
      '<div class="st"><i>2</i><div><small>Jald hi</small><b>Bolo aur khojo</b><span>Hindi aur Bharatiya bhashaon me voice search, aur phone-PC ke bookmarks ek saath sync.</span></div></div>' +
      '<div class="st"><i>3</i><div><small>Aage</small><b>Baatora Sahayak</b><span>Ek samajhdar madadgaar jo khojne, padhne aur kaam ko aasaan banaye.</span></div></div>' +
      '<div class="st dream"><i>★</i><div><small>Sapna</small><b>Bharat ka apna browser</b><span>Har ghar, har dukaan, har haath me — crore Bharatiyon ka bharosa.</span></div></div>' +
      '</div>' +
      '<div class="abfoot"><span class="flag">' + FLAG_SVG + 'Made in India</span><span>Dil se banaya, Bharat ke liye ❤️</span></div></div>';
    window.bt.info().then((i) => { $('aver').textContent = 'Version ' + i.version; });
  }
}

/* ---------------- Account: Sign in / Sign up (is computer par) ---------------- */
function curAcct() { const e = load('bt_signed', ''); return e ? (load('bt_accts', []).find((x) => x.email === e) || null) : null; }
function ini(n) { return (String(n || '?').trim().charAt(0) || '?').toUpperCase(); }
async function hashPw(pw, salt) {
  try {
    const enc = new TextEncoder();
    const key = await crypto.subtle.importKey('raw', enc.encode(pw), 'PBKDF2', false, ['deriveBits']);
    const bits = await crypto.subtle.deriveBits({ name: 'PBKDF2', salt: enc.encode(salt), iterations: 120000, hash: 'SHA-256' }, key, 256);
    return Array.from(new Uint8Array(bits)).map((b) => b.toString(16).padStart(2, '0')).join('');
  } catch (e) { return 'x' + btoa(unescape(encodeURIComponent(salt + pw))); }
}
function paintProfile() {
  const a = curAcct(), el = $('profav'), b = $('profbtn');
  if (INCOG) { el.className = 'av inc'; el.innerHTML = '<svg><use href="#i-incog"/></svg>'; b.title = 'Incognito'; return; }
  if (a) { el.className = 'av on'; el.textContent = ini(a.name); b.title = a.name + ' (' + a.email + ')'; }
  else { el.className = 'av'; el.innerHTML = '<svg><use href="#i-user"/></svg>'; b.title = 'Baatora me sign in karein'; }
}
function signOut() { save('bt_signed', ''); paintProfile(); closePops(); if (panelKind === 'settings') renderPanel(); toast('Sign out ho gaye'); }
const AUTH = { mode: 'in' };
function openAuth(mode) {
  if (INCOG) return;
  closePops(); AUTH.mode = mode || 'in'; paintAuth(); $('auth').classList.add('show');
  setTimeout(() => { const f = $('auth').querySelector('input'); if (f) f.focus(); }, 30);
}
function closeAuth() { $('auth').classList.remove('show'); }
function paintAuth() {
  const up = AUTH.mode === 'up', box = $('auth');
  box.innerHTML = '<div class="acard"><button class="aclose" id="axc" title="Band karein">✕</button><img src="logo.png" class="alogo" alt="">' +
    '<h2>' + (up ? 'Baatora account banayein' : 'Baatora me sign in karein') + '</h2>' +
    '<p class="asub">' + (up ? 'Apna naam, email aur password daalkar naya account banayein.' : 'Apne email aur password se sign in karein.') + '</p>' +
    '<div class="atabs"><button data-m="in" class="' + (up ? '' : 'on') + '">Sign in</button><button data-m="up" class="' + (up ? 'on' : '') + '">Sign up</button></div>' +
    '<div class="aform">' + (up ? '<input class="in" id="an" placeholder="Poora naam" autocomplete="name">' : '') +
    '<input class="in" id="ae" type="email" placeholder="Email" autocomplete="email">' +
    '<input class="in" id="ap" type="password" placeholder="Password" autocomplete="' + (up ? 'new-password' : 'current-password') + '">' +
    (up ? '<input class="in" id="ap2" type="password" placeholder="Password dobara likhein" autocomplete="new-password">' : '') +
    '<div class="aerr" id="aerr"></div><button class="btn pri abig" id="ago">' + (up ? 'Sign up' : 'Sign in') + '</button></div>' +
    '<small class="anote">Abhi aapka account sirf is computer par save hota hai (password surakshit roop se). Phone aur PC ke beech sync jald aayega.</small></div>';
  $('axc').onclick = closeAuth;
  box.querySelectorAll('.atabs button').forEach((b) => b.onclick = () => { AUTH.mode = b.dataset.m; paintAuth(); const f = box.querySelector('input'); if (f) f.focus(); });
  box.querySelectorAll('input').forEach((i) => i.onkeydown = (e) => { if (e.key === 'Enter') $('ago').click(); });
  $('ago').onclick = submitAuth;
}
async function submitAuth() {
  const up = AUTH.mode === 'up', err = (m) => { $('aerr').textContent = m; };
  const email = $('ae').value.trim().toLowerCase(), pw = $('ap').value, name = up ? $('an').value.trim() : '';
  if (up && !name) return err('Apna naam likhein');
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email)) return err('Sahi email likhein');
  if (pw.length < 6) return err('Password kam se kam 6 akshar ka rakhein');
  const list = load('bt_accts', []);
  $('ago').disabled = true;
  try {
    if (up) {
      if (pw !== $('ap2').value) return err('Dono password alag hain');
      if (list.some((x) => x.email === email)) return err('Is email se account pehle se hai — Sign in karein');
      const salt = Math.random().toString(36).slice(2) + Date.now().toString(36);
      list.push({ name, email, salt, hash: await hashPw(pw, salt), ts: Date.now() });
      save('bt_accts', list); save('bt_signed', email);
      toast('🎉 Account ban gaya! Namaste, ' + name);
    } else {
      const a = list.find((x) => x.email === email);
      if (!a) return err('Is email ka account nahi mila — pehle Sign up karein');
      if ((await hashPw(pw, a.salt)) !== a.hash) return err('Password galat hai');
      save('bt_signed', email);
      toast('✅ Namaste, ' + a.name);
    }
    closeAuth(); paintProfile(); if (panelKind === 'settings') renderPanel();
  } finally { const g = $('ago'); if (g) g.disabled = false; }
}
function renderProfPop() {
  const p = $('profpop'), a = curAcct();
  if (INCOG) { p.innerHTML = '<div class="pp-h"><span class="av big inc"><svg><use href="#i-incog"/></svg></span><div><b>Incognito</b><small>Is window me History aur cookies save nahi hoti.</small></div></div>'; return; }
  const item = (act, ic, t) => '<button class="pp-i" data-pa="' + act + '"><svg><use href="#i-' + ic + '"/></svg>' + t + '</button>';
  if (a) p.innerHTML = '<div class="pp-h"><span class="av big on">' + esc(ini(a.name)) + '</span><div><b>' + esc(a.name) + '</b><small>' + esc(a.email) + '</small></div></div>' +
    item('manage', 'user', 'Baatora account manage karein') + item('pw', 'key', 'Passwords') + item('incog', 'incog', 'Incognito window') + item('out', 'power', 'Sign out');
  else p.innerHTML = '<div class="pp-h"><span class="av big"><svg><use href="#i-user"/></svg></span><div><b>Baatora me sign in karein</b><small>Apna account banakar naam aur settings ek jagah rakhein.</small></div></div>' +
    '<div class="pp-b"><button class="btn pri" data-pa="up">Sign up</button><button class="btn" data-pa="in">Sign in</button></div>';
}
$('profbtn').onclick = (e) => { e.stopPropagation(); const p = $('profpop'); const on = p.classList.contains('show'); closePops(); if (!on) { renderProfPop(); p.classList.add('show'); } };
$('profpop').addEventListener('click', (e) => {
  const b = e.target.closest('[data-pa]'); if (!b) return;
  const a = b.dataset.pa; closePops();
  if (a === 'in' || a === 'up') openAuth(a);
  else if (a === 'manage') openPanel('settings', 'google');
  else if (a === 'pw') openPanel('settings', 'autofill');
  else if (a === 'incog') window.bt.newWindow({ incog: true });
  else if (a === 'out') signOut();
});
window.addEventListener('storage', (e) => { if (e.key === 'bt_signed' || e.key === 'bt_accts') paintProfile(); });
paintProfile();

/* ---------------- Settings (Chrome jaisa sidebar) ---------------- */
let setSec = 'google', FL = {};
window.bt.flags().then((f) => { FL = f || {}; });
const SEC = [
  ['google', 'You and Baatora', 'user'], ['autofill', 'Autofill and passwords', 'key'], ['privacy', 'Privacy and security', 'shield'],
  ['perf', 'Performance', 'speed'], ['look', 'Appearance', 'palette'], ['engine', 'Search engine', 'zoom'],
  ['default', 'Default browser', 'win'], ['startup', 'On startup', 'power'], ['-'],
  ['lang', 'Languages', 'lang'], ['dl', 'Downloads', 'dl'], ['access', 'Accessibility', 'access'],
  ['system', 'System', 'wrench'], ['reset', 'Reset settings', 'restore'], ['-'],
  ['ext', 'Extensions', 'ext'], ['about', 'About Baatora', 'info']
];
const ICO = (id, c) => '<b class="mi" style="--c:' + c + '"><svg><use href="#i-' + id + '"/></svg></b>';
const SET = (ic, c, t, s, right) => '<div class="set">' + ICO(ic, c) + '<div class="t"><b>' + t + '</b><small>' + s + '</small></div>' + (right || '') + '</div>';
const swS = (k, ic, c, t, s) => SET(ic, c, t, s, '<div class="sw ' + (S[k] ? 'on' : '') + '" data-k="' + k + '"></div>');
const swF = (f, def, ic, c, t, s, rl) => SET(ic, c, t, s, '<div class="sw ' + ((FL[f] === undefined ? def : !!FL[f]) ? 'on' : '') + '" data-f="' + f + '"' + (rl ? ' data-rl="1"' : '') + '></div>');
const swP = (p, ic, c, t, s) => SET(ic, c, t, s, '<div class="sw ' + ((FL.perm && FL.perm[p] === false) ? '' : 'on') + '" data-p="' + p + '"></div>');
const selOpts = (arr, cur) => arr.map((o) => '<option value="' + esc(o[0]) + '"' + (String(o[0]) === String(cur) ? ' selected' : '') + '>' + esc(o[1]) + '</option>').join('');
const LANGS = [['', 'Default (computer ki bhasha)'], ['en-IN,en;q=0.9,hi;q=0.8', 'English (India) + हिन्दी'], ['hi-IN,hi;q=0.9,en;q=0.8', 'हिन्दी (Hindi)'], ['en-US,en;q=0.9', 'English (US)'], ['en-GB,en;q=0.9', 'English (UK)']];

function renderSettings(body) {
  const nav = SEC.map((s) => s[0] === '-' ? '<hr>' : '<button data-sec="' + s[0] + '" class="' + (s[0] === setSec ? 'on' : '') + '"><svg><use href="#i-' + s[2] + '"/></svg>' + s[1] + '</button>').join('');
  body.innerHTML = '<nav class="snav">' + nav + '</nav><div class="spage" id="spage"></div>';
  body.querySelectorAll('.snav button').forEach((b) => b.onclick = () => { setSec = b.dataset.sec; renderSettings(body); });
  paintSec($('spage'), setSec);
}

function paintSec(el, sec) {
  const title = (SEC.find((x) => x[0] === sec) || [0, ''])[1];
  let h = '<h3 class="sh">' + title + '</h3>';
  const a = curAcct();
  switch (sec) {
    case 'google':
      h += '<div class="brandcard"><img src="logo.png" alt=""><div class="t"><b>Baatora</b><small id="sver">Tez. Surakshit. Apna Browser.</small></div><span class="flag">' + FLAG_SVG + 'Made in India</span></div>';
      if (INCOG) h += '<div class="none">🕶 Incognito me account use nahi hota</div>';
      else if (a) h += '<div class="acctcard"><span class="av big on">' + esc(ini(a.name)) + '</span><div class="t"><b>' + esc(a.name) + '</b><small>' + esc(a.email) + '</small></div><button class="btn red" id="aout">Sign out</button></div>' +
        '<div class="set"><div class="t"><b>Naam badlein</b><small>Profile me jo naam dikhega</small></div><input class="in" id="anm" value="' + esc(a.name) + '" maxlength="40"><button class="btn" id="asv">Save</button></div>';
      else h += '<div class="acctcard"><span class="av big"><svg><use href="#i-user"/></svg></span><div class="t"><b>Baatora me sign in karein</b><small>Apna Baatora account banayein — naam aur settings ek jagah.</small></div><button class="btn" id="ain">Sign in</button><button class="btn pri" id="aup">Sign up</button></div>';
      h += SET('restore', '#40C4FF,#304FFE', 'Sync (jald aa raha hai)', 'Phone aur PC ke bookmarks, history aur passwords ek saath — abhi account sirf is computer par hai.');
      break;
    case 'autofill':
      h += '<p class="sub">Passwords is computer par Windows ki encryption se save hote hain. Websites par ye apne aap nahi bharte — “Password copy” dabakar paste karein.</p>' +
        '<div class="set pwadd"><input class="in" id="pws" placeholder="Website (jaise instagram.com)"><input class="in" id="pwu" placeholder="Username / Email"><input class="in" id="pwp" type="password" placeholder="Password"><button class="btn pri" id="pwadd">Save</button></div><div class="perr" id="pwerr"></div><div id="pwlist"></div>';
      break;
    case 'privacy':
      h += swS('adblock', 'shield', '#69F0AE,#00A152', 'Ad Blocker', 'Websites ke ads, popups aur tracking band. YouTube par ads aate hain, lekin video bina rukawat chalta hai.') +
        swF('dnt', false, 'info', '#40C4FF,#0277BD', '“Do Not Track” request bhejein', 'Websites ko bataye ki aap tracking nahi chahte') +
        swF('httpsOnly', false, 'shield', '#448AFF,#1A3FD8', 'Hamesha surakshit connection (HTTPS)', 'http:// sites ko https:// par kholne ki koshish') +
        swP('geolocation', 'loc', '#FF8A00,#FFC107', 'Websites location maang sakein', 'Chalu: har site pehle aapse poochhegi (Chrome jaisa). Band: koi site location nahi le payegi') +
        swP('media', 'cam', '#B388FF,#6200EA', 'Camera aur Microphone ki ijaazat', 'Band karne par websites camera/mic use nahi kar payengi') +
        swP('notifications', 'bell', '#FF80AB,#C51162', 'Notifications ki ijaazat', 'Websites se notifications aane dein') +
        SET('loc', '#FF6D00,#FFAB00', 'Windows Location', 'Location ke liye Windows me bhi Location chalu honi chahiye (Settings › Privacy › Location)', '<button class="btn" id="swloc">Windows Location settings</button>') +
        '<h4 class="sh2">Site settings — kis site ko kya ijaazat di</h4><div id="sitepermList"></div>' +
        SET('broom', '#FF5252,#B71C1C', 'Browsing data saaf karein', 'History, cache, cookies (login bhi hat jayega)', '<button class="btn" id="sch">History</button><button class="btn" id="scc">Cache</button><button class="btn red" id="sck">Cookies</button>');
      break;
    case 'perf':
      h += swF('hwaccel', true, 'desk', '#FF5252,#AD1457', 'Video ke liye Graphics (Hardware acceleration)', 'YouTube/video kaala (black) dikhe ya atke to ise band karke Baatora dobara kholein', true) +
        swF('autoplay', true, 'speed', '#FFD740,#FF9100', 'Video apne aap chalu (Autoplay)', 'Video bina click kiye turant chale', true) +
        swF('smoothScroll', true, 'speed', '#69F0AE,#00897B', 'Smooth scrolling', 'Page narmi se scroll ho — atke to band karein', true) +
        swS('memSaver', 'speed', '#40C4FF,#304FFE', 'Memory Saver (Chrome jaisa)', 'Jo tab der se use nahi hua use sula dein — RAM aur CPU khali, Baatora tez. Click karte hi tab wapas load ho jayega. Gaana/video chal raha tab nahi sota.') +
        SET('hist', '#B388FF,#6200EA', 'Tab kitni der baad soye', 'Memory Saver ke liye', '<select id="ssleep">' + selOpts([[5, '5 minute'], [15, '15 minute'], [30, '30 minute'], [60, '1 ghanta'], [180, '3 ghante']], S.sleepMin || 15) + '</select>') +
        SET('desk', '#69F0AE,#00A152', 'Abhi RAM kitni use ho rahi hai', '<span id="smem">Dekh rahe hain…</span>', '<button class="btn" id="ssleepnow">Peeche ke tabs abhi sulayein</button>');
      break;
    case 'look':
      h += '<div class="set">' + ICO('sun', '#FF8A00,#1E5BFF') + '<div class="t"><b>Browser ka rang (Theme)</b><small>Upar ki patti, menu aur Home page ka rang chunein</small></div><div class="themes">' +
        Object.keys(THEMES).filter((k) => k !== 'incog').map((k) => '<div class="th' + ((S.theme || 'light') === k ? ' on' : '') + '" data-th="' + k + '" style="--b:' + THEMES[k].bar + ';--t:' + THEMES[k].tool + '"><i></i><span>' + THEMES[k].n + '</span></div>').join('') + '</div></div>' +
        swS('night', 'moon', '#7C4DFF,#311B92', 'Night mode', 'Har website ko dark karke dikhaye') +
        swS('bmbar', 'bm', '#FFD740,#FF6D00', 'Bookmarks bar', 'Address bar ke neeche bookmarks dikhayein');
      break;
    case 'engine':
      h += SET('zoom', '#00E5FF,#00838F', 'Address bar me search engine', 'Address bar aur Home page se search', '<select id="seng">' + selOpts(Object.keys(ENG).map((k) => [k, ENGN[k]]), S.engine) + '</select>');
      break;
    case 'default':
      h += SET('globe', '#FF8A00,#FFC107', 'Baatora ko Default browser banayein', 'Har link Baatora me khulega (Windows Settings khulegi — wahan Baatora chunein)', '<button class="btn pri" id="sdef">Default banayein</button>');
      break;
    case 'startup': {
      const m = S.startMode || (S.restore ? 'restore' : 'newtab');
      const rad = (v, t, s) => '<label class="set rad"><input type="radio" name="sm" value="' + v + '"' + (m === v ? ' checked' : '') + '><div class="t"><b>' + t + '</b><small>' + s + '</small></div></label>';
      h += rad('newtab', 'Naya tab page kholein', 'Baatora hamesha Home page se shuru hoga') +
        rad('restore', 'Jahan chhoda tha wahin se jaari rakhein', 'Pichhle tabs wapas khulenge') +
        rad('page', 'Ek khaas page kholein', 'Neeche us page ka address likhein') +
        '<div class="set"><div class="t"><b>Startup page</b><small>jaise google.com ya youtube.com</small></div><input class="in" id="spg" style="width:320px;max-width:100%" placeholder="Website ka naam" value="' + esc(S.startPage || '') + '"></div>';
      break;
    }
    case 'lang':
      h += SET('lang', '#40C4FF,#304FFE', 'Websites ki bhasha', 'Websites aapko kis bhasha me dikhein (page reload karna padega)', '<select id="slang">' + selOpts(LANGS, FL.lang || '') + '</select>') +
        SET('save', '#69F0AE,#00897B', 'Spell check', 'Likhte samay galat spelling par laal line', '<div class="sw" id="sspell"></div>') +
        SET('lang', '#FFD740,#FF9100', 'Spell check ki bhasha', 'Kis bhasha ke hisaab se spelling jaanchi jaye', '<select id="sspl"><option>…</option></select>');
      break;
    case 'dl':
      h += SET('folder', '#64FFDA,#00897B', 'Downloads folder', '<span id="sdlp">…</span>', '<button class="btn" id="sdlc">Badlein</button><button class="btn" id="sdlo">Kholein</button>') +
        swF('askDl', false, 'dl', '#448AFF,#1A3FD8', 'Har file se pehle poochhein ki kahan save karni hai', 'Download se pehle Windows ka “Save as” dialog khulega');
      break;
    case 'access':
      h += SET('zoom', '#40C4FF,#0277BD', 'Default page zoom', 'Naye pages is size me khulenge', '<select id="szoom">' + selOpts([75, 90, 100, 110, 125, 150, 175, 200].map((z) => [z, z + '%']), S.zoomDef || 100) + '</select>') +
        swS('reduceMotion', 'speed', '#B388FF,#6200EA', 'Animations kam karein', 'Browser ke menu aur panels me animation band') +
        SET('key', '#90A4AE,#455A64', 'Keyboard shortcuts', 'Ctrl+T naya tab • Ctrl+W band • Ctrl+Shift+T band tab wapas • Ctrl+L address bar • Ctrl+F khojein • Ctrl+D bookmark • Ctrl+H history • Ctrl+J downloads • F11 full screen • Ctrl+Shift+N incognito');
      break;
    case 'system':
      h += SET('globe', '#448AFF,#1A3FD8', 'Proxy settings', 'Windows ki proxy settings kholein', '<button class="btn" id="sprox">Kholein</button>') +
        SET('restore', '#FF8A00,#FFC107', 'Baatora dobara chalayein', 'Browser band hokar turant wapas khulega', '<button class="btn" id="srel">Relaunch</button>') +
        SET('code', '#78909C,#37474F', 'Developer tools', 'Kisi bhi page par F12 dabayein');
      break;
    case 'reset':
      h += SET('restore', '#FF5252,#AD1457', 'Settings ko original par laayein', 'Theme, search engine, startup aur baaki sab settings default ho jayengi. History, bookmarks, passwords aur account nahi hatenge.', '<button class="btn red" id="srst">Reset settings</button>');
      break;
    case 'ext':
      h += '<p class="sub">Extension ko unzip karke uska folder (jisme manifest.json ho) yahan jodein. Sab Chrome extensions Baatora me nahi chalte — ye abhi experimental hai.</p>' +
        SET('ext', '#7C4DFF,#311B92', 'Extension jodein', 'Unpacked extension folder chunein', '<button class="btn pri" id="xadd">Folder se jodein</button>') +
        SET('globe', '#448AFF,#1A3FD8', 'Chrome Web Store', 'Extensions dhoondhne ke liye', '<button class="btn" id="xstore">Kholein</button>') +
        '<div class="perr" id="xerr"></div><div id="xlist"></div>';
      break;
    case 'about':
      h += '<div class="brandcard"><img src="logo.png" alt=""><div class="t"><b>Baatora</b><small id="sver">…</small></div><span class="flag">' + FLAG_SVG + 'Made in India</span></div>' +
        '<div class="set"><div class="t"><b>Version</b><small id="aver2">…</small></div></div>' +
        SET('info', '#40C4FF,#0277BD', 'Baatora ke baare me', 'Founder, kahani aur Baatora ka bhavishya', '<button class="btn pri" id="sabout">Padhein</button>');
      break;
  }
  el.innerHTML = h;
  bindSec(el, sec);
}

function bindSec(el, sec) {
  const on = (id, fn) => { const e = $(id); if (e) e.onclick = fn; };
  el.querySelectorAll('.sw[data-k],.sw[data-f],.sw[data-p]').forEach((s) => s.onclick = async () => {
    if (s.dataset.k) {
      const k = s.dataset.k; S[k] = !S[k]; saveSet(); s.classList.toggle('on', S[k]);
      if (k === 'adblock') { window.bt.adblock(S.adblock); updShield(); }
      if (k === 'bmbar') renderBm();
      if (k === 'night') tabs.forEach((t) => applyNight(t, S.night));
      if (k === 'reduceMotion') applyMotion();
    } else if (s.dataset.f) {
      const f = s.dataset.f, v = !s.classList.contains('on'); s.classList.toggle('on', v); FL[f] = v; await window.bt.setFlag(f, v);
      if (s.dataset.rl) { if (confirm('Ye badlav Baatora dobara kholne par lagega. Abhi dobara kholein?')) window.bt.relaunch(); } else toast('Save ho gaya');
    } else if (s.dataset.p) {
      const p = s.dataset.p, v = !s.classList.contains('on'); s.classList.toggle('on', v); FL.perm = Object.assign({}, FL.perm, { [p]: v }); await window.bt.setFlag('perm', FL.perm); toast('Save ho gaya');
    }
  });
  on('swloc', () => window.bt.openOs('ms-settings:privacy-location'));
  if ($('sitepermList') && typeof renderSitePerms === 'function') renderSitePerms();
  // You and Baatora
  on('ain', () => openAuth('in')); on('aup', () => openAuth('up')); on('aout', signOut);
  on('asv', () => {
    const n = $('anm').value.trim(); if (!n) return;
    const list = load('bt_accts', []), a = curAcct(); if (!a) return;
    const x = list.find((y) => y.email === a.email); if (x) { x.name = n; save('bt_accts', list); }
    paintProfile(); renderPanel(); toast('Naam badal gaya');
  });
  // Passwords
  if (sec === 'autofill') {
    const list = () => window.bt.pwList().then((arr) => {
      const box = $('pwlist'); if (!box) return;
      box.innerHTML = arr.length ? arr.map((x) => '<div class="row" data-id="' + esc(x.id) + '"><img src="' + esc(fav('https://' + x.site.replace(/^https?:\/\//i, ''))) + '"><div class="t"><b>' + esc(x.site) + '</b><small>' + esc(x.user || '—') + '</small></div><button class="act cpu">Username copy</button><button class="act cpp">Password copy</button><button class="del">Hatayein</button></div>').join('') : '<div class="none">Abhi koi password save nahi hai</div>';
      box.querySelectorAll('.row').forEach((r) => {
        const id = r.dataset.id, item = arr.find((y) => y.id === id);
        r.querySelector('.cpu').onclick = () => { navigator.clipboard.writeText(item.user || '').then(() => toast('Username copy ho gaya')); };
        r.querySelector('.cpp').onclick = async () => { const pw = await window.bt.pwGet(id); if (pw == null) return toast('Password nahi khul paya'); navigator.clipboard.writeText(pw).then(() => toast('Password copy ho gaya')); };
        r.querySelector('.del').onclick = async () => { if (confirm('Ye password hatayein?')) { await window.bt.pwDel(id); list(); } };
      });
    });
    list();
    on('pwadd', async () => {
      const r = await window.bt.pwAdd($('pws').value, $('pwu').value, $('pwp').value);
      if (!r.ok) { $('pwerr').textContent = r.err || 'Save nahi hua'; return; }
      $('pwerr').textContent = ''; $('pws').value = $('pwu').value = $('pwp').value = ''; toast('Password save ho gaya'); list();
    });
  }
  // Privacy
  on('sch', () => { HIST = []; saveHist(); toast('History saaf ho gayi'); });
  on('scc', async () => { await window.bt.clearData({ cache: true }); toast('Cache saaf ho gaya'); });
  on('sck', async () => { if (!confirm('Sab cookies aur site data delete karein? Websites se logout ho jayenge.')) return; await window.bt.clearData({ cookies: true }); toast('Cookies saaf ho gayi'); });
  // Appearance
  el.querySelectorAll('.th').forEach((t) => t.onclick = () => { S.theme = t.dataset.th; saveSet(); applyTheme(); el.querySelectorAll('.th').forEach((x) => x.classList.toggle('on', x === t)); toast('🎨 Rang: ' + THEMES[S.theme].n); });
  // Search engine
  if ($('seng')) $('seng').onchange = (e) => { S.engine = e.target.value; saveSet(); applyTheme(); toast('Search engine: ' + ENGN[S.engine]); };
  on('sdef', () => window.bt.defaultBrowser());
  // Startup
  el.querySelectorAll('input[name=sm]').forEach((r) => r.onchange = () => { S.startMode = r.value; S.restore = r.value === 'restore'; saveSet(); toast('Save ho gaya'); });
  if ($('spg')) $('spg').onchange = (e) => { S.startPage = e.target.value.trim(); if (S.startPage && S.startMode !== 'page') { S.startMode = 'page'; S.restore = false; } saveSet(); renderSettings($('pbody')); toast('Startup page save ho gaya'); };
  // Languages
  if ($('slang')) $('slang').onchange = async (e) => { FL.lang = e.target.value; await window.bt.setLang(e.target.value); toast('Bhasha badal gayi — page reload karein'); };
  if ($('sspell')) window.bt.spellInfo().then((i) => {
    const sw = $('sspell'), sel = $('sspl'); if (!sw || !sel) return;
    sw.classList.toggle('on', i.enabled);
    let dn = null; try { dn = new Intl.DisplayNames(['en'], { type: 'language' }); } catch (e) {}
    const nm = (c) => { try { return dn ? dn.of(c) + ' (' + c + ')' : c; } catch (e) { return c; } };
    sel.innerHTML = selOpts(i.available.map((c) => [c, nm(c)]), (i.langs || [])[0]);
    sw.onclick = async () => { const v = !sw.classList.contains('on'); sw.classList.toggle('on', v); await window.bt.spellSet(v, i.langs); toast('Save ho gaya'); };
    sel.onchange = async () => { i.langs = [sel.value]; await window.bt.spellSet(sw.classList.contains('on'), [sel.value]); toast('Spell check ki bhasha badal gayi'); };
  });
  // Downloads
  on('sdlo', () => window.bt.dl('', 'folder'));
  on('sdlc', async () => { const p = await window.bt.pickDlDir(); if (p && $('sdlp')) $('sdlp').textContent = p; });
  if (sec === 'dl') window.bt.info().then((i) => { const e = $('sdlp'); if (e) e.textContent = i.downloads; });
  // Accessibility
  if ($('ssleep')) $('ssleep').onchange = (e) => { S.sleepMin = +e.target.value; saveSet(); toast('Tab ' + S.sleepMin + ' minute baad soyenge'); };
  if ($('smem')) window.bt.memInfo().then((m) => { if (m && $('smem')) $('smem').textContent = 'Lagbhag ' + m.mb + ' MB • ' + tabs.length + ' tabs (' + tabs.filter((x) => x.sleeping).length + ' so rahe hain)'; });
  on('ssleepnow', () => { let n = 0; tabs.forEach((x) => { if (x !== cur && discardTab(x)) n++; }); toast(n ? '💤 ' + n + ' tab sula diye — RAM khali' : 'Sulane layak koi tab nahi'); });
  if ($('szoom')) $('szoom').onchange = (e) => { S.zoomDef = +e.target.value; saveSet(); toast('Naye pages ' + S.zoomDef + '% par khulenge'); };
  // System / Reset
  on('sprox', () => window.bt.openOs('ms-settings:network-proxy'));
  on('srel', () => { if (confirm('Baatora dobara chalayein?')) window.bt.relaunch(); });
  on('srst', () => {
    if (!confirm('Saari settings original par aa jayengi aur Baatora dobara khulega. Aage badhein?')) return;
    try { localStorage.removeItem('bt_set'); } catch (e) {}
    window.bt.resetFlags();
  });
  // Extensions
  if (sec === 'ext') {
    const list = () => window.bt.extList().then((arr) => {
      const box = $('xlist'); if (!box) return;
      box.innerHTML = arr.length ? arr.map((x) => '<div class="row" data-p="' + esc(x.path) + '"><div class="t"><b>' + esc(x.name) + '</b><small>' + esc(x.path) + '</small></div><button class="del">Hatayein</button></div>').join('') : '<div class="none">Abhi koi extension nahi jodi gayi</div>';
      box.querySelectorAll('.row').forEach((r) => r.querySelector('.del').onclick = async () => { await window.bt.extRemove(r.dataset.p); list(); toast('Extension hata di'); });
    });
    list();
    on('xadd', async () => { const r = await window.bt.extAdd(); if ($('xerr')) $('xerr').textContent = r.ok ? '' : (r.err || ''); if (r.ok) { toast('Extension jud gayi'); list(); } });
    on('xstore', () => { closePanel(); newTab('https://chromewebstore.google.com/'); });
  }
  // About
  if (sec === 'about' || sec === 'google') window.bt.info().then((i) => {
    const v = $('sver'); if (v) v.textContent = 'Version ' + i.version + ' • Created by Anil Yadav';
    const v2 = $('aver2'); if (v2) v2.textContent = 'Baatora ' + i.version + ' • Chromium ' + i.chrome + ' • Electron ' + i.electron;
  });
  on('sabout', () => openPanel('about'));
}

function applyMotion() { document.body.classList.toggle('nomo', !!S.reduceMotion); }
applyMotion();

/* ---------------- Find in page ---------------- */
let findOpen = false;
function openFind() { if (!cur) return; findOpen = true; $('findbar').classList.add('show'); $('findq').focus(); $('findq').select(); if ($('findq').value) doFind(true); }
function closeFind() { findOpen = false; $('findbar').classList.remove('show'); try { cur.wv.stopFindInPage('clearSelection'); } catch (e) {} $('findc').textContent = '0/0'; }
function doFind(fwd, next) { const q = $('findq').value; if (!q) { try { cur.wv.stopFindInPage('clearSelection'); } catch (e) {} $('findc').textContent = '0/0'; return; } cur.wv.findInPage(q, { forward: fwd !== false, findNext: !!next }); }
$('findq').addEventListener('input', () => doFind(true));
$('findq').addEventListener('keydown', (e) => { if (e.key === 'Enter') doFind(!e.shiftKey, true); if (e.key === 'Escape') closeFind(); });
$('findn').onclick = () => doFind(true, true);
$('findp').onclick = () => doFind(false, true);
$('findx').onclick = closeFind;

/* ---------------- Page tools ---------------- */
function setZoom(z) { if (!cur) return; cur.zoom = Math.max(0.25, Math.min(5, Math.round(z * 100) / 100)); cur.wv.setZoomFactor(cur.zoom); $('zval').textContent = Math.round(cur.zoom * 100) + '%'; toast('Zoom ' + Math.round(cur.zoom * 100) + '%'); }
const NIGHT_CSS = 'html{filter:invert(.9) hue-rotate(180deg)!important;background:#fff!important}img,video,picture,canvas,iframe,svg image,[style*="background-image"]{filter:invert(1) hue-rotate(180deg)!important}';
async function applyNight(t, on) {
  if (!t.ready || isHome(t.url)) return;
  try {
    if (on && !t.nightKey) t.nightKey = await t.wv.insertCSS(NIGHT_CSS);
    else if (!on && t.nightKey) { await t.wv.removeInsertedCSS(t.nightKey); t.nightKey = null; }
  } catch (e) { t.nightKey = null; }
}
const READER_JS = `(function(){var a=document.querySelector('article')||document.querySelector('main')||document.querySelector('[role=main]')||document.body;
var t=document.title;var c=a.cloneNode(true);c.querySelectorAll('script,style,nav,aside,footer,header,form,iframe,button,.ad,.ads,[class*=share],[class*=comment],[id*=comment]').forEach(function(e){e.remove()});
document.documentElement.innerHTML='<head><meta charset=utf-8><title></title><style>body{max-width:760px;margin:40px auto;padding:0 22px;font:19px/1.75 Georgia,serif;background:#FBF7EE;color:#222}h1{font:700 32px/1.3 "Segoe UI",sans-serif;margin-bottom:24px}img,video{max-width:100%;height:auto;border-radius:10px}a{color:#1E5BFF}pre{white-space:pre-wrap}</style></head><body><h1></h1><div id=rd></div></body>';
document.title=t;document.querySelector('h1').textContent=t;document.getElementById('rd').appendChild(c);})()`;

/* ---------------- baatora:// links (Home page) ---------------- */
function baatora(u, wcId) {
  let p; try { p = new URL(u); } catch (e) { return; }
  const what = (p.hostname || p.pathname.replace(/^\/+/, '')).toLowerCase();
  const t = tabs.find((x) => x.wcId === wcId) || cur;
  switch (what) {
    case 'downloads': case 'history': case 'bookmarks': case 'settings': case 'about': openPanel(what); break;
    case 'incognito': window.bt.newWindow({ incog: true }); break;
    case 'home': goHome(); break;
    case 'vpn': toast('🛡 Free VPN abhi sirf Baatora Android app me hai'); break;
    case 'notifications': toast('🔔 Koi nayi notification nahi'); break;
    case 'voice': addr.focus(); toast('🎤 Voice search PC par jald aayega — abhi type karke khojein'); break;
    case 'clip': { const v = p.searchParams.get('u'); if (v && t) { t.wv.loadURL(toUrl(v)).catch(() => {}); } break; }
    case 'clipx': break;
    default: toast('Ye feature PC version me jald aayega');
  }
}
window.bt.on('baatora', baatora);

/* ---------------- Menu ---------------- */
function closePops() { const tm = $('tabmenu'); if (tm) tm.classList.remove('show'); $('profpop').classList.remove('show'); $('menu').classList.remove('show'); $('dlpop').classList.remove('show'); $('sitepop').classList.remove('show'); sugg.style.display = 'none'; }
$('menubtn').onclick = (e) => { e.stopPropagation(); const m = $('menu'); const on = m.classList.contains('show'); closePops(); if (!on) { $('zval').textContent = Math.round((cur ? cur.zoom : 1) * 100) + '%'; m.classList.add('show'); } };
document.addEventListener('mousedown', (e) => { if (!e.target.closest('#menu,#menubtn,#dlpop,#dlbtn,#omni,#sitepop,#profpop,#profbtn')) closePops(); });
$('menu').addEventListener('click', (e) => {
  const b = e.target.closest('[data-a]'); if (!b) return;
  const a = b.dataset.a;
  if (!['zin', 'zout'].includes(a)) closePops();
  action(a);
});

function action(a) {
  const t = cur;
  switch (a) {
    case 'newtab': newTab(); break;
    case 'newwin': window.bt.newWindow({}); break;
    case 'incog': window.bt.newWindow({ incog: true }); break;
    case 'history': case 'downloads': case 'bookmarks': case 'settings': case 'about': openPanel(a); break;
    case 'zin': setZoom((t ? t.zoom : 1) + 0.1); break;
    case 'zout': setZoom((t ? t.zoom : 1) - 0.1); break;
    case 'zreset': setZoom(1); break;
    case 'fs': window.bt.fullscreen(); break;
    case 'find': openFind(); break;
    case 'print': openPrint(t); break;
    case 'printsys': if (t && t.wcId) window.bt.printSystem(t.wcId); break;
    case 'translate': translatePage(); break;
    case 'qr': showQr(); break;
    case 'deskshort': deskShortcut(); break;
    case 'source': viewSource(); break;
    case 'openfile': openFileDlg(); break;
    case 'reopen': { const u = closed.pop(); if (u) newTab(u); else toast('Koi band tab nahi'); break; }
    case 'cleardata': openPanel('settings', 'privacy'); break;
    case 'copyurl': if (t && !isHome(t.url)) navigator.clipboard.writeText(t.url).then(() => toast('🔗 Link copy ho gaya')).catch(() => {}); break;
    case 'save': if (t && t.wcId) window.bt.savePage(t.wcId).then((ok) => { if (ok) toast('💾 Page save ho gaya'); }); break;
    case 'desktop': if (t) { t.mobile = !t.mobile; t.wv.setUserAgent(t.mobile ? MOBILE_UA : navigator.userAgent.replace(/\sElectron\/\S+/, '').replace(/\sBaatora\/\S+/i, '').replace(/\sbaatora-pc\/\S+/i, '')); t.wv.reload(); toast(t.mobile ? '📱 Mobile site' : '🖥 Desktop site'); } break;
    case 'reader': if (t && !isHome(t.url)) t.wv.executeJavaScript(READER_JS).catch(() => {}); break;
    case 'night': S.night = !S.night; saveSet(); tabs.forEach((x) => applyNight(x, S.night)); toast(S.night ? '🌙 Night mode chalu' : 'Night mode band'); break;
    case 'devtools': if (t) { if (t.wv.isDevToolsOpened()) t.wv.closeDevTools(); else t.wv.openDevTools(); } break;
    case 'exit': window.bt.quit(); break;
  }
}

/* ---------------- Keyboard shortcuts ---------------- */
function shortcut(c) {
  const t = cur;
  const m = /^ctrl\+([1-9])$/.exec(c);
  if (m) { const n = +m[1]; select(n === 9 ? tabs[tabs.length - 1] : tabs[n - 1]); return true; }
  switch (c) {
    case 'ctrl+t': newTab(); break;
    case 'ctrl+w': if (t) closeTab(t); break;
    case 'ctrl+n': action('newwin'); break;
    case 'ctrl+shift+n': action('incog'); break;
    case 'ctrl+shift+t': { const u = closed.pop(); if (u) newTab(u); break; }
    case 'ctrl+l': case 'alt+d': case 'f6': addr.focus(); addr.select(); break;
    case 'ctrl+r': case 'f5': if (t) t.wv.reload(); break;
    case 'ctrl+f': openFind(); break;
    case 'ctrl+h': openPanel('history'); break;
    case 'ctrl+j': openPanel('downloads'); break;
    case 'ctrl+shift+b': S.bmbar = !S.bmbar; saveSet(); renderBm(); break;
    case 'ctrl+d': toggleBm(); break;
    case 'ctrl+p': action('print'); break;
    case 'ctrl+=': case 'ctrl++': action('zin'); break;
    case 'ctrl+-': action('zout'); break;
    case 'ctrl+0': action('zreset'); break;
    case 'ctrl+tab': if (tabs.length > 1) select(tabs[(tabs.indexOf(t) + 1) % tabs.length]); break;
    case 'ctrl+shift+tab': if (tabs.length > 1) select(tabs[(tabs.indexOf(t) - 1 + tabs.length) % tabs.length]); break;
    case 'alt+arrowleft': try { t.wv.goBack(); } catch (e) {} break;
    case 'alt+arrowright': try { t.wv.goForward(); } catch (e) {} break;
    case 'alt+home': goHome(); break;
    case 'f11': window.bt.fullscreen(); break;
    case 'f12': case 'ctrl+shift+i': action('devtools'); break;
    case 'ctrl+shift+delete': openPanel('settings', 'privacy'); break;
    case 'ctrl+shift+p': action('printsys'); break;
    case 'ctrl+u': action('source'); break;
    case 'ctrl+s': action('save'); break;
    case 'ctrl+o': action('openfile'); break;
    case 'ctrl+shift+r': case 'shift+f5': hardReload(); break;
    case 'ctrl+shift+j': case 'ctrl+shift+c': action('devtools'); break;
    case 'ctrl+shift+w': window.bt.closeWindow(); break;
    case 'ctrl+shift+o': openPanel('bookmarks'); break;
    case 'ctrl+pagedown': if (tabs.length > 1) select(tabs[(tabs.indexOf(t) + 1) % tabs.length]); break;
    case 'ctrl+pageup': if (tabs.length > 1) select(tabs[(tabs.indexOf(t) - 1 + tabs.length) % tabs.length]); break;
    case 'ctrl+f4': if (t) closeTab(t); break;
    case 'f3': case 'ctrl+g': if (findOpen) doFind(true, true); else openFind(); break;
    case 'ctrl+shift+g': if (findOpen) doFind(false, true); else openFind(); break;
    case 'ctrl+k': case 'ctrl+e': addr.focus(); addr.select(); break;
    case 'qr': showQr(); break;
    case 'translate': translatePage(); break;
    case 'ctrl+q': window.bt.quit(); break;
    case 'save-page': action('save'); break;
    case 'escape':
      if (typeof closePrint === 'function' && closePrint()) break;
      if ($('qrpop').classList.contains('show')) $('qrpop').classList.remove('show');
      else if ($('tabmenu').classList.contains('show')) $('tabmenu').classList.remove('show');
      else if (findOpen) closeFind();
      else if ($('auth').classList.contains('show')) closeAuth();
      else if (panelKind) closePanel();
      else if ($('profpop').classList.contains('show') || $('menu').classList.contains('show') || $('dlpop').classList.contains('show') || $('sitepop').classList.contains('show')) closePops();
      else if (t && t.loading) t.wv.stop();
      break;
    default: return false;
  }
  return true;
}
window.bt.on('shortcut', shortcut);
document.addEventListener('keydown', (e) => {
  const k = e.key.toLowerCase(), c = e.ctrlKey || e.metaKey;
  let combo = null;
  if (c && e.shiftKey) combo = 'ctrl+shift+' + k;
  else if (c) combo = 'ctrl+' + k;
  else if (e.altKey) combo = 'alt+' + k;
  else if (e.shiftKey && k === 'f5') combo = 'shift+f5';
  else if (/^f\d+$/.test(k)) combo = k;
  else if (k === 'escape' && document.activeElement !== addr && document.activeElement !== $('findq')) combo = 'escape';
  if (!combo) return;
  const typing = /^(input|textarea|select)$/i.test(document.activeElement.tagName);
  if (typing && /^ctrl\+[acvxyz]$/.test(combo)) return;
  if (typing && combo === 'ctrl+shift+z') return;
  if (typeof printOpen === 'function' && printOpen() && combo !== 'escape') { if (combo === 'ctrl+p') e.preventDefault(); return; }
  if (shortcut(combo)) e.preventDefault();
});

window.bt.on('open-tab', (u, bg) => { if (u) newTab(u, { bg: !!bg }); });
window.bt.on('search-tab', (s) => newTab(search(s), { bg: false }));
window.bt.on('fullscreen', (on) => document.body.classList.toggle('fs', !!on));

/* ---------------- Start ---------------- */
window.bt.adblock(S.adblock);
applyTheme();
updShield(); renderBm();
(function start() {
  const startUrl = Q.get('url');
  const mode = S.startMode || (S.restore ? 'restore' : 'newtab');
  const sess = (!INCOG && mode === 'restore') ? load('bt_session', null) : null;
  if (sess && Array.isArray(sess.tabs) && sess.tabs.length && !(sess.tabs.length === 1 && isHome(sess.tabs[0]) && startUrl)) {
    const ci = Math.max(0, Math.min(Math.min(sess.tabs.length, 30) - 1, sess.cur | 0));
    // Sirf jo tab aakhri baar khula tha wahi turant load hoga, baaki click karne par (Chrome jaisa)
    newTab(isHome(sess.tabs[ci]) ? homeUrl() : sess.tabs[ci], { title: (sess.titles || [])[ci] });
    sess.tabs.slice(0, 30).forEach((u, i) => {
      if (i === ci) { cur.ord = i; if (sess.pins && sess.pins[i]) cur.pinned = true; return; }
      const nt = newTab(isHome(u) ? homeUrl() : u, { bg: true, lazy: true, index: i, title: (sess.titles || [])[i] || host(u) || 'Naya tab' });
      nt.ord = i; if (sess.pins && sess.pins[i]) nt.pinned = true;
    });
    { const c = cur; tabs.sort((a, b) => (a.ord || 0) - (b.ord || 0)); tabs.forEach((x) => $('tabs').appendChild(x.el)); select(c); }
    layoutTabs();
    if (startUrl) newTab(startUrl);
  } else newTab(startUrl || ((!INCOG && mode === 'page' && S.startPage) ? toUrl(S.startPage) : homeUrl()));
  if (INCOG) toast('🕶 Incognito: history, cookies save nahi honge');
})();
