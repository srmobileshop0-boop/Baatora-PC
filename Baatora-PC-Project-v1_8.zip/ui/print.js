/* Baatora PC — Chrome jaisa Print Preview (Ctrl+P)
   Left: page ka asli preview (PDF)  •  Right: Destination, Pages, Layout, Color, More settings */
'use strict';
const PR = Object.assign({
  dest: 'pdf', pagesMode: 'all', custom: '', landscape: false, color: 'color', paper: 'A4', pps: 1,
  margins: 'default', mt: 10, mb: 10, ml: 10, mr: 10, scaleMode: 'default', scale: 100,
  hf: false, bg: false, copies: 1, collate: true, duplex: 'simplex', dpi: '', more: false
}, load('bt_print', {}));
PR.pagesMode = 'all'; PR.custom = ''; PR.copies = 1;

let pvTab = null, pvSeq = 0, pvTimer = 0, pvTotal = 0, pvPages = 0, pvPrinters = [], pvBad = false, pvBusy = false;
const PAPER_LIST = [['A4', 'A4'], ['Letter', 'Letter'], ['Legal', 'Legal'], ['A3', 'A3'], ['A5', 'A5'], ['Tabloid', 'Tabloid'], ['Ledger', 'Ledger']];

function pvBuild() {
  if ($('pv')) return;
  const d = document.createElement('div');
  d.id = 'pv';
  d.innerHTML =
    '<div class="pv-box" role="dialog" aria-label="Print">' +
      '<div class="pv-left"><div class="pv-stage">' +
        '<iframe id="pvf" title="Print preview"></iframe>' +
        '<div class="pv-load" id="pvLoad"><i class="spin"></i><span>Preview ban raha hai…</span></div>' +
        '<div class="pv-msg" id="pvMsg"></div>' +
      '</div></div>' +
      '<div class="pv-right">' +
        '<div class="pv-head"><h2>Print</h2><span id="pvSheets"></span></div>' +
        '<div class="pv-scroll">' +
          pvRow('Destination', '<select id="pvDest"></select>') +
          pvRow('Pages', '<select id="pvPages"><option value="all">All</option><option value="odd">Odd pages only</option><option value="even">Even pages only</option><option value="custom">Custom</option></select>') +
          '<div class="pv-row pv-sub" id="pvCustomRow"><span></span><div><input id="pvCustom" class="pv-in" placeholder="jaise 1-5, 8, 11-13" spellcheck="false"><small id="pvCustomErr" class="pv-err">Galat page range — jaise 1-5, 8, 11-13</small></div></div>' +
          pvRow('Copies', '<div class="pv-copies"><input id="pvCopies" class="pv-in" type="number" min="1" max="999" value="1"><label class="pv-ck" id="pvCollateL"><input type="checkbox" id="pvCollate"> Collate</label></div>', 'pvCopiesRow', true) +
          pvRow('Layout', '<select id="pvLayout"><option value="p">Portrait</option><option value="l">Landscape</option></select>') +
          pvRow('Color', '<select id="pvColor"><option value="color">Color</option><option value="bw">Black and white</option></select>', 'pvColorRow', true) +
          '<button class="pv-more" id="pvMoreBtn"><span>More settings</span><svg viewBox="0 0 24 24"><path d="M7.41 8.59L12 13.17l4.59-4.58L18 10l-6 6-6-6z"/></svg></button>' +
          '<div id="pvMore">' +
            pvRow('Paper size', '<select id="pvPaper">' + PAPER_LIST.map((p) => '<option value="' + p[0] + '">' + p[1] + '</option>').join('') + '</select>') +
            pvRow('Pages per sheet', '<select id="pvPps">' + [1, 2, 4, 6, 9, 16].map((n) => '<option value="' + n + '">' + n + '</option>').join('') + '</select>', 'pvPpsRow', true) +
            pvRow('Margins', '<select id="pvMargins"><option value="default">Default</option><option value="none">None</option><option value="min">Minimum</option><option value="custom">Custom</option></select>') +
            '<div class="pv-row pv-sub" id="pvMarginBox"><span></span><div class="pv-mgrid">' +
              ['mt:Upar', 'mb:Neeche', 'ml:Baayein', 'mr:Daayein'].map((x) => { const [k, l] = x.split(':'); return '<label>' + l + '<input class="pv-in" type="number" min="0" max="100" step="1" data-m="' + k + '"><i>mm</i></label>'; }).join('') +
            '</div></div>' +
            pvRow('Scale', '<select id="pvScaleMode"><option value="default">Default</option><option value="custom">Custom</option></select>') +
            '<div class="pv-row pv-sub" id="pvScaleBox"><span></span><div class="pv-scale"><input id="pvScale" class="pv-in" type="number" min="10" max="200" step="5"><i>%</i></div></div>' +
            pvRow('Quality', '<select id="pvDpi"><option value="">Default</option><option value="300">300 dpi</option><option value="600">600 dpi</option></select>', 'pvDpiRow', true) +
            '<div class="pv-row pv-opt" id="pvDuplexRow"><span>Two-sided</span><div><label class="pv-ck"><input type="checkbox" id="pvDuplex"> Dono taraf print (Print on both sides)</label>' +
              '<select id="pvDuplexEdge"><option value="longEdge">Long edge (kitaab jaisa)</option><option value="shortEdge">Short edge (calendar jaisa)</option></select></div></div>' +
            '<div class="pv-row pv-opt"><span>Options</span><div>' +
              '<label class="pv-ck" id="pvHfL"><input type="checkbox" id="pvHf"> Headers and footers</label>' +
              '<label class="pv-ck"><input type="checkbox" id="pvBg"> Background graphics</label>' +
            '</div></div>' +
          '</div>' +
          '<button class="pv-sys" id="pvSys">Print using system dialog… <kbd>Ctrl+Shift+P</kbd></button>' +
        '</div>' +
        '<div class="pv-foot"><button class="pv-btn pri" id="pvGo">Print</button><button class="pv-btn" id="pvCancel">Cancel</button></div>' +
      '</div>' +
    '</div>';
  $('content').appendChild(d);
  d.addEventListener('mousedown', (e) => { if (e.target === d) closePrint(); });

  const ch = (id, fn) => $(id).addEventListener('change', fn);
  ch('pvDest', (e) => { PR.dest = e.target.value; pvPaint(); pvRefresh(); });
  ch('pvPages', (e) => { PR.pagesMode = e.target.value; pvPaint(); if (PR.pagesMode === 'custom') { $('pvCustom').focus(); if (!PR.custom.trim()) return; } pvRefresh(); });
  $('pvCustom').addEventListener('input', (e) => { PR.custom = e.target.value; pvRefresh(450); });
  $('pvCopies').addEventListener('input', (e) => { PR.copies = Math.max(1, Math.min(999, parseInt(e.target.value, 10) || 1)); pvPaint(); });
  ch('pvCollate', (e) => { PR.collate = e.target.checked; });
  ch('pvLayout', (e) => { PR.landscape = e.target.value === 'l'; pvRefresh(); });
  ch('pvColor', (e) => { PR.color = e.target.value; pvPaint(); });
  $('pvMoreBtn').onclick = () => { PR.more = !PR.more; pvPaint(); };
  ch('pvPaper', (e) => { PR.paper = e.target.value; pvRefresh(); });
  ch('pvPps', (e) => { PR.pps = +e.target.value; pvPaint(); });
  ch('pvMargins', (e) => { PR.margins = e.target.value; pvPaint(); pvRefresh(); });
  d.querySelectorAll('[data-m]').forEach((i) => i.addEventListener('input', () => { PR[i.dataset.m] = Math.max(0, Math.min(100, +i.value || 0)); pvRefresh(500); }));
  ch('pvScaleMode', (e) => { PR.scaleMode = e.target.value; pvPaint(); pvRefresh(); });
  $('pvScale').addEventListener('input', (e) => { const v = +e.target.value; if (v >= 10 && v <= 200) { PR.scale = v; pvRefresh(500); } });
  ch('pvDpi', (e) => { PR.dpi = e.target.value; });
  ch('pvDuplex', (e) => { PR.duplex = e.target.checked ? $('pvDuplexEdge').value : 'simplex'; pvPaint(); });
  ch('pvDuplexEdge', (e) => { if (PR.duplex !== 'simplex') PR.duplex = e.target.value; });
  ch('pvHf', (e) => { PR.hf = e.target.checked; pvRefresh(); });
  ch('pvBg', (e) => { PR.bg = e.target.checked; pvRefresh(); });
  $('pvCancel').onclick = closePrint;
  $('pvGo').onclick = pvGo;
  $('pvSys').onclick = () => { const t = pvTab; closePrint(); if (t && t.wcId) window.bt.printSystem(t.wcId); };
  d.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') { e.preventDefault(); e.stopPropagation(); closePrint(); }
    else if (e.key === 'Enter' && !/^(select|button)$/i.test(e.target.tagName)) { e.preventDefault(); pvGo(); }
  });
}
function pvRow(label, ctl, id, printerOnly) {
  return '<div class="pv-row' + (printerOnly ? ' pv-printer' : '') + '"' + (id ? ' id="' + id + '"' : '') + '><span>' + label + '</span><div>' + ctl + '</div></div>';
}

function pvOpts() {
  return {
    dest: PR.dest,
    pages: PR.pagesMode === 'custom' ? (PR.custom.trim() || 'all') : PR.pagesMode,
    landscape: PR.landscape, color: PR.color, paper: PR.paper, pps: PR.pps,
    margins: PR.margins, mt: PR.mt, mb: PR.mb, ml: PR.ml, mr: PR.mr,
    scale: PR.scaleMode === 'custom' ? PR.scale : 100,
    hf: PR.hf, bg: PR.bg, copies: PR.copies, collate: PR.collate, duplex: PR.duplex, dpi: PR.dpi
  };
}
const isPdf = () => PR.dest === 'pdf';

function pvFillDest() {
  const sel = $('pvDest');
  const names = pvPrinters.map((p) => p.name);
  if (PR.dest !== 'pdf' && !names.includes(PR.dest)) PR.dest = 'pdf';
  sel.innerHTML = '<option value="pdf">Save as PDF</option>' +
    (pvPrinters.length ? '<optgroup label="Printers">' + pvPrinters.map((p) => '<option value="' + esc(p.name) + '">' + esc(p.label) + (p.isDefault ? ' (default)' : '') + '</option>').join('') + '</optgroup>' : '');
  sel.value = PR.dest;
}

function pvPaint() {
  const box = $('pv'); if (!box) return;
  box.classList.toggle('pdf', isPdf());
  box.classList.toggle('more', !!PR.more);
  $('pvPages').value = PR.pagesMode;
  $('pvCustomRow').style.display = PR.pagesMode === 'custom' ? '' : 'none';
  $('pvCustom').value = PR.custom;
  $('pvCustom').classList.toggle('bad', pvBad);
  $('pvCustomErr').style.display = pvBad ? 'block' : 'none';
  $('pvCopies').value = PR.copies;
  $('pvCollate').checked = PR.collate;
  $('pvCollateL').style.visibility = PR.copies > 1 ? 'visible' : 'hidden';
  $('pvLayout').value = PR.landscape ? 'l' : 'p';
  $('pvColor').value = PR.color;
  $('pvPaper').value = PR.paper;
  $('pvPps').value = String(PR.pps);
  $('pvMargins').value = PR.margins;
  $('pvMarginBox').style.display = PR.margins === 'custom' ? '' : 'none';
  box.querySelectorAll('[data-m]').forEach((i) => { if (document.activeElement !== i) i.value = PR[i.dataset.m]; });
  $('pvScaleMode').value = PR.scaleMode;
  $('pvScaleBox').style.display = PR.scaleMode === 'custom' ? '' : 'none';
  if (document.activeElement !== $('pvScale')) $('pvScale').value = PR.scale;
  $('pvDpi').value = PR.dpi;
  $('pvDuplex').checked = PR.duplex !== 'simplex';
  $('pvDuplexEdge').style.display = PR.duplex !== 'simplex' ? '' : 'none';
  if (PR.duplex !== 'simplex') $('pvDuplexEdge').value = PR.duplex;
  $('pvHf').checked = PR.hf;
  $('pvHfL').classList.toggle('dis', PR.margins === 'none' || PR.margins === 'min');
  $('pvBg').checked = PR.bg;
  // Black & white ka preview bhi grey dikhe (Chrome jaisa)
  $('pvf').classList.toggle('bw', !isPdf() && PR.color === 'bw');
  // Kitne kaagaz / pages
  let txt = '';
  if (pvPages) {
    if (isPdf()) txt = pvPages + (pvPages === 1 ? ' page' : ' pages');
    else {
      let sheets = Math.ceil(pvPages / (PR.pps || 1));
      if (PR.duplex !== 'simplex') sheets = Math.ceil(sheets / 2);
      sheets *= PR.copies || 1;
      txt = sheets + (sheets === 1 ? ' sheet of paper' : ' sheets of paper');
    }
  }
  $('pvSheets').textContent = txt;
  $('pvGo').textContent = isPdf() ? 'Save' : 'Print';
  $('pvGo').disabled = pvBad || pvBusy || !pvPages;
}

function pvRefresh(delay) {
  clearTimeout(pvTimer);
  pvTimer = setTimeout(pvMake, delay == null ? 120 : delay);
}
async function pvMake() {
  if (!pvTab || !pvTab.wcId) return;
  const my = ++pvSeq;
  $('pvLoad').classList.add('show');
  $('pvMsg').classList.remove('show');
  pvBusy = true; pvPaint();
  const o = pvOpts();
  const r = await window.bt.printPreview(pvTab.wcId, o).catch((e) => ({ err: String(e) }));
  if (my !== pvSeq || !$('pv').classList.contains('show')) return;
  pvBusy = false;
  $('pvLoad').classList.remove('show');
  if (r && r.total) pvTotal = r.total;
  if (r && r.err === 'range') { pvBad = true; pvPaint(); return; }
  pvBad = false;
  if (!r || r.err) {
    pvPages = 0;
    $('pvMsg').textContent = 'Preview nahi ban paya' + (r && r.err ? ': ' + r.err : '');
    $('pvMsg').classList.add('show');
    pvPaint(); return;
  }
  pvPages = r.pages || 1;
  $('pvf').src = r.url + '#toolbar=0&navpanes=0&scrollbar=1&view=FitH';
  pvPaint();
}

async function openPrint(t) {
  t = t || cur;
  if (!t) return;
  if (!t.wcId) { toast('Page abhi load ho raha hai — thodi der baad Print karein'); return; }
  closePops();
  if (findOpen) closeFind();
  pvBuild();
  pvTab = t; pvPages = 0; pvTotal = 0; pvBad = false;
  PR.pagesMode = 'all'; PR.custom = ''; PR.copies = 1;
  $('pvf').removeAttribute('src');
  $('pv').classList.add('show');
  pvFillDest(); pvPaint(); pvRefresh(0);
  pvPrinters = await window.bt.printers(t.wcId).catch(() => []) || [];
  pvFillDest(); pvPaint();
  setTimeout(() => $('pvDest').focus(), 30);
}
function closePrint() {
  const d = $('pv'); if (!d || !d.classList.contains('show')) return false;
  d.classList.remove('show');
  pvSeq++; clearTimeout(pvTimer);
  $('pvf').removeAttribute('src');
  pvTab = null;
  if (cur) cur.wv.focus();
  return true;
}
function printOpen() { const d = $('pv'); return !!(d && d.classList.contains('show')); }

function pvSavePrefs() {
  const keep = Object.assign({}, PR); delete keep.pagesMode; delete keep.custom; delete keep.copies;
  save('bt_print', keep);
}
async function pvGo() {
  if (!pvTab || pvBad || pvBusy || !pvPages) return;
  const t = pvTab, o = pvOpts(), pdf = isPdf();
  pvSavePrefs();
  closePrint();
  if (!pdf) toast('🖨 Printer ko bhej rahe hain…');
  const r = await window.bt.printDo(t.wcId, o).catch((e) => ({ ok: false, err: String(e) }));
  if (r && r.ok) toast(pdf ? '📄 PDF save ho gaya: ' + (r.path || '').split(/[\\/]/).pop() : '✅ Print ho gaya / printer ki queue me hai');
  else if (r && r.canceled) { /* user ne save cancel kiya */ }
  else toast('Print nahi ho paya' + (r && r.err && r.err !== 'cancelled' ? ': ' + r.err : ''));
}
