// Baatora — har website ke shuru me chalta hai (page ke scripts se pehle).
// YouTube ko ab bilkul nahi chheda jata: ads aate hain, lekin video bina rukawat chalta hai.
// (Is file ko Electron preload ke roop me rakha gaya hai taaki aage zaroorat par kaam jod sakein.)
