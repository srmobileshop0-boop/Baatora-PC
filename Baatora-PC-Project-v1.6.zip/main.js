// Baatora Browser — PC (Windows) version
// Made in India • Created by Anil Yadav, Thane
const { app, BrowserWindow, session, ipcMain, Menu, clipboard, shell, webContents, nativeTheme, dialog, safeStorage } = require('electron');
const path = require('path');
const fs = require('fs');
const { pathToFileURL } = require('url');

app.setName('Baatora');

// ---------- PC flags (Settings se) ----------
const FLAGS_FILE = path.join(app.getPath('userData'), 'baatora-flags.json');
let FLAGS = { hwaccel: true, smoothScroll: true, autoplay: true, dnt: false, httpsOnly: false, perm: {}, askDl: false, dlDir: '', lang: '', spell: true, spellLangs: [], extensions: [] };
try { FLAGS = Object.assign(FLAGS, JSON.parse(fs.readFileSync(FLAGS_FILE, 'utf8'))); } catch (e) {}
function writeFlags() { try { fs.writeFileSync(FLAGS_FILE, JSON.stringify(FLAGS)); } catch (e) {} }
if (FLAGS.hwaccel === false) app.disableHardwareAcceleration();
if (FLAGS.smoothScroll === false) app.commandLine.appendSwitch('disable-smooth-scrolling');
// Video bina click kiye turant chale (Settings > Performance se band kar sakte hain)
if (FLAGS.autoplay !== false) app.commandLine.appendSwitch('autoplay-policy', 'no-user-gesture-required');
if (process.platform === 'win32') app.setAppUserModelId('com.baatora.browser.pc');

const NORMAL = 'persist:baatora';
const INCOG = 'baatora-incognito';
const HOME = pathToFileURL(path.join(__dirname, 'pages', 'home-pc.html')).href;

let adblockOn = true;
const blocked = new Map(); // host webContents id -> count

const AD_HOSTS = /(^|\.)(doubleclick\.net|googlesyndication\.com|googleadservices\.com|adservice\.google\.[a-z.]+|pagead2\.googlesyndication\.com|google-analytics\.com|exoclick\.com|exosrv\.com|exdynsrv\.com|juicyads\.com|trafficstars\.com|tsyndicate\.com|clickadu\.com|hilltopads\.net|adcash\.com|popcash\.net|propellerads\.com|onclkds\.com|clickaine\.com|realsrv\.com|magsrv\.com|adsterra\.com|a-ads\.com|adskeeper\.com|richpush\.co|admaven\.com|ad-maven\.com|bidvertiser\.com|plugrush\.com|yllix\.com|popads\.net|monetag\.com|profitableratecpm\.com|highperformanceformat\.com|effectivegatecpm\.com|oclasrv\.com|taboola\.com|outbrain\.com|mgid\.com|revcontent\.com|zedo\.com|criteo\.com|criteo\.net|moatads\.com|adnxs\.com|amazon-adsystem\.com|scorecardresearch\.com|quantserve\.com|adform\.net|rubiconproject\.com|pubmatic\.com|openx\.net|smartadserver\.com|33across\.com|media\.net|yieldmo\.com|inmobi\.com|vungle\.com|unityads\.unity3d\.com|applovin\.com|chartboost\.com)$/i;

// YouTube par ads aane dete hain (video bina rukawat chale) — isliye YouTube ke requests kabhi nahi roke jate
const YT_PAGE = /^https?:\/\/([^/]*\.)?(youtube\.com|youtube-nocookie\.com|googlevideo\.com|ytimg\.com)(\/|:|$)/i;
function isYT(d) {
  try { const u = (d.webContents && d.webContents.getURL()) || ''; if (YT_PAGE.test(u)) return true; return YT_PAGE.test(d.referrer || ''); } catch (e) { return false; }
}

// ---------- Single instance (link double-click se naya tab) ----------
const gotLock = app.requestSingleInstanceLock();
if (!gotLock) app.quit();
app.on('second-instance', (_e, argv) => {
  const url = urlFromArgs(argv);
  let w = BrowserWindow.getFocusedWindow() || BrowserWindow.getAllWindows().find(x => !x.__incog) || null;
  if (!w) { createWindow({ url }); return; }
  if (w.isMinimized()) w.restore();
  w.focus();
  if (url) w.webContents.send('open-tab', url);
});

function urlFromArgs(argv) {
  const args = argv.slice(app.isPackaged ? 1 : 2);
  for (const a of args) {
    if (!a || a.startsWith('-')) continue;
    if (/^(https?|ftp|file):/i.test(a)) return a;
    try { if (fs.existsSync(a) && fs.statSync(a).isFile()) return pathToFileURL(path.resolve(a)).href; } catch (e) {}
  }
  return null;
}

// ---------- Session setup (adblock, downloads, UA, permissions) ----------
const readySessions = new Set();
function setupSession(part) {
  const ses = session.fromPartition(part);
  if (readySessions.has(part)) return ses;
  readySessions.add(part);

  // Chrome jaisa user-agent (taaki sites sahi chalein)
  const ua = ses.getUserAgent().replace(/\sElectron\/\S+/, '').replace(/\sBaatora\/\S+/i, '').replace(/\sbaatora-pc\/\S+/i, '');
  if (FLAGS.lang) ses.setUserAgent(ua, FLAGS.lang); else ses.setUserAgent(ua);

  // Spell check
  try {
    ses.setSpellCheckerEnabled(FLAGS.spell !== false);
    const av = ses.availableSpellCheckerLanguages || [];
    const sl = (FLAGS.spellLangs || []).filter((l) => av.includes(l));
    if (sl.length) ses.setSpellCheckerLanguages(sl);
  } catch (e) {}

  // Extensions (unpacked folders)
  if (part === NORMAL) (FLAGS.extensions || []).forEach((p) => loadExt(ses, p));

  // Do Not Track / Global Privacy Control
  ses.webRequest.onBeforeSendHeaders({ urls: ['*://*/*'] }, (details, cb) => {
    if (FLAGS.dnt) return cb({ requestHeaders: Object.assign({}, details.requestHeaders, { DNT: '1', 'Sec-GPC': '1' }) });
    cb({});
  });

  ses.webRequest.onBeforeRequest({ urls: ['*://*/*'] }, (details, cb) => {
    // HTTPS-only mode
    if (FLAGS.httpsOnly && details.resourceType === 'mainFrame' && /^http:\/\//i.test(details.url)) {
      try {
        const h = new URL(details.url).hostname;
        if (!/^(localhost|.*\.local|\d+\.\d+\.\d+\.\d+|\[.*\])$/i.test(h)) return cb({ redirectURL: details.url.replace(/^http:/i, 'https:') });
      } catch (e) {}
    }
    if (adblockOn && details.resourceType !== 'mainFrame' && !isYT(details)) {
      try {
        const h = new URL(details.url).hostname;
        if (AD_HOSTS.test(h)) {
          const wc = details.webContents;
          const host = wc && wc.hostWebContents;
          if (host && !host.isDestroyed()) {
            const n = (blocked.get(host.id) || 0) + 1;
            blocked.set(host.id, n);
            host.send('blocked', n);
          }
          return cb({ cancel: true });
        }
      } catch (e) {}
    }
    cb({});
  });

  ses.setPermissionRequestHandler((_wc, perm, cb) => {
    const P = FLAGS.perm || {};
    if (perm === 'geolocation') return cb(P.geolocation !== false);
    if (perm === 'notifications') return cb(P.notifications !== false);
    if (perm === 'media') return cb(P.media !== false);
    cb(['fullscreen', 'media', 'clipboard-read', 'clipboard-sanitized-write', 'pointerLock', 'geolocation', 'notifications', 'openExternal', 'window-management'].includes(perm));
  });

  ses.on('will-download', (_e, item, wc) => {
    const host = (wc && wc.hostWebContents) || wc;
    const dir = dlDir();
    let name = item.getFilename() || 'download';
    let p = path.join(dir, name), i = 1;
    const ext = path.extname(name), base = path.basename(name, ext);
    while (fs.existsSync(p)) p = path.join(dir, `${base} (${i++})${ext}`);
    if (!FLAGS.askDl) item.setSavePath(p); // askDl chalu ho to Windows ka "Save as" dialog khulega
    const curPath = () => item.getSavePath() || p;
    const id = Date.now() + '' + Math.floor(Math.random() * 1000);
    downloads.set(id, item);
    const send = (state) => {
      if (!host || host.isDestroyed()) return;
      host.send('dl', { id, name: path.basename(curPath()), path: curPath(), url: item.getURL(), total: item.getTotalBytes(), received: item.getReceivedBytes(), state, paused: item.isPaused(), ts: Date.now() });
    };
    send('progressing');
    item.on('updated', (_ev, state) => send(state));
    item.once('done', (_ev, state) => { send(state); downloads.delete(id); });
  });
  return ses;
}
const downloads = new Map();
function dlDir() { try { if (FLAGS.dlDir && fs.existsSync(FLAGS.dlDir)) return FLAGS.dlDir; } catch (e) {} return app.getPath('downloads'); }
async function loadExt(ses, p) { try { const api = ses.extensions || ses; return await api.loadExtension(p, { allowFileAccess: true }); } catch (e) { return null; } }
function extName(p) { try { const m = JSON.parse(fs.readFileSync(path.join(p, 'manifest.json'), 'utf8')); return m.name && !/^__MSG/.test(m.name) ? m.name : path.basename(p); } catch (e) { return path.basename(p); } }

// ---------- Windows ----------
function createWindow({ incog = false, url = null } = {}) {
  setupSession(incog ? INCOG : NORMAL);
  const w = new BrowserWindow({
    width: 1280, height: 820, minWidth: 520, minHeight: 400,
    backgroundColor: incog ? '#1A0B3A' : '#FFFFFF',
    title: incog ? 'Baatora Incognito' : 'Baatora',
    icon: path.join(__dirname, 'ui', 'logo.png'),
    titleBarStyle: 'hidden',
    titleBarOverlay: { color: incog ? '#1A0B3A' : '#DFE3E8', symbolColor: incog ? '#FFFFFF' : '#1F2937', height: 40 },
    show: false,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      webviewTag: true,
      spellcheck: true
    }
  });
  w.__incog = incog;
  const q = { incog: incog ? '1' : '0', home: HOME };
  if (url) q.url = url;
  w.loadFile(path.join(__dirname, 'ui', 'index.html'), { query: q });
  w.once('ready-to-show', () => { w.show(); });
  w.on('enter-full-screen', () => w.webContents.send('fullscreen', true));
  w.on('leave-full-screen', () => w.webContents.send('fullscreen', false));
  w.webContents.setWindowOpenHandler(() => ({ action: 'deny' }));
  return w;
}

// ---------- Webview (tab) handling ----------
app.on('web-contents-created', (_e, wc) => {
  wc.on('will-attach-webview', (_ev, prefs, params) => {
    prefs.preload = path.join(__dirname, 'guest-preload.js');
    prefs.nodeIntegration = false;
    prefs.contextIsolation = true;
    prefs.sandbox = true;
    prefs.autoplayPolicy = FLAGS.autoplay !== false ? 'no-user-gesture-required' : 'document-user-activation-required';
    if (params.partition !== NORMAL && params.partition !== INCOG) params.partition = NORMAL;
  });

  if (wc.getType() !== 'webview') return;

  wc.setWindowOpenHandler(({ url, disposition }) => {
    const host = wc.hostWebContents;
    if (host && !host.isDestroyed()) host.send('open-tab', url, disposition === 'background-tab');
    return { action: 'deny' };
  });

  let lastB = '', lastT = 0;
  const onNav = (ev, url) => {
    if (typeof url === 'object' && url) url = url.url;
    if (url && /^baatora:/i.test(url)) {
      ev.preventDefault();
      const now = Date.now();
      if (url === lastB && now - lastT < 600) return;
      lastB = url; lastT = now;
      const host = wc.hostWebContents;
      if (host && !host.isDestroyed()) host.send('baatora', url, wc.id);
    }
  };
  wc.on('will-navigate', onNav);
  wc.on('will-frame-navigate', (ev) => onNav(ev, ev.url));

  // Keyboard shortcuts page ke andar se bhi chalein
  wc.on('before-input-event', (ev, input) => {
    if (input.type !== 'keyDown') return;
    const k = (input.key || '').toLowerCase();
    const c = input.control || input.meta;
    let combo = null;
    if (c && input.shift && ['n', 't', 'b', 'delete', 'tab', 'i'].includes(k)) combo = 'ctrl+shift+' + k;
    else if (c && ['t', 'w', 'n', 'l', 'r', 'f', 'h', 'j', 'd', 'p', 'tab', '=', '+', '-', '0', 'q', '1', '2', '3', '4', '5', '6', '7', '8', '9'].includes(k)) combo = 'ctrl+' + k;
    else if (input.alt && ['arrowleft', 'arrowright', 'home', 'd'].includes(k)) combo = 'alt+' + k;
    else if (['f5', 'f6', 'f11', 'f12'].includes(k)) combo = k;
    else if (k === 'escape') combo = 'escape';
    if (!combo) return;
    if (combo === 'escape') { const host = wc.hostWebContents; if (host) host.send('shortcut', combo); return; }
    ev.preventDefault();
    const host = wc.hostWebContents;
    if (host && !host.isDestroyed()) host.send('shortcut', combo);
  });

  // Right-click menu
  wc.on('context-menu', (_ev, p) => {
    const host = wc.hostWebContents;
    const send = (...a) => { if (host && !host.isDestroyed()) host.send(...a); };
    const t = [];
    if (p.linkURL) {
      t.push({ label: 'Link naye tab me kholein', click: () => send('open-tab', p.linkURL, true) });
      t.push({ label: 'Link Incognito window me kholein', click: () => createWindow({ incog: true, url: p.linkURL }) });
      t.push({ label: 'Link copy karein', click: () => clipboard.writeText(p.linkURL) });
      t.push({ label: 'Link download karein', click: () => wc.downloadURL(p.linkURL) });
      t.push({ type: 'separator' });
    }
    if (p.mediaType === 'image' && p.srcURL) {
      t.push({ label: 'Photo naye tab me kholein', click: () => send('open-tab', p.srcURL, true) });
      t.push({ label: 'Photo save karein', click: () => wc.downloadURL(p.srcURL) });
      t.push({ label: 'Photo copy karein', click: () => wc.copyImageAt(p.x, p.y) });
      t.push({ label: 'Photo ka link copy karein', click: () => clipboard.writeText(p.srcURL) });
      t.push({ type: 'separator' });
    }
    if ((p.mediaType === 'video' || p.mediaType === 'audio') && p.srcURL && !p.srcURL.startsWith('blob:')) {
      t.push({ label: (p.mediaType === 'video' ? 'Video' : 'Audio') + ' download karein', click: () => wc.downloadURL(p.srcURL) });
      t.push({ type: 'separator' });
    }
    if (p.selectionText && p.selectionText.trim()) {
      const s = p.selectionText.trim();
      t.push({ label: 'Copy', role: 'copy' });
      t.push({ label: `"${s.length > 24 ? s.slice(0, 24) + '…' : s}" Google par khojein`, click: () => send('search-tab', s) });
      t.push({ type: 'separator' });
    }
    if (p.isEditable) {
      if (p.misspelledWord && p.dictionarySuggestions.length) {
        p.dictionarySuggestions.slice(0, 4).forEach(sg => t.push({ label: sg, click: () => wc.replaceMisspelling(sg) }));
        t.push({ type: 'separator' });
      }
      t.push({ label: 'Undo', role: 'undo' }, { label: 'Cut', role: 'cut' }, { label: 'Copy', role: 'copy' }, { label: 'Paste', role: 'paste' }, { label: 'Sab select karein', role: 'selectAll' });
      t.push({ type: 'separator' });
    }
    if (!p.linkURL && !p.isEditable && !(p.selectionText && p.selectionText.trim())) {
      t.push({ label: 'Peeche', enabled: wc.navigationHistory.canGoBack(), click: () => wc.navigationHistory.goBack() });
      t.push({ label: 'Aage', enabled: wc.navigationHistory.canGoForward(), click: () => wc.navigationHistory.goForward() });
      t.push({ label: 'Reload', click: () => wc.reload() });
      t.push({ type: 'separator' });
      t.push({ label: 'Page save karein…', click: () => send('shortcut', 'save-page') });
      t.push({ label: 'Print…', click: () => wc.print() });
      t.push({ label: 'Page ka link copy karein', click: () => clipboard.writeText(wc.getURL()) });
      t.push({ type: 'separator' });
    }
    t.push({ label: 'Inspect (Developer)', click: () => wc.inspectElement(p.x, p.y) });
    Menu.buildFromTemplate(t).popup({ window: BrowserWindow.fromWebContents(host || wc) || undefined });
  });
});

// ---------- IPC from UI ----------
ipcMain.handle('asset', (_e, name) => {
  if (!/^[a-z0-9_-]+\.js$/i.test(name)) return '';
  try { return fs.readFileSync(path.join(__dirname, 'pages', name), 'utf8'); } catch (e) { return ''; }
});
ipcMain.on('adblock', (_e, on) => { adblockOn = !!on; });
ipcMain.on('new-window', (_e, opts) => createWindow(opts || {}));
ipcMain.on('dl-action', (_e, id, act, p) => {
  const item = downloads.get(id);
  if (act === 'cancel' && item) item.cancel();
  else if (act === 'pause' && item) item.pause();
  else if (act === 'resume' && item && item.canResume()) item.resume();
  else if (act === 'open' && p) shell.openPath(p);
  else if (act === 'show' && p) shell.showItemInFolder(p);
  else if (act === 'folder') shell.openPath(dlDir());
});
ipcMain.on('default-browser', () => {
  shell.openExternal('ms-settings:defaultapps?registeredAppUser=Baatora').catch(() => shell.openExternal('ms-settings:defaultapps'));
});
ipcMain.on('open-external', (_e, url) => { if (/^(https?|mailto|tel):/i.test(url)) shell.openExternal(url); });
ipcMain.handle('clear-data', async (_e, what) => {
  const ses = session.fromPartition(NORMAL);
  if (what.cache) await ses.clearCache();
  if (what.cookies) await ses.clearStorageData({ storages: ['cookies', 'localstorage', 'indexdb', 'serviceworkers', 'cachestorage', 'websql', 'filesystem'] });
  return true;
});
ipcMain.handle('save-page', async (e, wcId) => {
  const wc = webContents.fromId(wcId);
  if (!wc) return false;
  const win = BrowserWindow.fromWebContents(e.sender);
  const safe = (wc.getTitle() || 'page').replace(/[\\/:*?"<>|]+/g, ' ').slice(0, 80);
  const r = await dialog.showSaveDialog(win, { defaultPath: path.join(app.getPath('downloads'), safe + '.html'), filters: [{ name: 'Web page', extensions: ['html'] }] });
  if (r.canceled || !r.filePath) return false;
  await wc.savePage(r.filePath, 'HTMLComplete');
  return true;
});
ipcMain.on('title-color', (e, color, symbolColor) => {
  const w = BrowserWindow.fromWebContents(e.sender);
  if (w && w.setTitleBarOverlay) { try { w.setTitleBarOverlay({ color, symbolColor: symbolColor || '#FFFFFF', height: 40 }); } catch (x) {} }
});
ipcMain.on('bt-adblock-on', (e) => { e.returnValue = adblockOn; });
ipcMain.handle('flags', () => FLAGS);
ipcMain.handle('set-flag', (_e, k, v) => { if (!/^[a-zA-Z]+$/.test(k) || k === 'extensions') return FLAGS; FLAGS[k] = v; writeFlags(); return FLAGS; });
ipcMain.on('relaunch', () => { app.relaunch(); app.quit(); });
// ---------- Settings ke naye kaam ----------
const fromUI = (e) => { try { return e.sender.getType() === 'window'; } catch (x) { return false; } };
ipcMain.handle('pick-dl-dir', async (e) => {
  if (!fromUI(e)) return null;
  const r = await dialog.showOpenDialog(BrowserWindow.fromWebContents(e.sender), { properties: ['openDirectory', 'createDirectory'], defaultPath: dlDir() });
  if (r.canceled || !r.filePaths[0]) return null;
  FLAGS.dlDir = r.filePaths[0]; writeFlags();
  return FLAGS.dlDir;
});
ipcMain.handle('set-lang', (e, lang) => {
  if (!fromUI(e)) return false;
  FLAGS.lang = String(lang || '').slice(0, 80); writeFlags();
  [NORMAL, INCOG].forEach((p) => { if (readySessions.has(p)) { const s = session.fromPartition(p); try { s.setUserAgent(s.getUserAgent(), FLAGS.lang || app.getLocale()); } catch (x) {} } });
  return true;
});
ipcMain.handle('spell-info', () => { const s = session.fromPartition(NORMAL); return { enabled: FLAGS.spell !== false, langs: s.getSpellCheckerLanguages(), available: s.availableSpellCheckerLanguages }; });
ipcMain.handle('spell-set', (e, enabled, langs) => {
  if (!fromUI(e)) return false;
  FLAGS.spell = !!enabled; if (Array.isArray(langs)) FLAGS.spellLangs = langs.slice(0, 3); writeFlags();
  [NORMAL, INCOG].forEach((p) => { if (!readySessions.has(p)) return; const s = session.fromPartition(p); try { s.setSpellCheckerEnabled(FLAGS.spell); const av = s.availableSpellCheckerLanguages; const sl = (FLAGS.spellLangs || []).filter((l) => av.includes(l)); if (sl.length) s.setSpellCheckerLanguages(sl); } catch (x) {} });
  return true;
});
ipcMain.handle('ext-list', () => (FLAGS.extensions || []).map((p) => ({ path: p, name: extName(p) })));
ipcMain.handle('ext-add', async (e) => {
  if (!fromUI(e)) return { ok: false, err: 'Not allowed' };
  const r = await dialog.showOpenDialog(BrowserWindow.fromWebContents(e.sender), { title: 'Extension ka folder chunein (jisme manifest.json ho)', properties: ['openDirectory'] });
  if (r.canceled || !r.filePaths[0]) return { ok: false, err: '' };
  const p = r.filePaths[0];
  if (!fs.existsSync(path.join(p, 'manifest.json'))) return { ok: false, err: 'Is folder me manifest.json nahi mila' };
  const x = await loadExt(session.fromPartition(NORMAL), p);
  if (!x) return { ok: false, err: 'Ye extension Baatora me load nahi ho paya' };
  if (!FLAGS.extensions.includes(p)) FLAGS.extensions.push(p);
  writeFlags();
  return { ok: true };
});
ipcMain.handle('ext-remove', (e, p) => {
  if (!fromUI(e)) return false;
  FLAGS.extensions = (FLAGS.extensions || []).filter((x) => x !== p); writeFlags();
  try { const api = session.fromPartition(NORMAL); const a = api.extensions || api; const ex = (a.getAllExtensions ? a.getAllExtensions() : []).find((x) => x.path === p); if (ex) a.removeExtension(ex.id); } catch (x) {}
  return true;
});
// Password manager (Windows ke encryption se)
const vaultFile = () => path.join(app.getPath('userData'), 'baatora-vault.json');
function vaultRead() { try { return JSON.parse(fs.readFileSync(vaultFile(), 'utf8')); } catch (e) { return []; } }
function vaultWrite(v) { try { fs.writeFileSync(vaultFile(), JSON.stringify(v)); } catch (e) {} }
ipcMain.handle('pw-list', (e) => fromUI(e) ? vaultRead().map((x) => ({ id: x.id, site: x.site, user: x.user })) : []);
ipcMain.handle('pw-add', (e, site, user, pw) => {
  if (!fromUI(e)) return { ok: false, err: 'Not allowed' };
  if (!safeStorage.isEncryptionAvailable()) return { ok: false, err: 'Is computer par encryption available nahi hai' };
  site = String(site || '').trim().slice(0, 200); user = String(user || '').trim().slice(0, 200); pw = String(pw || '').slice(0, 500);
  if (!site || !pw) return { ok: false, err: 'Website aur password likhna zaroori hai' };
  const v = vaultRead();
  v.unshift({ id: Date.now() + '' + Math.floor(Math.random() * 1000), site, user, pw: safeStorage.encryptString(pw).toString('base64') });
  vaultWrite(v.slice(0, 500));
  return { ok: true };
});
ipcMain.handle('pw-get', (e, id) => {
  if (!fromUI(e)) return null;
  const x = vaultRead().find((y) => y.id === id); if (!x) return null;
  try { return safeStorage.decryptString(Buffer.from(x.pw, 'base64')); } catch (err) { return null; }
});
ipcMain.handle('pw-del', (e, id) => { if (!fromUI(e)) return false; vaultWrite(vaultRead().filter((y) => y.id !== id)); return true; });
ipcMain.on('open-os', (_e, u) => { if (/^ms-settings:[a-z-]+$/i.test(u)) shell.openExternal(u).catch(() => {}); });
ipcMain.on('reset-flags', (e) => { if (!fromUI(e)) return; try { fs.rmSync(FLAGS_FILE, { force: true }); } catch (x) {} app.relaunch(); app.quit(); });

ipcMain.handle('clear-site', async (_e, origin, incog) => {
  try { await session.fromPartition(incog ? INCOG : NORMAL).clearStorageData({ origin }); return true; } catch (e) { return false; }
});
ipcMain.on('fullscreen', (e, on) => { const w = BrowserWindow.fromWebContents(e.sender); if (w) w.setFullScreen(on === undefined ? !w.isFullScreen() : !!on); });
ipcMain.on('close-window', (e) => { const w = BrowserWindow.fromWebContents(e.sender); if (w) w.close(); });
ipcMain.on('quit', () => app.quit());
ipcMain.handle('info', () => ({ version: app.getVersion(), electron: process.versions.electron, chrome: process.versions.chrome, downloads: dlDir() }));

// ---------- App start ----------
app.whenReady().then(() => {
  if (!gotLock) return;
  Menu.setApplicationMenu(null);
  nativeTheme.themeSource = 'system';
  setupSession(NORMAL);
  createWindow({ url: urlFromArgs(process.argv) });
  app.on('activate', () => { if (BrowserWindow.getAllWindows().length === 0) createWindow(); });
});
app.on('window-all-closed', () => { app.quit(); });
