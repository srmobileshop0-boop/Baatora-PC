const { contextBridge, ipcRenderer } = require('electron');

const allowedOn = ['open-tab', 'search-tab', 'baatora', 'shortcut', 'dl', 'blocked', 'fullscreen'];

contextBridge.exposeInMainWorld('bt', {
  on: (ch, fn) => { if (allowedOn.includes(ch)) ipcRenderer.on(ch, (_e, ...a) => fn(...a)); },
  asset: (name) => ipcRenderer.invoke('asset', name),
  adblock: (on) => ipcRenderer.send('adblock', on),
  newWindow: (opts) => ipcRenderer.send('new-window', opts),
  dl: (id, act, p) => ipcRenderer.send('dl-action', id, act, p),
  defaultBrowser: () => ipcRenderer.send('default-browser'),
  openExternal: (u) => ipcRenderer.send('open-external', u),
  clearData: (what) => ipcRenderer.invoke('clear-data', what),
  savePage: (wcId) => ipcRenderer.invoke('save-page', wcId),
  titleColor: (c, sym) => ipcRenderer.send('title-color', c, sym),
  fullscreen: (on) => ipcRenderer.send('fullscreen', on),
  closeWindow: () => ipcRenderer.send('close-window'),
  quit: () => ipcRenderer.send('quit'),
  info: () => ipcRenderer.invoke('info'),
  flags: () => ipcRenderer.invoke('flags'),
  setFlag: (k, v) => ipcRenderer.invoke('set-flag', k, v),
  relaunch: () => ipcRenderer.send('relaunch'),
  clearSite: (o, incog) => ipcRenderer.invoke('clear-site', o, incog),
  pickDlDir: () => ipcRenderer.invoke('pick-dl-dir'),
  setLang: (l) => ipcRenderer.invoke('set-lang', l),
  spellInfo: () => ipcRenderer.invoke('spell-info'),
  spellSet: (en, langs) => ipcRenderer.invoke('spell-set', en, langs),
  extList: () => ipcRenderer.invoke('ext-list'),
  extAdd: () => ipcRenderer.invoke('ext-add'),
  extRemove: (p) => ipcRenderer.invoke('ext-remove', p),
  pwList: () => ipcRenderer.invoke('pw-list'),
  pwAdd: (site, user, pw) => ipcRenderer.invoke('pw-add', site, user, pw),
  pwGet: (id) => ipcRenderer.invoke('pw-get', id),
  pwDel: (id) => ipcRenderer.invoke('pw-del', id),
  openOs: (u) => ipcRenderer.send('open-os', u),
  resetFlags: () => ipcRenderer.send('reset-flags')
});
